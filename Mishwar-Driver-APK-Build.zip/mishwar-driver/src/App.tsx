import React, { useCallback, useEffect, useState } from 'react';
import { DriverApp } from './components/DriverApp';
import { OfflineIndicator, PWAInstallBanner, PWAInstallButton } from './components/PWAInstallButton';
import { apiRequest } from './lib/api';
import type { DriverProfile, User } from './types/mishwar';

const DEFAULT_DOCUMENT_TITLE = 'MISHWAR – كابتن مشوار | تطبيق السائق';

export default function App() {
  const [auth, setAuth] = useState<{
    token: string | null;
    user: User | null;
    profile: DriverProfile | null;
  }>({
    token: null,
    user: null,
    profile: null,
  });
  const [unreadCount, setUnreadCount] = useState(0);

  const handleUnreadCount = useCallback((count: number) => {
    setUnreadCount((prev) => (prev === count ? prev : count));
  }, []);

  useEffect(() => {
    document.title = unreadCount > 0 ? `(${unreadCount}) كابتن مشوار – السائق` : DEFAULT_DOCUMENT_TITLE;
    const nav = navigator as Navigator & {
      setAppBadge?: (contents?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    if (unreadCount > 0) {
      nav.setAppBadge?.(unreadCount).catch(() => {});
    } else {
      nav.clearAppBadge?.().catch(() => {});
    }
  }, [unreadCount]);

  const handleLogout = async () => {
    if (auth.token) {
      await apiRequest('/api/auth/logout', { method: 'POST', token: auth.token }).catch(() => {});
    }
    setUnreadCount(0);
    setAuth({ token: null, user: null, profile: null });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-lg font-extrabold font-display text-slate-900 whitespace-nowrap shrink-0">
            <img
              src="/src/assets/images/mishwar_brand_mark_1795221944568.jpg"
              alt="شعار مشوار"
              className="w-8 h-8 rounded-lg object-cover"
              referrerPolicy="no-referrer"
            />
            <span>كابتن مشوار — السائق</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
          </div>
        </div>
      </header>

      <PWAInstallBanner />

      <div className="flex-1">
        <DriverApp
          token={auth.token}
          user={auth.user}
          driverProfile={auth.profile}
          onAuthSuccess={(token, user, profile) => setAuth({ token, user, profile })}
          onProfileUpdate={(profile) => setAuth((prev) => ({ ...prev, profile }))}
          onLogout={handleLogout}
          onUnreadCountChange={handleUnreadCount}
        />
      </div>

      <OfflineIndicator />
    </div>
  );
}
