const rawApiBase = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim() || '';
export const API_BASE_URL = rawApiBase.replace(/\/+$/, '');

export function resolveApiUrl(pathOrUrl: string): string {
  if (!pathOrUrl) return pathOrUrl;
  if (/^https?:\/\//i.test(pathOrUrl) || pathOrUrl.startsWith('blob:') || pathOrUrl.startsWith('data:')) {
    return pathOrUrl;
  }
  if (!API_BASE_URL) return pathOrUrl;
  return `${API_BASE_URL}${pathOrUrl.startsWith('/') ? pathOrUrl : `/${pathOrUrl}`}`;
}

export function formatIQD(amount: number | null | undefined): string {
  const num = Number(amount ?? 0);
  return `${Math.round(num).toLocaleString('en-US')} د.ع`;
}

export function formatDateTimeAr(iso: string | null | undefined): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('ar-IQ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export async function apiRequest<T>(
  path: string,
  options: {
    method?: string;
    token?: string | null;
    body?: unknown;
  } = {},
): Promise<T> {
  const headers: Record<string, string> = {};
  if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json';
  }
  if (options.token) {
    headers['Authorization'] = `Bearer ${options.token}`;
  }

  const res = await fetch(resolveApiUrl(path), {
    method: options.method ?? 'GET',
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `خطأ في الخادم (${res.status})`);
  }
  return data as T;
}

export async function uploadImageFile(
  file: File,
  purpose: 'avatar' | 'driver_doc' | 'driver_avatar' | 'complaint_attachment',
  token?: string | null,
): Promise<string> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    throw new Error('يرجى اختيار صورة بصيغة JPG أو PNG أو WebP فقط');
  }
  if (file.size > 5 * 1024 * 1024) {
    throw new Error('حجم الصورة يجب أن لا يتجاوز 5 ميجابايت');
  }
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('تعذر قراءة الملف'));
    reader.readAsDataURL(file);
  });

  const res = await apiRequest<{ url: string }>('/api/uploads', {
    method: 'POST',
    token,
    body: { dataUrl, purpose },
  });
  return res.url;
}

export async function fetchProtectedImageBlobUrl(url: string, token: string): Promise<string> {
  const res = await fetch(resolveApiUrl(url), {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    throw new Error('تعذر تحميل المستمسك');
  }
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

export function createSocketConnection(
  token: string,
  onEvent: (event: string, payload: unknown) => void,
): WebSocket {
  let wsUrl: string;
  if (API_BASE_URL) {
    const parsed = new URL(API_BASE_URL);
    const wsProto = parsed.protocol === 'https:' ? 'wss:' : 'ws:';
    wsUrl = `${wsProto}//${parsed.host}/ws?token=${encodeURIComponent(token)}`;
  } else {
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    wsUrl = `${proto}//${window.location.host}/ws?token=${encodeURIComponent(token)}`;
  }

  const ws = new WebSocket(wsUrl);
  ws.onmessage = (evt) => {
    try {
      const parsed = JSON.parse(evt.data) as { event: string; payload: unknown };
      onEvent(parsed.event, parsed.payload);
    } catch {
      // ignore malformed frames
    }
  };
  return ws;
}

export function triggerBrowserNotification(title: string, body: string) {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, { body, icon: '/pwa-192x192.png' });
    } catch {
      // ignore on platforms requiring service worker notification
    }
  }
}

export async function requestNotificationPermission() {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'default') {
    try {
      await Notification.requestPermission();
    } catch {
      // ignore
    }
  }
}
