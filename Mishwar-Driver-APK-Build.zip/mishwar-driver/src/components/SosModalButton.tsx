import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, PhoneCall, ShieldAlert, X } from 'lucide-react';
import { apiRequest } from '../lib/api';
import type { SosAlert } from '../types/mishwar';

interface SosModalButtonProps {
  token: string;
  rideId?: string | null;
  currentCoords?: { lat: number; lng: number } | null;
  compact?: boolean;
}

const INCIDENT_TYPES = [
  'طوارئ أمنية أو مضايقة',
  'حادث مروري',
  'مشكلة خطيرة أثناء الرحلة',
  'حالة صحية طارئة',
  'ضغطت بالخطأ / أخرى',
];

export const SosModalButton: React.FC<SosModalButtonProps> = ({
  token,
  rideId = null,
  currentCoords = null,
  compact = false,
}) => {
  const [open, setOpen] = useState(false);
  const [emergencyPhone, setEmergencyPhone] = useState('104');
  const [incidentType, setIncidentType] = useState(INCIDENT_TYPES[0]);
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [activeAlert, setActiveAlert] = useState<SosAlert | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;
    apiRequest<{ emergency_phone: string }>('/api/app/emergency-info', { token })
      .then((res) => setEmergencyPhone(res.emergency_phone || '104'))
      .catch(() => {});
  }, [token]);

  const resolveCoords = (): Promise<{ lat: number | null; lng: number | null }> => {
    if (currentCoords) return Promise.resolve(currentCoords);
    if (!navigator.geolocation) return Promise.resolve({ lat: null, lng: null });
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => resolve({ lat: null, lng: null }),
        { enableHighAccuracy: true, timeout: 3500 },
      );
    });
  };

  const handleSendSos = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const coords = await resolveCoords();
      const res = await apiRequest<{ alert: SosAlert; emergency_phone: string }>('/api/sos', {
        method: 'POST',
        token,
        body: {
          rideId,
          lat: coords.lat,
          lng: coords.lng,
          incidentType,
          notes,
        },
      });
      setActiveAlert(res.alert);
      setEmergencyPhone(res.emergency_phone || emergencyPhone);
      setNotes('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إرسال تنبيه الطوارئ');
    } finally {
      setBusy(false);
    }
  };

  const handleFalseAlarmCancel = async () => {
    if (!activeAlert) return;
    setBusy(true);
    setError(null);
    try {
      await apiRequest(`/api/sos/${activeAlert.id}/cancel`, {
        method: 'POST',
        token,
      });
      setActiveAlert(null);
      setConfirmCancel(false);
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إلغاء التنبيه');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={`inline-flex items-center justify-center gap-1.5 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 transition-colors shadow-sm ${
          compact ? 'px-3 py-2 text-xs min-h-[40px]' : 'w-full py-3 text-xs min-h-[44px]'
        }`}
      >
        <ShieldAlert className="w-4 h-4 shrink-0" />
        <span>طوارئ SOS</span>
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 border border-red-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-red-700">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="text-base font-bold">مركز الطوارئ والأمان — SOS</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  setConfirmCancel(false);
                }}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="rounded-xl bg-red-50 border border-red-200 p-3 text-xs text-red-700">{error}</div>
            )}

            {activeAlert ? (
              <div className="space-y-4">
                <div className="rounded-xl bg-red-50 border border-red-200 p-4 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 font-bold text-red-900 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-red-600" />
                    <span>تم إرسال تنبيه الطوارئ فوراً إلى الإدارة!</span>
                  </div>
                  <p className="text-red-800">
                    تم تسجيل موقعك الحالي وبيانات الرحلة ووقت التنبيه في غرفة عمليات مشوار.
                  </p>
                </div>

                <a
                  href={`tel:${emergencyPhone}`}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3.5 text-sm font-bold text-white hover:bg-emerald-700"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>اتصال فوري برقم الطوارئ ({emergencyPhone})</span>
                </a>

                {!confirmCancel ? (
                  <button
                    type="button"
                    onClick={() => setConfirmCancel(true)}
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 py-3 text-xs font-bold text-slate-700 hover:bg-slate-100"
                  >
                    تم الضغط بالخطأ — إلغاء التنبيه
                  </button>
                ) : (
                  <div className="rounded-xl border border-amber-300 bg-amber-50 p-3 space-y-2 text-xs">
                    <div className="font-bold text-amber-900">
                      تأكيد إلغاء التنبيه: هل أنت بأمان وتم الضغط بالخطأ؟
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        disabled={busy}
                        onClick={handleFalseAlarmCancel}
                        className="flex-1 rounded-lg bg-amber-600 py-2 font-bold text-white"
                      >
                        نعم، أنا بأمان وألغِ التنبيه
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmCancel(false)}
                        className="rounded-lg border border-slate-300 bg-white px-3 py-2 font-semibold"
                      >
                        تراجع
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <form onSubmit={handleSendSos} className="space-y-3">
                <p className="text-xs text-slate-600 leading-relaxed">
                  عند إرسال التنبيه سيتم إشعار فريق الإدارة فوراً بموقعك الجغرافي الحالي وبيانات رحلتك.
                </p>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">نوع الحالة الطارئة</label>
                  <select
                    value={incidentType}
                    onChange={(e) => setIncidentType(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-xs bg-white"
                  >
                    {INCIDENT_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ملاحظات إضافية (اختياري)</label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="اكتب أي تفاصيل تساعد فريق الطوارئ..."
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={busy}
                  className="w-full rounded-xl bg-red-600 py-3.5 text-sm font-bold text-white hover:bg-red-700 disabled:opacity-60"
                >
                  {busy ? 'جاري إرسال الإشارة...' : 'تأكيد وإرسال تنبيه الطوارئ الآن'}
                </button>

                <a
                  href={`tel:${emergencyPhone}`}
                  className="w-full flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-slate-50 py-2.5 text-xs font-bold text-slate-800 hover:bg-slate-100"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                  <span>الاتصال المباشر برقم الطوارئ ({emergencyPhone})</span>
                </a>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
};
