import React, { useState } from 'react';
import { CheckCircle2, FileText, ShieldCheck, X } from 'lucide-react';
import {
  CUSTOMER_TERMS_ACKNOWLEDGEMENT,
  CUSTOMER_TERMS_CLAUSES,
  CUSTOMER_TERMS_INTRO,
  CUSTOMER_TERMS_TITLE,
  CUSTOMER_TERMS_VERSION,
  DRIVER_TERMS_ACKNOWLEDGEMENT,
  DRIVER_TERMS_CLAUSES,
  DRIVER_TERMS_INTRO,
  DRIVER_TERMS_TITLE,
  DRIVER_TERMS_VERSION,
  PRIVACY_POLICY_SECTIONS,
  PRIVACY_POLICY_VERSION,
} from '../legal/agreements';

interface LegalTermsModalProps {
  role: 'customer' | 'driver';
  open: boolean;
  requireConsent?: boolean;
  busy?: boolean;
  onAccept?: () => void;
  onClose?: () => void;
}

export const LegalTermsModal: React.FC<LegalTermsModalProps> = ({
  role,
  open,
  requireConsent = false,
  busy = false,
  onAccept,
  onClose,
}) => {
  const [section, setSection] = useState<'terms' | 'privacy'>('terms');
  const [checked, setChecked] = useState(false);

  if (!open) return null;

  const isDriver = role === 'driver';
  const title = isDriver ? DRIVER_TERMS_TITLE : CUSTOMER_TERMS_TITLE;
  const intro = isDriver ? DRIVER_TERMS_INTRO : CUSTOMER_TERMS_INTRO;
  const clauses = isDriver ? DRIVER_TERMS_CLAUSES : CUSTOMER_TERMS_CLAUSES;
  const acknowledgement = isDriver ? DRIVER_TERMS_ACKNOWLEDGEMENT : CUSTOMER_TERMS_ACKNOWLEDGEMENT;
  const version = isDriver ? DRIVER_TERMS_VERSION : CUSTOMER_TERMS_VERSION;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4 backdrop-blur-sm"
      dir="rtl"
    >
      <div className="w-full max-w-2xl rounded-2xl bg-white border border-slate-200 shadow-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              {section === 'terms' ? <FileText className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
            </div>
            <div className="min-w-0">
              <h3 className="text-base font-bold text-slate-900 truncate">
                {section === 'terms' ? title : 'سياسة الخصوصية وحماية البيانات — مشوار'}
              </h3>
              <div className="text-[11px] text-slate-500 font-mono">
                MISHWAR · الإصدار {section === 'terms' ? version : PRIVACY_POLICY_VERSION}
              </div>
            </div>
          </div>

          {!requireConsent && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 px-5 pt-3 border-b border-slate-100 bg-slate-50/70">
          <button
            type="button"
            onClick={() => setSection('terms')}
            className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-colors ${
              section === 'terms'
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            {isDriver ? 'اتفاقية السائق (20 بنداً)' : 'اتفاقية الزبون (14 بنداً)'}
          </button>
          <button
            type="button"
            onClick={() => setSection('privacy')}
            className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-colors ${
              section === 'privacy'
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            سياسة الخصوصية وحماية الموقع والهوية
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3 text-xs leading-relaxed text-slate-700">
          {section === 'terms' ? (
            <>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 font-semibold text-slate-900">
                {intro}
              </div>
              <ol className="space-y-2.5">
                {clauses.map((clause) => (
                  <li
                    key={clause.number}
                    className={`rounded-xl border p-3 ${
                      isDriver && clause.number === 7
                        ? 'border-amber-200 bg-amber-50/60 text-slate-900'
                        : 'border-slate-100 bg-white'
                    }`}
                  >
                    <span className="font-bold text-blue-700 ml-1.5 font-mono">{clause.number}.</span>
                    <span className="font-bold text-slate-900 ml-1.5">{clause.title}:</span>
                    <span>{clause.body}</span>
                  </li>
                ))}
              </ol>
              <div className="rounded-xl bg-blue-50 border border-blue-200 p-3.5 font-bold text-blue-950">
                {acknowledgement}
              </div>
            </>
          ) : (
            <div className="space-y-3">
              {PRIVACY_POLICY_SECTIONS.map((sec) => (
                <div key={sec.title} className="rounded-xl border border-slate-200 p-3.5 bg-white">
                  <div className="font-bold text-slate-900 mb-1">{sec.title}</div>
                  <p className="text-slate-600 leading-relaxed">{sec.body}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="px-5 py-4 border-t border-slate-200 bg-slate-50 space-y-3">
          {requireConsent ? (
            <>
              <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-800 select-none">
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={(e) => setChecked(e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600"
                />
                <span className="font-semibold">
                  أقر بأنني قرأت جميع البنود المذكورة أعلاه وسياسة الخصوصية وفهمتها وأوافق عليها صراحةً.
                </span>
              </label>
              <button
                type="button"
                disabled={!checked || busy}
                onClick={onAccept}
                className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-50 min-h-[46px]"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{busy ? 'جاري تسجيل الموافقة...' : 'أوافق وأتابع استخدام مشوار'}</span>
              </button>
            </>
          ) : (
            <div className="flex items-center justify-end gap-2">
              {onAccept && (
                <button
                  type="button"
                  onClick={onAccept}
                  className="rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-blue-700"
                >
                  تحديد كموافق عليه وإغلاق
                </button>
              )}
              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  إغلاق
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
