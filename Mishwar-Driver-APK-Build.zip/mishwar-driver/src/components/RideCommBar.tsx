import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Flag,
  MessageSquare,
  Mic,
  MicOff,
  Phone,
  PhoneCall,
  PhoneOff,
  Send,
  ShieldCheck,
  X,
} from 'lucide-react';
import { apiRequest } from '../lib/api';
import type { RideMessage } from '../types/mishwar';

export interface CommWsPacket {
  seq: number;
  event: string;
  payload: Record<string, unknown>;
}

interface RideCommBarProps {
  rideId: string;
  token: string;
  currentUserId: string;
  currentRole: 'customer' | 'driver';
  otherPartyLabel: string;
  otherPartyName: string;
  otherPartyMaskedPhone?: string;
  incomingCommEvent: CommWsPacket | null;
  sendWsSignal: (event: string, payload: Record<string, unknown>) => void;
}

export const RideCommBar: React.FC<RideCommBarProps> = ({
  rideId,
  token,
  currentUserId,
  otherPartyLabel,
  otherPartyName,
  otherPartyMaskedPhone,
  incomingCommEvent,
  sendWsSignal,
}) => {
  const [messages, setMessages] = useState<RideMessage[]>([]);
  const [chatOpen, setChatOpen] = useState(true);
  const [msgText, setMsgText] = useState('');
  const [sending, setSending] = useState(false);
  const [commError, setCommError] = useState<string | null>(null);
  const [reportTarget, setReportTarget] = useState<RideMessage | null>(null);
  const [reportReason, setReportReason] = useState('لغة مسيئة أو سلوك غير مناسب');
  const [reportSuccess, setReportSuccess] = useState<string | null>(null);

  // Masked call state
  const [callState, setCallState] = useState<'idle' | 'calling' | 'ringing_incoming' | 'connected'>('idle');
  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const [incomingOffer, setIncomingOffer] = useState<{
    call_id?: string;
    sdp?: RTCSessionDescriptionInit;
    caller_name?: string;
  } | null>(null);
  const [muted, setMuted] = useState(false);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const loadMessages = useCallback(async () => {
    try {
      const res = await apiRequest<{ messages: RideMessage[]; closed: boolean }>(`/api/rides/${rideId}/messages`, {
        token,
      });
      setMessages(res.messages);
    } catch {
      // ignore transient error
    }
  }, [rideId, token]);

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const cleanupCallMedia = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    setMuted(false);
  }, []);

  useEffect(() => {
    return () => {
      cleanupCallMedia();
    };
  }, [cleanupCallMedia]);

  const createPeerConnection = useCallback(
    async (callId: string) => {
      cleanupCallMedia();
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
      });
      pc.onicecandidate = (e) => {
        if (e.candidate) {
          sendWsSignal('call:ice', { ride_id: rideId, call_id: callId, candidate: e.candidate });
        }
      };
      pc.ontrack = (e) => {
        if (remoteAudioRef.current && e.streams[0]) {
          remoteAudioRef.current.srcObject = e.streams[0];
          remoteAudioRef.current.play().catch(() => {});
        }
      };
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localStreamRef.current = stream;
        stream.getTracks().forEach((track) => pc.addTrack(track, stream));
      } catch {
        setCommError('تعذر الوصول إلى الميكروفون؛ تأكد من منح الإذن في المتصفح للمكالمة الصوتية.');
      }
      pcRef.current = pc;
      return pc;
    },
    [cleanupCallMedia, rideId, sendWsSignal],
  );

  // Handle incoming WS events forwarded from parent
  useEffect(() => {
    if (!incomingCommEvent) return;
    const { event, payload } = incomingCommEvent;
    if (String(payload.ride_id || '') !== rideId) return;

    if (event === 'chat:message') {
      const m = payload as unknown as RideMessage;
      setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
      setChatOpen(true);
    } else if (event === 'call:incoming') {
      setActiveCallId(String(payload.call_id || ''));
      setIncomingOffer({
        call_id: String(payload.call_id || ''),
        caller_name: String(payload.caller_name || otherPartyName),
      });
      setCallState('ringing_incoming');
    } else if (event === 'call:offer') {
      const sdp = payload.sdp as RTCSessionDescriptionInit | undefined;
      const cid = String(payload.call_id || activeCallId || '');
      setActiveCallId(cid);
      setIncomingOffer((prev) => ({ ...prev, call_id: cid, sdp }));
      setCallState('ringing_incoming');
    } else if (event === 'call:answer') {
      const sdp = payload.sdp as RTCSessionDescriptionInit | undefined;
      if (pcRef.current && sdp) {
        pcRef.current.setRemoteDescription(new RTCSessionDescription(sdp)).catch(() => {});
        setCallState('connected');
      }
    } else if (event === 'call:ice') {
      const cand = payload.candidate as RTCIceCandidateInit | undefined;
      if (pcRef.current && cand) {
        pcRef.current.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
      }
    } else if (event === 'call:hangup' || event === 'call:reject') {
      cleanupCallMedia();
      setCallState('idle');
      setActiveCallId(null);
      setIncomingOffer(null);
    }
  }, [incomingCommEvent, rideId, otherPartyName, activeCallId, cleanupCallMedia]);

  const handleStartCall = async () => {
    setCommError(null);
    try {
      const res = await apiRequest<{ session: { id: string } }>(`/api/rides/${rideId}/call/start`, {
        method: 'POST',
        token,
      });
      const cid = res.session.id;
      setActiveCallId(cid);
      setCallState('calling');
      const pc = await createPeerConnection(cid);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      sendWsSignal('call:offer', { ride_id: rideId, call_id: cid, sdp: offer });
    } catch (err) {
      setCallState('idle');
      setCommError(err instanceof Error ? err.message : 'تعذر بدء الاتصال الآمن');
    }
  };

  const handleAcceptCall = async () => {
    setCommError(null);
    const cid = incomingOffer?.call_id || activeCallId || '';
    try {
      const pc = await createPeerConnection(cid);
      if (incomingOffer?.sdp) {
        await pc.setRemoteDescription(new RTCSessionDescription(incomingOffer.sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        sendWsSignal('call:answer', { ride_id: rideId, call_id: cid, sdp: answer });
      }
      setCallState('connected');
    } catch {
      setCommError('تعذر إتمام الاتصال الصوتي');
    }
  };

  const handleHangup = async (reject = false) => {
    const cid = activeCallId;
    cleanupCallMedia();
    setCallState('idle');
    setActiveCallId(null);
    setIncomingOffer(null);
    if (cid) {
      sendWsSignal(reject ? 'call:reject' : 'call:hangup', { ride_id: rideId, call_id: cid });
    }
    await apiRequest(`/api/rides/${rideId}/call/end`, {
      method: 'POST',
      token,
      body: { callId: cid },
    }).catch(() => {});
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgText.trim() || sending) return;
    setSending(true);
    setCommError(null);
    try {
      const res = await apiRequest<{ message: RideMessage }>(`/api/rides/${rideId}/messages`, {
        method: 'POST',
        token,
        body: { body: msgText.trim() },
      });
      setMessages((prev) => (prev.some((x) => x.id === res.message.id) ? prev : [...prev, res.message]));
      setMsgText('');
    } catch (err) {
      setCommError(err instanceof Error ? err.message : 'تعذر إرسال الرسالة');
    } finally {
      setSending(false);
    }
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportTarget) return;
    try {
      await apiRequest(`/api/rides/${rideId}/messages/${reportTarget.id}/report`, {
        method: 'POST',
        token,
        body: { reason: reportReason },
      });
      setMessages((prev) => prev.map((m) => (m.id === reportTarget.id ? { ...m, is_reported: 1 } : m)));
      setReportTarget(null);
      setReportSuccess('تم إرسال البلاغ للإدارة وسيتم الاحتفاظ بالرسالة للمراجعة.');
      setTimeout(() => setReportSuccess(null), 5000);
    } catch (err) {
      setCommError(err instanceof Error ? err.message : 'تعذر الإبلاغ عن الرسالة');
    }
  };

  const formatTimeOnly = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 space-y-3">
      <audio ref={remoteAudioRef} autoPlay className="hidden" />

      {/* Masked Call & Chat Toggle Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <div className="text-xs min-w-0">
            <div className="font-bold text-slate-900 truncate">
              التواصل مع {otherPartyLabel}: {otherPartyName}
            </div>
            {otherPartyMaskedPhone && (
              <div className="text-[11px] text-slate-500 font-mono" dir="ltr">
                {otherPartyMaskedPhone} (رقم محمي)
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {callState === 'idle' && (
            <button
              type="button"
              onClick={handleStartCall}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-700 transition-colors min-h-[38px]"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>اتصال آمن</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setChatOpen((v) => !v)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 hover:bg-slate-100 transition-colors min-h-[38px]"
          >
            <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
            <span>المحادثة ({messages.length})</span>
          </button>
        </div>
      </div>

      {/* Active / Incoming Call Strip */}
      {callState !== 'idle' && (
        <div className="rounded-lg bg-slate-900 text-white px-3 py-2.5 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <PhoneCall className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>
              {callState === 'calling' && `جاري الاتصال الآمن بـ ${otherPartyName}...`}
              {callState === 'ringing_incoming' && `مكالمة واردة من ${otherPartyName} (رقم مخفي)`}
              {callState === 'connected' && `مكالمة صوتية نشطة مع ${otherPartyName}`}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            {callState === 'ringing_incoming' && (
              <button
                type="button"
                onClick={handleAcceptCall}
                className="rounded-lg bg-emerald-600 px-3 py-1.5 font-bold hover:bg-emerald-700"
              >
                رد
              </button>
            )}
            {callState === 'connected' && (
              <button
                type="button"
                onClick={() => {
                  const nextMuted = !muted;
                  localStreamRef.current?.getAudioTracks().forEach((t) => {
                    t.enabled = !nextMuted;
                  });
                  setMuted(nextMuted);
                }}
                className="rounded-lg bg-slate-700 px-2.5 py-1.5"
                title={muted ? 'تشغيل الميكروفون' : 'كتم الميكروفون'}
              >
                {muted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              </button>
            )}
            <button
              type="button"
              onClick={() => handleHangup(callState === 'ringing_incoming')}
              className="rounded-lg bg-red-600 px-3 py-1.5 font-bold hover:bg-red-700 inline-flex items-center gap-1"
            >
              <PhoneOff className="w-3.5 h-3.5" />
              <span>{callState === 'ringing_incoming' ? 'رفض' : 'إنهاء'}</span>
            </button>
          </div>
        </div>
      )}

      {commError && <div className="text-[11px] text-red-700 bg-red-50 rounded-lg px-2.5 py-1.5">{commError}</div>}
      {reportSuccess && (
        <div className="text-[11px] text-emerald-800 bg-emerald-50 rounded-lg px-2.5 py-1.5">{reportSuccess}</div>
      )}

      {/* Inline Chat Body */}
      {chatOpen && (
        <div className="space-y-2 border-t border-slate-200 pt-2.5">
          <div className="text-[10px] text-slate-400 text-center">
            محادثة مرتبطة بالرحلة فقط — تُحذف الرسائل تلقائياً فور انتهاء الرحلة ما لم يُبلغ عنها
          </div>

          <div className="max-h-44 overflow-y-auto space-y-2 px-1">
            {messages.length === 0 ? (
              <div className="text-[11px] text-slate-400 text-center py-3">
                لا توجد رسائل بعد. يمكنك إرسال رسالة فورية لتنسيق نقطة الالتقاء.
              </div>
            ) : (
              messages.map((m) => {
                const isMine = m.sender_id === currentUserId;
                return (
                  <div key={m.id} className={`flex flex-col ${isMine ? 'items-start' : 'items-end'}`}>
                    <div
                      className={`max-w-[85%] rounded-xl px-3 py-2 text-xs ${
                        isMine
                          ? 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="leading-relaxed break-words">{m.body}</div>
                      <div
                        className={`mt-1 flex items-center justify-between gap-2 text-[10px] ${
                          isMine ? 'text-blue-100' : 'text-slate-400'
                        }`}
                      >
                        <span>{formatTimeOnly(m.created_at)}</span>
                        {!isMine && (
                          <button
                            type="button"
                            onClick={() => setReportTarget(m)}
                            disabled={m.is_reported === 1}
                            className="inline-flex items-center gap-0.5 text-red-600 hover:underline disabled:text-slate-400 font-semibold"
                          >
                            <Flag className="w-2.5 h-2.5" />
                            <span>{m.is_reported === 1 ? 'تم الإبلاغ' : 'إبلاغ'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSendMessage} className="flex items-center gap-1.5">
            <input
              type="text"
              value={msgText}
              onChange={(e) => setMsgText(e.target.value)}
              maxLength={600}
              placeholder="اكتب رسالة فورية..."
              className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs focus:border-blue-600 focus:outline-none"
            />
            <button
              type="submit"
              disabled={sending || !msgText.trim()}
              className="rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white hover:bg-blue-700 disabled:opacity-50 inline-flex items-center gap-1"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال</span>
            </button>
          </form>
        </div>
      )}

      {/* Report Message Modal */}
      {reportTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={handleSubmitReport}
            className="w-full max-w-sm rounded-2xl bg-white p-5 space-y-3 border border-slate-200 shadow-xl"
          >
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-slate-900">الإبلاغ عن رسالة غير مناسبة</h4>
              <button type="button" onClick={() => setReportTarget(null)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-2.5 text-xs text-slate-700">
              "{reportTarget.body}"
            </div>
            <select
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs bg-white"
            >
              <option value="لغة مسيئة أو سلوك غير مناسب">لغة مسيئة أو سلوك غير مناسب</option>
              <option value="مضايقة أو تهديد">مضايقة أو تهديد</option>
              <option value="طلب تواصل خارج التطبيق أو مخالفة">طلب تواصل خارج التطبيق أو مخالفة</option>
              <option value="سبب آخر">سبب آخر</option>
            </select>
            <div className="flex gap-2">
              <button type="submit" className="flex-1 rounded-xl bg-red-600 py-2.5 text-xs font-bold text-white">
                تأكيد الإبلاغ
              </button>
              <button
                type="button"
                onClick={() => setReportTarget(null)}
                className="rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-semibold"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
