import React, { useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { Download, Smartphone, WifiOff, X } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export type PWADisplayMode = 'standalone' | 'minimal-ui' | 'browser';

export function detectPWADisplayMode(): PWADisplayMode {
  if (typeof window === 'undefined') return 'browser';
  if (Capacitor.isNativePlatform()) {
    return 'standalone';
  }
  const nav = window.navigator as unknown as { standalone?: boolean };
  if (
    window.matchMedia('(display-mode: standalone)').matches ||
    nav.standalone === true ||
    document.referrer.startsWith('android-app://')
  ) {
    return 'standalone';
  }
  if (window.matchMedia('(display-mode: minimal-ui)').matches) {
    return 'minimal-ui';
  }
  return 'browser';
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [displayMode, setDisplayMode] = useState<PWADisplayMode>(() => detectPWADisplayMode());
  const [isIOS, setIsIOS] = useState(false);
  const [isEmbeddedFrame, setIsEmbeddedFrame] = useState(false);

  const isInstalled = displayMode === 'standalone' || displayMode === 'minimal-ui';

  useEffect(() => {
    const syncDisplayMode = () => setDisplayMode(detectPWADisplayMode());
    syncDisplayMode();

    const ua = window.navigator.userAgent.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(ua));
    try {
      setIsEmbeddedFrame(window.self !== window.top);
    } catch {
      setIsEmbeddedFrame(true);
    }

    const standaloneMq = window.matchMedia('(display-mode: standalone)');
    const minimalMq = window.matchMedia('(display-mode: minimal-ui)');
    standaloneMq.addEventListener?.('change', syncDisplayMode);
    minimalMq.addEventListener?.('change', syncDisplayMode);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    const handleAppInstalled = () => {
      setDisplayMode('standalone');
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    return () => {
      standaloneMq.removeEventListener?.('change', syncDisplayMode);
      minimalMq.removeEventListener?.('change', syncDisplayMode);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDisplayMode('standalone');
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    displayMode,
    isIOS,
    isEmbeddedFrame,
    install,
  };
}

const IOSGuideModal: React.FC<{ open: boolean; onClose: () => void; isEmbeddedFrame?: boolean }> = ({
  open,
  onClose,
  isEmbeddedFrame = false,
}) => {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm"
      dir="rtl"
    >
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-base font-bold text-slate-900">تثبيت تطبيق مشوار على الشاشة الرئيسية</h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isEmbeddedFrame && (
          <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900 leading-relaxed">
            تفتح التطبيق حالياً داخل نافذة مدمجة. لتثبيت التطبيق على هاتفك، افتح رابط التطبيق مباشرة في متصفح{' '}
            <strong>Chrome</strong> (أندرويد) أو <strong>Safari</strong> (آيفون).
          </div>
        )}

        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <div className="rounded-xl bg-slate-50 border border-slate-200 p-3">
            <div className="font-bold text-slate-900 mb-1">على هواتف Android (متصفح Chrome):</div>
            <ol className="list-decimal list-inside space-y-1">
              <li>اضغط على زر القائمة (⋮) في أعلى المتصفح.</li>
              <li>اختر «تثبيت التطبيق» أو «الإضافة إلى الشاشة الرئيسية».</li>
              <li>أكّد التثبيت لتعمل أيقونة مشوار كـ PWA بملء الشاشة.</li>
            </ol>
          </div>

          <div className="rounded-xl bg-slate-50 border border-slate-200 p-3">
            <div className="font-bold text-slate-900 mb-1">على أجهزة iPhone / iPad (متصفح Safari):</div>
            <ol className="list-decimal list-inside space-y-1">
              <li>افتح التطبيق في متصفح Safari ثم اضغط زر المشاركة (Share).</li>
              <li>مرّر للأسفل واختر «إضافة إلى الشاشة الرئيسية» (Add to Home Screen).</li>
              <li>اضغط «إضافة» في الأعلى لتشغيل مشوار كتطبيق مستقل.</li>
            </ol>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 transition-colors"
        >
          فهمت
        </button>
      </div>
    </div>
  );
};

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isEmbeddedFrame, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) return null;

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
      >
        <Download className="w-4 h-4" />
        <span>تثبيت التطبيق</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowGuide(true)}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
        >
          <Smartphone className="w-4 h-4 text-blue-600" />
          <span>تثبيت على iPhone</span>
        </button>
        <IOSGuideModal open={showGuide} onClose={() => setShowGuide(false)} isEmbeddedFrame={isEmbeddedFrame} />
      </>
    );
  }

  return null;
};

const BANNER_DISMISSED_KEY = 'mishwar_pwa_banner_dismissed';

export const PWAInstallBanner: React.FC = () => {
  const { isInstalled, isInstallable, isIOS, isEmbeddedFrame, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(() => {
    try {
      return typeof window !== 'undefined' && window.sessionStorage.getItem(BANNER_DISMISSED_KEY) === '1';
    } catch {
      return false;
    }
  });
  const [showGuide, setShowGuide] = useState(false);

  // Do not display prompt when already running in standalone or minimal-ui PWA display modes
  if (isInstalled || dismissed) return null;

  const handleDismiss = () => {
    setDismissed(true);
    try {
      window.sessionStorage.setItem(BANNER_DISMISSED_KEY, '1');
    } catch {
      // Ignore storage access errors in restricted webviews
    }
  };

  return (
    <>
      <div className="bg-blue-50 border-b border-blue-200" dir="rtl" role="region" aria-label="تثبيت تطبيق مشوار">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Smartphone className="w-4 h-4" />
            </div>
            <div className="text-xs leading-snug">
              <span className="font-bold text-slate-900">التطبيق غير مثبت كـ PWA حالياً: </span>
              <span className="text-slate-700">
                أضف مشوار إلى الشاشة الرئيسية للوصول السريع والعمل بملء الشاشة كتطبيق أصلي.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isInstallable ? (
              <button
                type="button"
                onClick={install}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-blue-700 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تثبيت التطبيق الآن</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setShowGuide(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-blue-700 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isIOS ? 'إضافة للشاشة الرئيسية (iPhone)' : 'طريقة الإضافة للشاشة الرئيسية'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleDismiss}
              className="p-1.5 rounded-lg text-slate-500 hover:bg-blue-100 hover:text-slate-800 transition-colors"
              aria-label="إخفاء رسالة التثبيت"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <IOSGuideModal open={showGuide} onClose={() => setShowGuide(false)} isEmbeddedFrame={isEmbeddedFrame} />
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true,
  );

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-4 py-2 text-xs font-semibold text-white shadow-lg">
      <WifiOff className="w-4 h-4" />
      <span>لا يوجد اتصال بالإنترنت — يتم عرض البيانات المخزنة</span>
    </div>
  );
};
