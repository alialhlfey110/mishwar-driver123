import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';
import {
  AlertCircle,
  Bell,
  Camera,
  Car,
  Check,
  Clock,
  Copy,
  CreditCard,
  DollarSign,
  ExternalLink,
  FileText,
  Flag,
  HeadphonesIcon,
  History,
  Lock,
  LogOut,
  MapPin,
  Power,
  ShieldAlert,
  Star,
  Wallet,
  X,
} from 'lucide-react';
import { DRIVER_TERMS_VERSION } from '../legal/agreements';
import {
  apiRequest,
  createSocketConnection,
  formatDateTimeAr,
  formatIQD,
  requestNotificationPermission,
  triggerBrowserNotification,
  uploadImageFile,
} from '../lib/api';
import {
  CATEGORY_LABELS,
  COMPLAINT_CATEGORIES,
  PAYMENT_METHOD_LABELS,
  RIDE_STATUS_LABELS,
  type Complaint,
  type DriverProfile,
  type DriverWallet,
  type PaymentGatewayConfig,
  type PaymentMethod,
  type Ride,
  type RideNotification,
  type User,
  type VehicleCategory,
  type WalletTransaction,
} from '../types/mishwar';
import { LegalTermsModal } from './LegalTermsModal';
import { MishwarMap } from './MishwarMap';
import { ProtectedImage } from './ProtectedImage';
import { RideCommBar, type CommWsPacket } from './RideCommBar';
import { SosModalButton } from './SosModalButton';

interface DriverAppProps {
  token: string | null;
  user: User | null;
  driverProfile: DriverProfile | null;
  onAuthSuccess: (token: string, user: User, driverProfile: DriverProfile) => void;
  onProfileUpdate: (driverProfile: DriverProfile) => void;
  onLogout: () => void;
  onUnreadCountChange?: (count: number) => void;
}

interface IncomingOffer {
  attempt_id: string;
  ride: Ride;
  distance_to_pickup_km?: number;
  expires_at: string;
}

function haversineKmClient(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export const DriverApp: React.FC<DriverAppProps> = ({
  token,
  user,
  driverProfile,
  onAuthSuccess,
  onProfileUpdate,
  onLogout,
  onUnreadCountChange,
}) => {
  // Auth state
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [carMake, setCarMake] = useState('');
  const [carModel, setCarModel] = useState('');
  const [carYear, setCarYear] = useState('2022');
  const [carColor, setCarColor] = useState('');
  const [plateNumber, setPlateNumber] = useState('');
  const [category, setCategory] = useState<VehicleCategory>('Economy');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [licenseDocUrl, setLicenseDocUrl] = useState<string | null>(null);
  const [registrationDocUrl, setRegistrationDocUrl] = useState<string | null>(null);
  const [nationalIdDocUrl, setNationalIdDocUrl] = useState<string | null>(null);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [showLegalModal, setShowLegalModal] = useState(false);
  const [legalModalMode, setLegalModalMode] = useState<'view' | 'require_accept'>('view');
  const [termsBusy, setTermsBusy] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authBusy, setAuthBusy] = useState(false);

  // Driver App state
  const [tab, setTab] = useState<'drive' | 'wallet' | 'earnings' | 'history' | 'support'>('drive');
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [offer, setOffer] = useState<IncomingOffer | null>(null);
  const [copiedAccount, setCopiedAccount] = useState(false);

  // Commission consent & wallet state
  const [activeCommissionPercent, setActiveCommissionPercent] = useState<number>(10);
  const [requiresCommissionConsent, setRequiresCommissionConsent] = useState<boolean>(false);
  const [commissionBusy, setCommissionBusy] = useState(false);
  const [wallet, setWallet] = useState<DriverWallet | null>(null);
  const [walletTxs, setWalletTxs] = useState<WalletTransaction[]>([]);
  const [topupGateways, setTopupGateways] = useState<PaymentGatewayConfig[]>([]);
  const [topupProvider, setTopupProvider] = useState<'superqi' | 'zaincash'>('superqi');
  const [topupAmount, setTopupAmount] = useState('10000');
  const [topupBusy, setTopupBusy] = useState(false);
  const [topupCheckoutUrl, setTopupCheckoutUrl] = useState<string | null>(null);
  const [topupError, setTopupError] = useState<string | null>(null);
  const [offerCountdown, setOfferCountdown] = useState(0);
  const [routeGeometry, setRouteGeometry] = useState<[number, number][]>([]);
  const [approachGeometry, setApproachGeometry] = useState<[number, number][]>([]);
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'active' | 'lost'>('idle');
  const [myCoords, setMyCoords] = useState<{
    lat: number;
    lng: number;
    speedKmh: number | null;
    heading: number | null;
  } | null>(
    driverProfile?.current_lat != null && driverProfile?.current_lng != null
      ? {
          lat: driverProfile.current_lat,
          lng: driverProfile.current_lng,
          speedKmh: driverProfile.current_speed_kmh ?? null,
          heading: driverProfile.heading ?? null,
        }
      : null,
  );
  const [actionError, setActionError] = useState<string | null>(null);
  const [toggleBusy, setToggleBusy] = useState(false);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [photoBanner, setPhotoBanner] = useState<string | null>(null);

  const [earnings, setEarnings] = useState<{
    daily: { total: number; count: number };
    monthly: { total: number; count: number };
    reviews: Array<{
      id: string;
      driver_rating: number;
      driver_review: string | null;
      completed_at: string;
      customer_name: string;
    }>;
  }>({ daily: { total: 0, count: 0 }, monthly: { total: 0, count: 0 }, reviews: [] });
  const [history, setHistory] = useState<Ride[]>([]);
  const [notifications, setNotifications] = useState<RideNotification[]>([]);
  const [showNotifs, setShowNotifs] = useState(false);
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  // Categorized Support Form
  const [compCategory, setCompCategory] = useState<string>(COMPLAINT_CATEGORIES[0]);
  const [compSubject, setCompSubject] = useState('');
  const [compMsg, setCompMsg] = useState('');
  const [compRideId, setCompRideId] = useState('');
  const [compAttachmentUrl, setCompAttachmentUrl] = useState<string | null>(null);
  const [compSuccess, setCompSuccess] = useState<string | null>(null);

  // Driver -> Customer Mutual Rating Modal
  const [rateCustomerTarget, setRateCustomerTarget] = useState<Ride | null>(null);
  const [custStars, setCustStars] = useState(5);
  const [custReview, setCustReview] = useState('');

  // Chat / WebRTC signaling forwarding
  const [lastCommEvent, setLastCommEvent] = useState<CommWsPacket | null>(null);
  const commSeqRef = useRef(0);
  const wsRef = useRef<WebSocket | null>(null);
  const watchIdRef = useRef<number | null>(null);

  const sendWsSignal = useCallback((event: string, payload: Record<string, unknown>) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ event, payload }));
    }
  }, []);

  const loadDriverData = useCallback(async () => {
    if (!token) return;
    try {
      const [meRes, actRes, offRes, earnRes, histRes, notifRes, compRes, walRes] = await Promise.all([
        apiRequest<{
          user: User;
          driverProfile: DriverProfile;
          driverWallet?: DriverWallet;
          activeCommissionPercent?: number;
          requiresCommissionConsent?: boolean;
          needsTermsAcceptance?: boolean;
        }>('/api/auth/me', { token }),
        apiRequest<{ ride: Ride | null }>('/api/rides/active', { token }),
        apiRequest<{ offer: IncomingOffer | null }>('/api/driver/offers', { token }),
        apiRequest<typeof earnings>('/api/driver/earnings', { token }),
        apiRequest<{ rides: Ride[] }>('/api/rides/history', { token }),
        apiRequest<{ notifications: RideNotification[] }>('/api/notifications', { token }),
        apiRequest<{ complaints: Complaint[] }>('/api/complaints', { token }),
        apiRequest<{
          wallet: DriverWallet;
          transactions: WalletTransaction[];
          gateways: PaymentGatewayConfig[];
          commission_percent: number;
        }>('/api/driver/wallet', { token }),
      ]);
      onAuthSuccess(token, meRes.user, meRes.driverProfile);
      if (meRes.activeCommissionPercent != null) {
        setActiveCommissionPercent(meRes.activeCommissionPercent);
      }
      setRequiresCommissionConsent(Boolean(meRes.requiresCommissionConsent));
      if (meRes.needsTermsAcceptance) {
        setLegalModalMode('require_accept');
        setShowLegalModal(true);
      }
      setActiveRide(actRes.ride);
      setOffer(offRes.offer);
      setEarnings(earnRes);
      setHistory(histRes.rides);
      setNotifications(notifRes.notifications);
      setComplaints(compRes.complaints);
      setWallet(walRes.wallet);
      setWalletTxs(walRes.transactions);
      setTopupGateways(walRes.gateways);
    } catch {
      // resilient
    }
  }, [token]);

  useEffect(() => {
    if (!token || !user) return;
    requestNotificationPermission();
    loadDriverData();

    const ws = createSocketConnection(token, (event, payload) => {
      if (event === 'ride:offer') {
        const inc = payload as IncomingOffer;
        setOffer(inc);
        triggerBrowserNotification('لديك طلب رحلة جديد.', `${inc.ride.pickup_address} ← ${inc.ride.dropoff_address}`);
      } else if (event === 'ride:offer_expired') {
        setOffer(null);
      } else if (event === 'wallet:updated') {
        setWallet(payload as DriverWallet);
        loadDriverData();
      } else if (event === 'driver:commission_changed') {
        const data = payload as { commission_percent?: number };
        if (data?.commission_percent != null) {
          setActiveCommissionPercent(data.commission_percent);
          setRequiresCommissionConsent(true);
        }
        loadDriverData();
      } else if (event === 'ride:updated') {
        const r = payload as Ride;
        if (r.status === 'completed' || r.status === 'cancelled') {
          setActiveRide(null);
          setApproachGeometry([]);
          setRouteGeometry([]);
          loadDriverData();
          if (r.status === 'completed' && r.customer_rating == null) {
            setRateCustomerTarget(r);
          }
        } else {
          setActiveRide(r);
          setOffer(null);
        }
      } else if (event === 'notification:new') {
        const n = payload as RideNotification;
        setNotifications((prev) => [n, ...prev]);
        triggerBrowserNotification(n.title, n.body);
        if (n.type === 'admin_notice') {
          loadDriverData();
        }
      } else if (
        event === 'chat:message' ||
        event === 'call:incoming' ||
        event === 'call:offer' ||
        event === 'call:answer' ||
        event === 'call:ice' ||
        event === 'call:hangup' ||
        event === 'call:reject'
      ) {
        commSeqRef.current += 1;
        setLastCommEvent({
          seq: commSeqRef.current,
          event,
          payload: (payload || {}) as Record<string, unknown>,
        });
      }
    });
    wsRef.current = ws;

    return () => {
      ws.close();
      wsRef.current = null;
    };
  }, [token, user?.id]);

  useEffect(() => {
    if (!offer) {
      setOfferCountdown(0);
      return;
    }
    const tick = () => {
      const rem = Math.max(0, Math.ceil((Date.parse(offer.expires_at) - Date.now()) / 1000));
      setOfferCountdown(rem);
      if (rem === 0) setOffer(null);
    };
    tick();
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, [offer]);

  const shouldTrackGps = Boolean(
    token && driverProfile?.approval_status === 'approved' && (driverProfile.is_online === 1 || activeRide),
  );

  useEffect(() => {
    if (!shouldTrackGps || !token) {
      if (watchIdRef.current != null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setGpsStatus('idle');
      return;
    }

    if (!navigator.geolocation) {
      setGpsStatus('lost');
      return;
    }

    if (Capacitor.isNativePlatform()) {
      Geolocation.requestPermissions().catch(() => {});
    }

    let lastSentAt = 0;
    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        setGpsStatus('active');
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const speedMs = pos.coords.speed;
        const heading = pos.coords.heading;
        const now = Date.now();
        if (now - lastSentAt < 2500) return;
        lastSentAt = now;

        try {
          const res = await apiRequest<{ lat: number; lng: number; speed_kmh: number | null }>('/api/driver/location', {
            method: 'POST',
            token,
            body: { lat, lng, speedMs, heading, gpsAvailable: true },
          });
          setMyCoords({ lat, lng, speedKmh: res.speed_kmh, heading });
        } catch {
          // ignore transient rejections
        }
      },
      async () => {
        setGpsStatus('lost');
        setMyCoords((prev) => (prev ? { ...prev, speedKmh: null } : null));
        try {
          await apiRequest('/api/driver/location', {
            method: 'POST',
            token,
            body: { gpsAvailable: false },
          });
        } catch {
          // ignore
        }
      },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 },
    );

    watchIdRef.current = watchId;
    return () => {
      navigator.geolocation.clearWatch(watchId);
      watchIdRef.current = null;
    };
  }, [shouldTrackGps, token]);

  useEffect(() => {
    if (!activeRide) return;
    apiRequest<{ geometry: [number, number][] }>(
      `/api/maps/route?fromLat=${activeRide.pickup_lat}&fromLng=${activeRide.pickup_lng}&toLat=${activeRide.dropoff_lat}&toLng=${activeRide.dropoff_lng}`,
    )
      .then((r) => setRouteGeometry(r.geometry))
      .catch(() => {});

    if (myCoords && (activeRide.status === 'on_the_way' || activeRide.status === 'found')) {
      apiRequest<{ geometry: [number, number][] }>(
        `/api/maps/route?fromLat=${myCoords.lat}&fromLng=${myCoords.lng}&toLat=${activeRide.pickup_lat}&toLng=${activeRide.pickup_lng}`,
      )
        .then((r) => setApproachGeometry(r.geometry))
        .catch(() => {});
    } else {
      setApproachGeometry([]);
    }
  }, [activeRide?.id, activeRide?.status, myCoords?.lat, myCoords?.lng]);

  const handleToggleMishwar = async () => {
    if (!token || !driverProfile) return;
    setActionError(null);
    if (driverProfile.is_online === 1 && activeRide) {
      setActionError('لا يمكن إطفاء زر مشوار أثناء وجود رحلة نشطة');
      return;
    }

    const nextOnline = driverProfile.is_online !== 1;
    setToggleBusy(true);

    const sendToggle = async (lat?: number, lng?: number) => {
      try {
        const res = await apiRequest<{ driverProfile: DriverProfile }>('/api/driver/mishwar-toggle', {
          method: 'POST',
          token,
          body: { isOnline: nextOnline, lat, lng },
        });
        onProfileUpdate(res.driverProfile);
      } catch (err) {
        setActionError(err instanceof Error ? err.message : 'تعذر تغيير حالة مشوار');
      } finally {
        setToggleBusy(false);
      }
    };

    if (nextOnline && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setMyCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            speedKmh: pos.coords.speed != null ? Math.round(pos.coords.speed * 3.6) : null,
            heading: pos.coords.heading,
          });
          sendToggle(pos.coords.latitude, pos.coords.longitude);
        },
        () => sendToggle(),
        { enableHighAccuracy: true, timeout: 4000 },
      );
    } else {
      sendToggle();
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (authMode === 'register' && !acceptTerms) {
      setAuthError('يجب قراءة اتفاقية السائق والشروط والأحكام والموافقة عليها قبل التسجيل.');
      return;
    }
    setAuthBusy(true);
    try {
      const endpoint = authMode === 'login' ? '/api/auth/driver/login' : '/api/auth/driver/register';
      const body =
        authMode === 'login'
          ? { phone, password }
          : {
              name,
              phone,
              password,
              avatarUrl,
              carMake,
              carModel,
              carYear: Number(carYear),
              carColor,
              plateNumber,
              category,
              licenseDocUrl,
              registrationDocUrl,
              nationalIdDocUrl,
              acceptTerms: true,
            };
      const res = await apiRequest<{
        token: string;
        user: User;
        driverProfile: DriverProfile;
        needsTermsAcceptance?: boolean;
        activeCommissionPercent?: number;
        requiresCommissionConsent?: boolean;
      }>(endpoint, {
        method: 'POST',
        body,
      });
      if (res.activeCommissionPercent != null) setActiveCommissionPercent(res.activeCommissionPercent);
      setRequiresCommissionConsent(Boolean(res.requiresCommissionConsent));
      if (res.needsTermsAcceptance) {
        setLegalModalMode('require_accept');
        setShowLegalModal(true);
      }
      onAuthSuccess(res.token, res.user, res.driverProfile);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'فشل تسجيل الدخول');
    } finally {
      setAuthBusy(false);
    }
  };

  const handleAcceptTermsPostLogin = async () => {
    if (!token || !user || !driverProfile) return;
    setTermsBusy(true);
    try {
      const res = await apiRequest<{ user: User }>('/api/legal/accept-terms', {
        method: 'POST',
        token,
      });
      onAuthSuccess(token, res.user, driverProfile);
      setShowLegalModal(false);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر تسجيل الموافقة');
    } finally {
      setTermsBusy(false);
    }
  };

  const handleAcceptCommissionChange = async () => {
    if (!token || !user) return;
    setCommissionBusy(true);
    setActionError(null);
    try {
      const res = await apiRequest<{
        driverProfile: DriverProfile;
        activeCommissionPercent: number;
        requiresCommissionConsent: boolean;
      }>('/api/driver/commission/accept', { method: 'POST', token });
      onAuthSuccess(token, user, res.driverProfile);
      setActiveCommissionPercent(res.activeCommissionPercent);
      setRequiresCommissionConsent(res.requiresCommissionConsent);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر تسجيل الموافقة على العمولة');
    } finally {
      setCommissionBusy(false);
    }
  };

  const handleInitiateTopup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setTopupBusy(true);
    setTopupError(null);
    setTopupCheckoutUrl(null);
    try {
      const res = await apiRequest<{ checkoutUrl: string }>('/api/driver/wallet/topup/initiate', {
        method: 'POST',
        token,
        body: { provider: topupProvider, amountIqd: Number(topupAmount) },
      });
      setTopupCheckoutUrl(res.checkoutUrl);
      loadDriverData();
    } catch (err) {
      setTopupError(err instanceof Error ? err.message : 'تعذر بدء عملية الشحن عبر البوابة الرسمية');
    } finally {
      setTopupBusy(false);
    }
  };

  const handleCopyAccountNumber = () => {
    if (!user?.account_number) return;
    navigator.clipboard?.writeText(user.account_number).catch(() => {});
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 1800);
  };

  const handleUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    purpose: 'driver_avatar' | 'driver_doc',
    setter: (url: string) => void,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await uploadImageFile(file, purpose, token);
      setter(url);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'فشل رفع الصورة');
    }
  };

  const handleUpdatePersonalPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !token || !user) return;
    setPhotoBusy(true);
    setPhotoBanner(null);
    setActionError(null);
    try {
      const uploadedUrl = await uploadImageFile(file, 'driver_avatar', token);
      const res = await apiRequest<{ user: User; driverProfile: DriverProfile }>('/api/driver/photo', {
        method: 'PATCH',
        token,
        body: { avatarUrl: uploadedUrl },
      });
      onAuthSuccess(token, res.user, res.driverProfile);
      setPhotoBanner('تم حفظ الصورة الشخصية وإرسالها لمراجعة الإدارة.');
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر تحديث الصورة الشخصية');
    } finally {
      setPhotoBusy(false);
    }
  };

  const handleAcceptOffer = async () => {
    if (!token || !offer) return;
    setActionError(null);
    try {
      const res = await apiRequest<{ ride: Ride }>(`/api/driver/rides/${offer.ride.id}/accept`, {
        method: 'POST',
        token,
      });
      setOffer(null);
      setActiveRide(res.ride);
    } catch (err) {
      setOffer(null);
      setActionError(err instanceof Error ? err.message : 'تعذر قبول الرحلة');
    }
  };

  const handleRejectOffer = async () => {
    if (!token || !offer) return;
    const rideId = offer.ride.id;
    setOffer(null);
    await apiRequest(`/api/driver/rides/${rideId}/reject`, { method: 'POST', token }).catch(() => {});
  };

  const handleUpdateRideStatus = async (status: 'arrived' | 'in_progress' | 'completed') => {
    if (!token || !activeRide) return;
    setActionError(null);
    try {
      const res = await apiRequest<{ ride: Ride }>(`/api/driver/rides/${activeRide.id}/status`, {
        method: 'POST',
        token,
        body: { status },
      });
      if (status === 'completed') {
        setActiveRide(null);
        setRateCustomerTarget(res.ride);
        loadDriverData();
      } else {
        setActiveRide(res.ride);
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'تعذر تحديث حالة الرحلة');
    }
  };

  const handleSubmitCustomerRating = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !rateCustomerTarget) return;
    await apiRequest(`/api/rides/${rateCustomerTarget.id}/rate-customer`, {
      method: 'POST',
      token,
      body: { rating: custStars, review: custReview },
    });
    setRateCustomerTarget(null);
    setCustReview('');
    loadDriverData();
  };

  const openIssueReportForRide = (ride: Ride) => {
    setRateCustomerTarget(null);
    setCompRideId(ride.id);
    setCompCategory('مشكلة أثناء الرحلة');
    setCompSubject(`بلاغ سائق حول رحلة (${ride.pickup_address} ← ${ride.dropoff_address})`);
    setTab('support');
  };

  const activeTelemetry = useMemo(() => {
    if (!activeRide || !myCoords) return null;
    const targetLat = activeRide.status === 'in_progress' ? activeRide.dropoff_lat : activeRide.pickup_lat;
    const targetLng = activeRide.status === 'in_progress' ? activeRide.dropoff_lng : activeRide.pickup_lng;
    const remKm = haversineKmClient(myCoords.lat, myCoords.lng, targetLat, targetLng);
    const speed = myCoords.speedKmh && myCoords.speedKmh >= 8 ? myCoords.speedKmh : 30;
    return {
      remKm: remKm.toFixed(2),
      etaMin: Math.max(1, Math.round((remKm / speed) * 60)),
    };
  }, [activeRide, myCoords]);

  const unreadCount = notifications.filter((n) => n.is_read === 0).length;
  useEffect(() => {
    onUnreadCountChange?.(token && user && driverProfile ? unreadCount : 0);
  }, [token, user, driverProfile, unreadCount, onUnreadCountChange]);

  // ==================== LOGIN / REGISTER ====================
  if (!token || !user || !driverProfile) {
    return (
      <div className="max-w-2xl mx-auto my-8 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">تطبيق السائق — مشوار</h2>
            <p className="text-sm text-slate-500 mt-1">سجّل ككابتن وابدأ باستقبال الطلبات عند تفعيل زر مشوار</p>
          </div>
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => {
                setAuthMode('login');
                setAuthError(null);
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                authMode === 'login' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              دخول
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode('register');
                setAuthError(null);
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                authMode === 'register' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              تسجيل سائق جديد
            </button>
          </div>
        </div>

        {authError && (
          <div className="mb-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            {authError}
          </div>
        )}

        <form onSubmit={handleAuthSubmit} className="space-y-4">
          {authMode === 'register' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">الاسم الكامل</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">فئة السيارة</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as VehicleCategory)}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm bg-white"
                >
                  {(['Economy', 'Super', 'Plus', 'Family'] as VehicleCategory[]).map((c) => (
                    <option key={c} value={c}>
                      {c} — {CATEGORY_LABELS[c].ar}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">الشركة المصنعة</label>
                <input
                  type="text"
                  required
                  value={carMake}
                  onChange={(e) => setCarMake(e.target.value)}
                  placeholder="مثال: Hyundai / Kia / Toyota"
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">الموديل</label>
                <input
                  type="text"
                  required
                  value={carModel}
                  onChange={(e) => setCarModel(e.target.value)}
                  placeholder="مثال: Elantra"
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">سنة الصنع</label>
                <input
                  type="number"
                  required
                  min={2000}
                  max={2030}
                  value={carYear}
                  onChange={(e) => setCarYear(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">لون السيارة</label>
                <input
                  type="text"
                  required
                  value={carColor}
                  onChange={(e) => setCarColor(e.target.value)}
                  placeholder="مثال: أبيض"
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">رقم لوحة السيارة</label>
                <input
                  type="text"
                  required
                  value={plateNumber}
                  onChange={(e) => setPlateNumber(e.target.value)}
                  placeholder="مثال: بغداد 45123 أ"
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
                />
              </div>

              <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الصورة الشخصية الحقيقية {avatarUrl ? '✓' : '*'}
                  </label>
                  <input
                    type="file"
                    required
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(e) => handleUpload(e, 'driver_avatar', setAvatarUrl)}
                    className="text-xs text-slate-600 w-full"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    إجازة السوق {licenseDocUrl ? '✓' : '*'}
                  </label>
                  <input
                    type="file"
                    required
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(e) => handleUpload(e, 'driver_doc', setLicenseDocUrl)}
                    className="text-xs text-slate-600 w-full"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    السنوية (تسجيل المركبة) {registrationDocUrl ? '✓' : '*'}
                  </label>
                  <input
                    type="file"
                    required
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(e) => handleUpload(e, 'driver_doc', setRegistrationDocUrl)}
                    className="text-xs text-slate-600 w-full"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    البطاقة الوطنية {nationalIdDocUrl ? '✓' : '*'}
                  </label>
                  <input
                    type="file"
                    required
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(e) => handleUpload(e, 'driver_doc', setNationalIdDocUrl)}
                    className="text-xs text-slate-600 w-full"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">رقم الهاتف العراقي</label>
              <input
                type="tel"
                required
                dir="ltr"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0770 123 4567"
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm text-left font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">كلمة المرور</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
              />
            </div>
          </div>

          {authMode === 'register' && (
            <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 space-y-2 text-xs">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-blue-600"
                />
                <span className="text-slate-700 leading-relaxed">
                  أقرّ بأنني قرأت وفهمت وأوافق على{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setLegalModalMode('view');
                      setShowLegalModal(true);
                    }}
                    className="font-bold text-blue-600 hover:underline"
                  >
                    اتفاقية السائق والشروط والأحكام (20 بنداً) وسياسة الخصوصية
                  </button>{' '}
                  ونظام العمولات والرصيد الافتتاحي.
                </span>
              </label>
            </div>
          )}

          <button
            type="submit"
            disabled={authBusy}
            className="w-full rounded-xl bg-blue-600 py-3.5 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-60 transition-colors min-h-[48px]"
          >
            {authBusy ? 'جاري المعالجة...' : authMode === 'login' ? 'دخول الكابتن' : 'إرسال طلب الانضمام'}
          </button>
        </form>

        <LegalTermsModal
          open={showLegalModal}
          role="driver"
          requireConsent={false}
          onClose={() => setShowLegalModal(false)}
        />
      </div>
    );
  }

  const isOnline = driverProfile.is_online === 1;
  const displayAvatarUrl = driverProfile.pending_avatar_url || user.avatar_url;
  const totalWalletAvailable = wallet ? wallet.bonus_balance_iqd + wallet.real_balance_iqd : null;
  const isZeroBalancePaused = totalWalletAvailable !== null && totalWalletAvailable <= 0;

  // ==================== AUTHENTICATED DRIVER APP ====================
  return (
    <div className="max-w-7xl mx-auto px-4 py-4 pb-24 lg:pb-8">
      {/* Top Driver Bar */}
      <div className="flex items-center justify-between gap-4 bg-white border border-slate-200 rounded-2xl px-4 py-3 mb-4">
        <div className="flex items-center gap-3 min-w-0">
          <ProtectedImage
            src={displayAvatarUrl}
            token={token}
            alt={user.name}
            className="w-11 h-11 rounded-full object-cover border border-slate-200 shrink-0"
            fallback={
              <div className="w-11 h-11 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-bold shrink-0">
                {user.name.slice(0, 1)}
              </div>
            }
          />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold text-slate-900 text-sm truncate">{user.name}</span>
              {user.account_number && (
                <button
                  type="button"
                  onClick={handleCopyAccountNumber}
                  title="نسخ رقم حساب السائق"
                  className="inline-flex items-center gap-1 rounded-md bg-slate-100 border border-slate-200 px-2 py-0.5 font-mono text-[11px] font-bold text-slate-800 hover:bg-slate-200 whitespace-nowrap shrink-0"
                >
                  <span>{user.account_number}</span>
                  {copiedAccount ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                </button>
              )}
            </div>
            <div className="text-xs text-slate-500">
              {driverProfile.car_make} {driverProfile.car_model} · {driverProfile.plate_number} ·{' '}
              {CATEGORY_LABELS[driverProfile.category].ar}
            </div>
          </div>
        </div>

        <nav className="hidden lg:flex items-center gap-1.5">
          {[
            { id: 'drive', label: 'العمل والرحلة', icon: Car },
            {
              id: 'wallet',
              label: totalWalletAvailable != null ? `المحفظة (${formatIQD(totalWalletAvailable)})` : 'المحفظة',
              icon: Wallet,
            },
            { id: 'earnings', label: 'الأرباح والتقييمات', icon: DollarSign },
            { id: 'history', label: 'سجل الرحلات', icon: History },
            { id: 'support', label: 'الدعم والتظلّم', icon: HeadphonesIcon },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id as typeof tab)}
                className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  tab === item.id ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <SosModalButton
            token={token}
            rideId={activeRide?.id ?? null}
            currentCoords={myCoords ? { lat: myCoords.lat, lng: myCoords.lng } : null}
            compact
          />

          <button
            type="button"
            onClick={async () => {
              setShowNotifs((v) => !v);
              if (unreadCount > 0) {
                await apiRequest('/api/notifications/read-all', { method: 'POST', token });
                setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
              }
            }}
            className="relative min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -left-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 min-h-[44px]"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">خروج</span>
          </button>
        </div>
      </div>

      {/* Driver Personal Photo & Verification Card */}
      <div className="mb-4 bg-white border border-slate-200 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <ProtectedImage
            src={displayAvatarUrl}
            token={token}
            alt="صورة الكابتن الشخصية"
            className="w-12 h-12 rounded-full object-cover border border-slate-200 shrink-0"
            fallback={
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500 shrink-0">
                صورة
              </div>
            }
          />
          <div className="text-xs">
            <div className="font-bold text-slate-900">الصورة الشخصية للسائق</div>
            <div
              className={`mt-0.5 font-semibold ${
                driverProfile.photo_status === 'approved'
                  ? 'text-emerald-700'
                  : driverProfile.photo_status === 'rejected'
                    ? 'text-red-700'
                    : 'text-amber-700'
              }`}
            >
              {driverProfile.photo_status === 'approved' && 'معتمدة — تظهر للزبائن بعد قبول الرحلة'}
              {driverProfile.photo_status === 'pending' && 'قيد مراجعة الإدارة — لا تظهر للزبائن قبل الموافقة'}
              {driverProfile.photo_status === 'rejected' &&
                `مرفوضة: ${driverProfile.photo_rejection_reason || 'يرجى رفع صورة شخصية واضحة'}`}
            </div>
            {photoBanner && <div className="text-blue-700 mt-0.5">{photoBanner}</div>}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setLegalModalMode('view');
              setShowLegalModal(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50"
          >
            <FileText className="w-4 h-4 text-blue-600" />
            <span>اتفاقية السائق والخصوصية</span>
          </button>

          <label className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-800 hover:bg-slate-100 cursor-pointer">
            <Camera className="w-4 h-4 text-blue-600" />
            <span>{photoBusy ? 'جاري الرفع...' : 'تحديث الصورة من الهاتف'}</span>
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              disabled={photoBusy}
              onChange={handleUpdatePersonalPhoto}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {showNotifs && (
        <div className="mb-4 bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-slate-900 text-sm">إشعارات السائق والإدارة</h3>
            <button type="button" onClick={() => setShowNotifs(false)} className="text-slate-400">
              <X className="w-4 h-4" />
            </button>
          </div>
          {notifications.length === 0 ? (
            <p className="text-xs text-slate-500">لا توجد إشعارات.</p>
          ) : (
            <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
              {notifications.map((n) => (
                <div key={n.id} className="py-2">
                  <div className="text-xs font-bold text-slate-900">{n.title}</div>
                  <div className="text-xs text-slate-600">{n.body}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{formatDateTimeAr(n.created_at)}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* APPROVAL GATE + INTEGRATED GRIEVANCE/APPEAL FORM (CLAUSES 15 & 19) */}
      {driverProfile.approval_status !== 'approved' && (
        <div className="max-w-2xl mx-auto my-6 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center space-y-3">
            <AlertCircle
              className={`w-12 h-12 mx-auto ${
                driverProfile.approval_status === 'rejected' ? 'text-red-600' : 'text-amber-500'
              }`}
            />
            <h3 className="text-lg font-bold text-slate-900">
              {driverProfile.approval_status === 'rejected'
                ? 'تم رفض طلب التسجيل'
                : 'حسابك بانتظار موافقة الإدارة'}
            </h3>
            {user.account_number && (
              <div className="inline-flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-1 font-mono text-xs font-bold text-slate-800">
                <span>رقم حساب السائق: {user.account_number}</span>
              </div>
            )}
            <p className="text-sm text-slate-600">
              {driverProfile.approval_status === 'rejected'
                ? driverProfile.rejection_reason || 'يرجى مراجعة المستمسكات المرفوعة مع إدارة مشوار.'
                : 'يقوم فريق إدارة مشوار حالياً بمراجعة المستمسكات ومعلومات السيارة. فور الموافقة يُمنح حسابك رصيداً افتتاحياً مجانياً 10,000 د.ع ويظهر زر مشوار.'}
            </p>
            <button
              type="button"
              onClick={loadDriverData}
              className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-blue-700"
            >
              تحديث حالة الطلب
            </button>
          </div>

          {/* Direct Grievance / Appeal submission for non-approved / rejected drivers */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
            <h4 className="text-sm font-bold text-slate-900">تقديم تظلّم أو اعتراض إداري (البندان 15 و 19)</h4>
            {compSuccess && (
              <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs text-emerald-800">
                {compSuccess}
              </div>
            )}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setCompSuccess(null);
                await apiRequest('/api/complaints', {
                  method: 'POST',
                  token,
                  body: {
                    category: 'تظلّم / اعتراض إداري (إيقاف حساب / عمولة / محفظة)',
                    subject: compSubject || `اعتراض بخصوص حالة الحساب (${user.account_number})`,
                    message: compMsg,
                  },
                });
                setCompSubject('');
                setCompMsg('');
                setCompSuccess('تم إرسال التظلّم مع ربطه برقم حسابك للإدارة بنجاح.');
                loadDriverData();
              }}
              className="space-y-3"
            >
              <input
                type="text"
                required
                value={compSubject}
                onChange={(e) => setCompSubject(e.target.value)}
                placeholder="موضوع الاعتراض (مثال: طلب إعادة مراجعة المستمسكات أو القرار)"
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
              />
              <textarea
                required
                rows={3}
                value={compMsg}
                onChange={(e) => setCompMsg(e.target.value)}
                placeholder="اكتب تفاصيل التظلّم ليتم مراجعتها من الإدارة..."
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
              />
              <button type="submit" className="w-full rounded-xl bg-slate-900 py-2.5 text-xs font-bold text-white">
                إرسال التظلّم الإداري
              </button>
            </form>
          </div>
        </div>
      )}

      {/* CLAUSE 7 COMMISSION CONSENT BANNER (BLOCKS NEW OFFERS UNTIL ACCEPTED) */}
      {driverProfile.approval_status === 'approved' && requiresCommissionConsent && (
        <div className="mb-4 rounded-2xl border border-amber-300 bg-amber-50 p-4 space-y-3">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-6 h-6 text-amber-700 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-950 space-y-1">
              <div className="font-bold text-sm">
                إشعار تعديل نسبة عمولة مشوار (البند السابع من اتفاقية السائق)
              </div>
              <p className="leading-relaxed">
                قامت الإدارة بتحديث نسبة عمولة المنصة إلى{' '}
                <span className="font-mono font-bold text-base">{activeCommissionPercent}%</span>{' '}
                (نسبتك الموافق عليها سابقاً:{' '}
                <span className="font-mono font-bold">
                  {driverProfile.agreed_commission_percent ?? 'غير محددة'}%
                </span>
                ). يتوقف استقبال الطلبات الجديدة مؤقتاً حتى موافقتك على التعديل. الرحلة الجارية لا تتأثر.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={commissionBusy}
              onClick={handleAcceptCommissionChange}
              className="rounded-xl bg-amber-700 hover:bg-amber-800 px-4 py-2 text-xs font-bold text-white disabled:opacity-60"
            >
              {commissionBusy ? 'جاري التثبيت...' : `أوافق على نسبة العمولة الجديدة (${activeCommissionPercent}%)`}
            </button>
            <button
              type="button"
              onClick={() => {
                setCompCategory('تظلّم / اعتراض إداري (إيقاف حساب / عمولة / محفظة)');
                setCompSubject(`اعتراض على تعديل العمولة إلى ${activeCommissionPercent}%`);
                setTab('support');
              }}
              className="rounded-xl border border-amber-400 bg-white px-4 py-2 text-xs font-bold text-amber-900 hover:bg-amber-100"
            >
              تقديم تظلّم / اعتراض
            </button>
          </div>
        </div>
      )}

      {/* ZERO BALANCE AUTO-PAUSE ALERT */}
      {driverProfile.approval_status === 'approved' && isZeroBalancePaused && (
        <div className="mb-4 rounded-2xl border border-red-300 bg-red-50 p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5 text-xs text-red-900">
            <Wallet className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-sm">نفد رصيد المحفظة المتاح (0 د.ع) — تم إيقاف استقبال الطلبات الجديدة</div>
              <p className="mt-0.5">
                لن تتوقف أي رحلة جارية حالياً، ولن يصبح رصيدك سالباً. يرجى شحن المحفظة للاستمرار باستقبال الرحلات.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setTab('wallet')}
            className="rounded-xl bg-red-600 hover:bg-red-700 px-4 py-2 text-xs font-bold text-white shrink-0"
          >
            شحن المحفظة الآن
          </button>
        </div>
      )}

      {/* MAIN DRIVER CONSOLE */}
      {driverProfile.approval_status === 'approved' && tab === 'drive' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-5">
            {/* زر مشوار */}
            <div className="flex flex-col items-center text-center py-4 border-b border-slate-100">
              <button
                type="button"
                disabled={
                  toggleBusy ||
                  (isOnline && Boolean(activeRide)) ||
                  (!isOnline && (requiresCommissionConsent || isZeroBalancePaused))
                }
                onClick={handleToggleMishwar}
                className={`w-36 h-36 rounded-full flex flex-col items-center justify-center text-white shadow-lg transition-all active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed ${
                  isOnline
                    ? 'bg-[#2563EB] hover:bg-blue-700 shadow-blue-600/30'
                    : 'bg-[#64748B] hover:bg-slate-600 shadow-slate-500/20'
                }`}
              >
                {isOnline && activeRide ? <Lock className="w-8 h-8 mb-1.5" /> : <Power className="w-9 h-9 mb-1.5" />}
                <span className="text-xl font-extrabold font-display">مشوار</span>
              </button>

              <div className="mt-4">
                <div className={`text-base font-bold ${isOnline ? 'text-blue-700' : 'text-slate-600'}`}>
                  {isOnline ? 'مشوار يعمل' : 'مشوار متوقف'}
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {activeRide
                    ? 'لا يمكن إطفاء زر مشوار أثناء وجود رحلة نشطة'
                    : requiresCommissionConsent
                      ? 'يتطلب الموافقة على نسبة العمولة الجديدة أولاً'
                      : isZeroBalancePaused
                        ? 'يرجى شحن المحفظة لتفعيل زر مشوار'
                        : isOnline
                          ? 'أنت متاح الآن لاستقبال طلبات الزبائن القريبة'
                          : 'اضغط على زر مشوار للبدء في استقبال الرحلات'}
                </p>
              </div>

              <div className="mt-4 w-full grid grid-cols-2 gap-2 text-center">
                <div className="rounded-xl bg-slate-50 border border-slate-100 p-2.5">
                  <div className="text-[11px] text-slate-500">سرعتك الحالية</div>
                  <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                    {gpsStatus === 'lost' || myCoords?.speedKmh == null
                      ? 'غير متاح'
                      : `${myCoords.speedKmh} كم/س`}
                  </div>
                </div>
                <div className="rounded-xl bg-slate-50 border border-slate-100 p-2.5">
                  <div className="text-[11px] text-slate-500">إشارة GPS</div>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">
                    {gpsStatus === 'active'
                      ? 'متصل مباشر'
                      : gpsStatus === 'lost'
                        ? 'فقدان الإشارة'
                        : 'متوقف'}
                  </div>
                </div>
              </div>
            </div>

            {actionError && (
              <div className="rounded-xl bg-red-50 border border-red-200 p-3 text-xs text-red-700">
                {actionError}
              </div>
            )}

            {/* Active Ride Panel */}
            {activeRide ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs text-slate-500 flex items-center gap-2">
                      <span>الرحلة الجارية</span>
                      {activeRide.ride_number && (
                        <span className="font-mono font-bold text-slate-700">{activeRide.ride_number}</span>
                      )}
                    </div>
                    <div className="text-base font-bold text-blue-700">{RIDE_STATUS_LABELS[activeRide.status]}</div>
                  </div>
                  <div className="text-left">
                    <div className="font-mono font-bold text-slate-900">{formatIQD(activeRide.final_fare_iqd)}</div>
                    <div className="text-[11px] font-semibold text-slate-600">
                      {activeRide.payment_method !== 'electronic_pending'
                        ? PAYMENT_METHOD_LABELS[activeRide.payment_method]
                        : 'دفع إلكتروني'}
                      {activeRide.payment_status === 'paid' ? ' · مدفوعة إلكترونياً' : ''}
                    </div>
                  </div>
                </div>

                <div className="rounded-xl bg-slate-50 p-3.5 border border-slate-100 space-y-2 text-xs">
                  <div className="font-bold text-slate-900">
                    الزبون: {activeRide.customer_name}
                    {activeRide.customer_account_number ? (
                      <span className="font-mono font-normal text-slate-500 mr-2">
                        ({activeRide.customer_account_number})
                      </span>
                    ) : null}
                  </div>
                  <div>
                    <span className="text-slate-400">نقطة الانطلاق: </span>
                    <span className="font-semibold text-slate-800">{activeRide.pickup_address}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">الوجهة: </span>
                    <span className="font-semibold text-slate-800">{activeRide.dropoff_address}</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200 flex items-center gap-3 text-slate-600">
                    <span>المسافة الكلية: {activeRide.distance_km} كم</span>
                    {activeTelemetry && (
                      <>
                        <span>·</span>
                        <span>المتبقي: {activeTelemetry.remKm} كم ({activeTelemetry.etaMin} د)</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Inline Ride Chat & Masked Call */}
                <RideCommBar
                  rideId={activeRide.id}
                  token={token}
                  currentUserId={user.id}
                  currentRole="driver"
                  otherPartyLabel="الزبون"
                  otherPartyName={activeRide.customer_name || 'الزبون'}
                  otherPartyMaskedPhone={activeRide.customer_phone_masked}
                  incomingCommEvent={lastCommEvent}
                  sendWsSignal={sendWsSignal}
                />

                <div className="space-y-2">
                  {(activeRide.status === 'on_the_way' || activeRide.status === 'found') && (
                    <button
                      type="button"
                      onClick={() => handleUpdateRideStatus('arrived')}
                      className="w-full rounded-xl bg-blue-600 py-3.5 text-sm font-bold text-white hover:bg-blue-700 min-h-[48px]"
                    >
                      وصلت إلى الزبون
                    </button>
                  )}
                  {activeRide.status === 'arrived' && (
                    <div className="space-y-2">
                      <button
                        type="button"
                        onClick={() => handleUpdateRideStatus('in_progress')}
                        className="w-full rounded-xl bg-emerald-600 py-3.5 text-sm font-bold text-white hover:bg-emerald-700 min-h-[48px]"
                      >
                        بدء الرحلة
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          apiRequest(`/api/rides/${activeRide.id}/notify-waiting`, { method: 'POST', token }).catch(
                            () => {},
                          )
                        }
                        className="w-full rounded-xl border border-blue-200 bg-blue-50 py-2.5 text-xs font-bold text-blue-700"
                      >
                        إرسال تنبيه: أنا بانتظارك عند نقطة الانطلاق
                      </button>
                    </div>
                  )}
                  {activeRide.status === 'in_progress' && (
                    <button
                      type="button"
                      onClick={() => handleUpdateRideStatus('completed')}
                      className="w-full rounded-xl bg-slate-900 py-3.5 text-sm font-bold text-white hover:bg-slate-800 min-h-[48px]"
                    >
                      إنهاء الرحلة واستلام الأجرة ({formatIQD(activeRide.final_fare_iqd)})
                    </button>
                  )}

                  <SosModalButton
                    token={token}
                    rideId={activeRide.id}
                    currentCoords={myCoords ? { lat: myCoords.lat, lng: myCoords.lng } : null}
                  />

                  {activeRide.status !== 'in_progress' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await apiRequest(`/api/rides/${activeRide.id}/cancel`, {
                          method: 'POST',
                          token,
                          body: { reason: 'إلغاء من السائق' },
                        });
                        setActiveRide(null);
                        loadDriverData();
                      }}
                      className="w-full rounded-xl border border-red-200 bg-red-50 py-2.5 text-xs font-semibold text-red-700"
                    >
                      إلغاء الرحلة
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center text-xs text-slate-500 py-4">
                {isOnline
                  ? 'بانتظار إرسال أقرب طلب رحلة من النظام الذكي...'
                  : 'عند تفعيل زر مشوار ستصلك طلبات الرحلات تلقائياً هنا.'}
              </div>
            )}
          </div>

          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col min-h-[380px] lg:min-h-[580px]">
            <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span>الخريطة الحية وموقع الرحلة</span>
              </div>
              <span className="font-mono">التقييم: {driverProfile.rating_avg.toFixed(1)} ★</span>
            </div>
            <div className="flex-1 min-h-[340px]">
              <MishwarMap
                pickup={
                  activeRide
                    ? { lat: activeRide.pickup_lat, lng: activeRide.pickup_lng, label: activeRide.pickup_address }
                    : null
                }
                dropoff={
                  activeRide
                    ? { lat: activeRide.dropoff_lat, lng: activeRide.dropoff_lng, label: activeRide.dropoff_address }
                    : null
                }
                driverLocation={
                  myCoords ? { lat: myCoords.lat, lng: myCoords.lng, heading: myCoords.heading } : null
                }
                routeGeometry={routeGeometry}
                driverToPickupGeometry={approachGeometry}
              />
            </div>
          </div>
        </div>
      )}

      {/* DRIVER WALLET & TOP-UP */}
      {driverProfile.approval_status === 'approved' && tab === 'wallet' && wallet && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">الرصيد الافتتاحي المجاني المتبقي</div>
              <div className="text-2xl font-bold font-mono text-indigo-700 mt-1 tabular-nums">
                {formatIQD(wallet.bonus_balance_iqd)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                رصيد سماح افتراضي للعمل — غير قابل للسحب أو التحويل
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">الرصيد الحقيقي (شحن وأرباح إلكترونية)</div>
              <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
                {formatIQD(wallet.real_balance_iqd)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                إجمالي الشحن المؤكد: {formatIQD(wallet.total_topped_up_iqd)}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">إجمالي الرصيد المتاح للعمل</div>
              <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                {formatIQD(wallet.bonus_balance_iqd + wallet.real_balance_iqd)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                نسبة العمولة الحالية: <span className="font-mono font-bold">{activeCommissionPercent}%</span>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">إجمالي عمولات مشوار المخصومة</div>
              <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
                {formatIQD(wallet.total_commission_iqd)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                أرباح إلكترونية مضافة: {formatIQD(wallet.total_electronic_earnings_iqd)}
              </div>
            </div>
          </div>

          {/* Electronic Wallet Top-Up */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <span>شحن محفظة السائق إلكترونياً</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  يُضاف المبلغ للرصيد الحقيقي تلقائياً بعد تأكيد الدفع الرسمي ويعيد تفعيل استقبال الرحلات فوراً.
                </p>
              </div>
            </div>

            <form onSubmit={handleInitiateTopup} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
              <div className="md:col-span-5">
                <label className="block text-xs font-medium text-slate-700 mb-1">بوابة الدفع الرسمية</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['superqi', 'zaincash'] as const).map((prov) => {
                    const g = topupGateways.find((x) => x.provider === prov);
                    const avail = Boolean(g?.available);
                    return (
                      <button
                        key={prov}
                        type="button"
                        onClick={() => setTopupProvider(prov)}
                        className={`rounded-xl border p-2.5 text-right text-xs transition-colors ${
                          topupProvider === prov
                            ? 'border-blue-600 bg-blue-50 text-blue-900'
                            : 'border-slate-200 bg-white text-slate-700'
                        }`}
                      >
                        <div className="font-bold">{PAYMENT_METHOD_LABELS[prov]}</div>
                        <div className={`text-[11px] mt-0.5 ${avail ? 'text-emerald-700' : 'text-amber-700'}`}>
                          {avail ? 'متاح ومفعل' : g?.unavailable_reason_ar || 'بانتظار اعتماد التاجر'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="md:col-span-4">
                <label className="block text-xs font-medium text-slate-700 mb-1">مبلغ الشحن (د.ع)</label>
                <input
                  type="number"
                  min={1000}
                  step={1000}
                  required
                  value={topupAmount}
                  onChange={(e) => setTopupAmount(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm font-mono"
                />
              </div>

              <div className="md:col-span-3">
                <button
                  type="submit"
                  disabled={
                    topupBusy || !topupGateways.find((g) => g.provider === topupProvider)?.available
                  }
                  className="w-full rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 py-2.5 px-4 text-xs font-bold text-white min-h-[42px]"
                >
                  {topupBusy ? 'جاري التحويل...' : 'شحن المحفظة الآن'}
                </button>
              </div>
            </form>

            {topupError && (
              <div className="rounded-xl bg-red-50 border border-red-200 p-3 text-xs text-red-700">{topupError}</div>
            )}

            {topupCheckoutUrl && (
              <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="font-bold text-emerald-900">
                  تم إنشاء فاتورة الشحن بنجاح. اضغط لإتمام الدفع عبر البوابة الرسمية:
                </span>
                <a
                  href={topupCheckoutUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-700 px-4 py-2 font-bold text-white hover:bg-emerald-800"
                >
                  <span>الانتقال لبوابة الدفع</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            )}
          </div>

          {/* Wallet Ledger */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <h3 className="text-base font-bold text-slate-900 mb-3">سجل حركات المحفظة والعمولات</h3>
            {walletTxs.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 text-center">لا توجد حركات مسجلة في المحفظة بعد.</p>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {walletTxs.map((tx) => (
                  <div key={tx.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-slate-900">
                        {tx.note}
                        {tx.ride_number ? (
                          <span className="font-mono text-blue-700 mr-2">({tx.ride_number})</span>
                        ) : null}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {formatDateTimeAr(tx.created_at)} · الرصيد بعد الحركة: سماح {formatIQD(tx.bonus_after_iqd)} / حقيقي{' '}
                        {formatIQD(tx.real_after_iqd)}
                      </div>
                    </div>
                    <div className="text-left font-mono font-bold shrink-0">
                      {tx.bonus_delta_iqd !== 0 && (
                        <div className={tx.bonus_delta_iqd > 0 ? 'text-indigo-700' : 'text-red-700'}>
                          سماح: {tx.bonus_delta_iqd > 0 ? `+${formatIQD(tx.bonus_delta_iqd)}` : formatIQD(tx.bonus_delta_iqd)}
                        </div>
                      )}
                      {tx.real_delta_iqd !== 0 && (
                        <div className={tx.real_delta_iqd > 0 ? 'text-emerald-700' : 'text-red-700'}>
                          حقيقي: {tx.real_delta_iqd > 0 ? `+${formatIQD(tx.real_delta_iqd)}` : formatIQD(tx.real_delta_iqd)}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* EARNINGS & REVIEWS */}
      {driverProfile.approval_status === 'approved' && tab === 'earnings' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">أرباح اليوم</div>
              <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                {formatIQD(earnings.daily.total)}
              </div>
              <div className="text-xs text-slate-500 mt-1">{earnings.daily.count} رحلة مكتملة</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">أرباح الشهر</div>
              <div className="text-2xl font-bold font-mono text-blue-700 mt-1 tabular-nums">
                {formatIQD(earnings.monthly.total)}
              </div>
              <div className="text-xs text-slate-500 mt-1">{earnings.monthly.count} رحلة مكتملة</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl p-5">
              <div className="text-xs text-slate-500">متوسط تقييم الزبائن</div>
              <div className="text-2xl font-bold font-mono text-amber-600 mt-1 tabular-nums">
                {driverProfile.rating_avg.toFixed(2)} ★
              </div>
              <div className="text-xs text-slate-500 mt-1">{driverProfile.rating_count} تقييم</div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <h3 className="text-base font-bold text-slate-900 mb-3">تقييمات وملاحظات الزبائن</h3>
            {earnings.reviews.length === 0 ? (
              <p className="text-xs text-slate-500 py-4">لا توجد تقييمات بعد.</p>
            ) : (
              <div className="divide-y divide-slate-100">
                {earnings.reviews.map((rev) => (
                  <div key={rev.id} className="py-3 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-bold text-slate-900">{rev.customer_name}</div>
                      <div className="text-xs text-slate-600 mt-0.5">{rev.driver_review || 'بدون تعليق نصي'}</div>
                    </div>
                    <div className="text-xs font-bold text-amber-600 shrink-0">{rev.driver_rating} / 5 ★</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* HISTORY */}
      {driverProfile.approval_status === 'approved' && tab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <h3 className="text-base font-bold text-slate-900 mb-3">سجل رحلات السائق</h3>
          {history.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">لا توجد رحلات مسجلة.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {history.map((r) => (
                <div key={r.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                      {r.ride_number && <span className="font-mono font-bold text-slate-700">{r.ride_number}</span>}
                      <span>{RIDE_STATUS_LABELS[r.status]}</span>
                      <span>·</span>
                      <span>
                        {r.payment_method !== 'electronic_pending'
                          ? PAYMENT_METHOD_LABELS[r.payment_method]
                          : 'دفع إلكتروني'}
                      </span>
                      <span>·</span>
                      <span>{formatDateTimeAr(r.created_at)}</span>
                    </div>
                    <div className="text-sm font-bold text-slate-900">
                      {r.pickup_address} ← {r.dropoff_address}
                    </div>
                    <div className="text-xs text-slate-500">
                      الزبون: {r.customer_name} · {r.distance_km} كم
                      {(r.commission_iqd ?? 0) > 0 ? ` · عمولة مشوار: ${formatIQD(r.commission_iqd ?? 0)}` : ''}
                    </div>
                  </div>
                  <div className="text-left shrink-0 space-y-1">
                    <div className="font-mono font-bold text-slate-900 text-sm">{formatIQD(r.final_fare_iqd)}</div>
                    {r.status === 'completed' && r.customer_rating == null && (
                      <div>
                        <button
                          type="button"
                          onClick={() => setRateCustomerTarget(r)}
                          className="text-xs font-semibold text-blue-600 hover:underline"
                        >
                          تقييم الزبون
                        </button>
                      </div>
                    )}
                    {r.customer_rating != null && (
                      <div className="text-xs font-semibold text-amber-600">تقييمك للزبون: {r.customer_rating} / 5</div>
                    )}
                    <div>
                      <button
                        type="button"
                        onClick={() => openIssueReportForRide(r)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600 hover:underline"
                      >
                        <Flag className="w-3 h-3" />
                        <span>الإبلاغ عن مشكلة</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUPPORT */}
      {driverProfile.approval_status === 'approved' && tab === 'support' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <h3 className="text-base font-bold text-slate-900 mb-3">تقديم شكوى أو التواصل مع الإدارة</h3>
            {compSuccess && (
              <div className="mb-3 rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs text-emerald-800">
                {compSuccess}
              </div>
            )}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setCompSuccess(null);
                await apiRequest('/api/complaints', {
                  method: 'POST',
                  token,
                  body: {
                    category: compCategory,
                    subject: compSubject,
                    message: compMsg,
                    rideId: compRideId || undefined,
                    attachmentUrl: compAttachmentUrl,
                  },
                });
                setCompSubject('');
                setCompMsg('');
                setCompRideId('');
                setCompAttachmentUrl(null);
                setCompSuccess('تم إرسال البلاغ للإدارة بنجاح');
                loadDriverData();
              }}
              className="space-y-3"
            >
              <select
                value={compCategory}
                onChange={(e) => setCompCategory(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-xs bg-white"
              >
                {COMPLAINT_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <input
                type="text"
                required
                value={compSubject}
                onChange={(e) => setCompSubject(e.target.value)}
                placeholder="العنوان"
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-xs"
              />
              <select
                value={compRideId}
                onChange={(e) => setCompRideId(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-xs bg-white"
              >
                <option value="">غير مرتبطة برحلة محددة</option>
                {history.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.pickup_address} ← {r.dropoff_address} ({formatIQD(r.final_fare_iqd)})
                  </option>
                ))}
              </select>
              <textarea
                required
                rows={4}
                value={compMsg}
                onChange={(e) => setCompMsg(e.target.value)}
                placeholder="تفاصيل الملاحظة أو الشكوى..."
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-xs"
              />
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  إرفاق صورة (اختياري) {compAttachmentUrl ? '✓' : ''}
                </label>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    const url = await uploadImageFile(f, 'complaint_attachment', token);
                    setCompAttachmentUrl(url);
                  }}
                  className="text-xs text-slate-600"
                />
              </div>
              <button type="submit" className="w-full rounded-xl bg-blue-600 py-3 text-xs font-bold text-white">
                إرسال
              </button>
            </form>
          </div>
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <h3 className="text-base font-bold text-slate-900 mb-3">الرسائل والشكاوى السابقة</h3>
            <div className="divide-y divide-slate-100">
              {complaints.map((c) => (
                <div key={c.id} className="py-2.5 text-xs space-y-1">
                  <div className="font-bold text-slate-900">
                    [{c.category}] {c.subject}
                  </div>
                  <div className="text-slate-600">{c.message}</div>
                  {c.attachment_url && (
                    <ProtectedImage
                      src={c.attachment_url}
                      token={token}
                      alt="مرفق"
                      className="w-24 h-16 rounded-lg object-cover border border-slate-200"
                    />
                  )}
                  {c.admin_reply && <div className="mt-1 text-blue-700 font-semibold">الرد: {c.admin_reply}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* INCOMING RIDE REQUEST MODAL */}
      {offer && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">طلب رحلة جديد</h3>
              <span className="font-mono text-sm font-bold text-blue-700">{offerCountdown} ث</span>
            </div>
            <div className="rounded-xl bg-slate-50 p-4 space-y-2 text-xs border border-slate-100">
              {offer.ride.ride_number && (
                <div className="font-mono font-bold text-blue-700">رقم الرحلة: {offer.ride.ride_number}</div>
              )}
              <div>
                <span className="text-slate-400">الزبون: </span>
                <span className="font-bold text-slate-900">{offer.ride.customer_name}</span>
              </div>
              <div>
                <span className="text-slate-400">الانطلاق: </span>
                <span className="font-semibold text-slate-800">{offer.ride.pickup_address}</span>
              </div>
              <div>
                <span className="text-slate-400">الوجهة: </span>
                <span className="font-semibold text-slate-800">{offer.ride.dropoff_address}</span>
              </div>
              <div>
                <span className="text-slate-400">طريقة الدفع: </span>
                <span className="font-bold text-slate-900">
                  {offer.ride.payment_method !== 'electronic_pending'
                    ? PAYMENT_METHOD_LABELS[offer.ride.payment_method]
                    : 'دفع إلكتروني'}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between font-bold">
                <span>المسافة: {offer.ride.distance_km} كم</span>
                <span className="font-mono text-base text-blue-700">{formatIQD(offer.ride.final_fare_iqd)}</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleAcceptOffer}
                className="rounded-xl bg-blue-600 py-3.5 text-sm font-bold text-white hover:bg-blue-700 min-h-[48px]"
              >
                قبول الرحلة
              </button>
              <button
                type="button"
                onClick={handleRejectOffer}
                className="rounded-xl border border-slate-300 bg-white py-3.5 text-sm font-bold text-slate-700 hover:bg-slate-50 min-h-[48px]"
              >
                رفض
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DRIVER -> CUSTOMER MUTUAL RATING MODAL */}
      {rateCustomerTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <form
            onSubmit={handleSubmitCustomerRating}
            className="w-full max-w-md rounded-2xl bg-white p-6 border border-slate-200 shadow-xl space-y-4"
          >
            <h3 className="text-lg font-bold text-slate-900">تقييم الزبون: {rateCustomerTarget.customer_name}</h3>
            <p className="text-xs text-slate-500">
              انتهت الرحلة إلى {rateCustomerTarget.dropoff_address}. المبلغ المستلم: {formatIQD(rateCustomerTarget.final_fare_iqd)}
            </p>
            <div className="flex items-center justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button key={star} type="button" onClick={() => setCustStars(star)} className="p-2">
                  <Star
                    className={`w-8 h-8 ${star <= custStars ? 'fill-amber-400 text-amber-500' : 'text-slate-300'}`}
                  />
                </button>
              ))}
            </div>
            <textarea
              rows={3}
              value={custReview}
              onChange={(e) => setCustReview(e.target.value)}
              placeholder="ملاحظاتك عن الزبون (اختياري)"
              className="w-full rounded-xl border border-slate-300 p-3 text-xs"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 rounded-xl bg-blue-600 py-3 text-xs font-bold text-white hover:bg-blue-700"
              >
                حفظ التقييم
              </button>
              <button
                type="button"
                onClick={() => setRateCustomerTarget(null)}
                className="rounded-xl border border-slate-200 px-4 py-3 text-xs font-semibold text-slate-600"
              >
                لاحقاً
              </button>
            </div>
            <button
              type="button"
              onClick={() => openIssueReportForRide(rateCustomerTarget)}
              className="w-full text-center text-xs font-semibold text-red-600 hover:underline pt-1"
            >
              هل واجهت مشكلة؟ الإبلاغ عن مشكلة في هذه الرحلة
            </button>
          </form>
        </div>
      )}

      {/* DRIVER LEGAL TERMS MODAL (VIEWER & MANDATORY UPDATE) */}
      <LegalTermsModal
        open={showLegalModal}
        role="driver"
        requireConsent={legalModalMode === 'require_accept'}
        busy={termsBusy}
        onAccept={legalModalMode === 'require_accept' ? handleAcceptTermsPostLogin : undefined}
        onClose={() => setShowLegalModal(false)}
      />

      {/* MOBILE BOTTOM BAR */}
      {driverProfile.approval_status === 'approved' && (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-5 h-16 pb-safe">
          {[
            { id: 'drive', label: 'مشوار', icon: Power },
            { id: 'wallet', label: 'المحفظة', icon: Wallet },
            { id: 'earnings', label: 'الأرباح', icon: DollarSign },
            { id: 'history', label: 'الرحلات', icon: Clock },
            { id: 'support', label: 'الدعم', icon: HeadphonesIcon },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id as typeof tab)}
                className={`flex flex-col items-center justify-center min-h-[44px] whitespace-nowrap shrink-0 ${
                  tab === item.id ? 'text-blue-600' : 'text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-semibold mt-0.5">{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
