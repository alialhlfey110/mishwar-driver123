import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { db } from './db.ts';
import { sendToAdmins } from './dispatch.ts';

export type SecuritySeverity = 'low' | 'medium' | 'high' | 'critical';

export function recordSecurityEvent(params: {
  severity: SecuritySeverity;
  eventType: string;
  actorUserId?: string | null;
  ipAddress?: string | null;
  summary: string;
  details?: Record<string, unknown>;
}) {
  const id = crypto.randomUUID();
  const created_at = new Date().toISOString();
  db.prepare(
    `INSERT INTO security_events (id, severity, event_type, actor_user_id, ip_address, summary, details, is_resolved, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`,
  ).run(
    id,
    params.severity,
    params.eventType,
    params.actorUserId ?? null,
    params.ipAddress ?? null,
    params.summary,
    params.details ? JSON.stringify(params.details) : null,
    created_at,
  );

  if (params.severity === 'high' || params.severity === 'critical') {
    sendToAdmins('admin:security_alert', {
      id,
      severity: params.severity,
      event_type: params.eventType,
      summary: params.summary,
      ip_address: params.ipAddress ?? null,
      created_at,
    });
  }
}

// ==================== SECURITY HEADERS ====================
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-XSS-Protection', '0');
  res.setHeader('Permissions-Policy', 'geolocation=(self), camera=(), microphone=(self)');
  if (req.path.startsWith('/api/')) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
  }
  next();
}

// ==================== API & LOGIN RATE LIMITERS ====================
interface RateEntry {
  count: number;
  resetAt: number;
}
const apiBuckets = new Map<string, RateEntry>();

export function apiRateLimiter(maxPerMin = 240) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    const current = apiBuckets.get(key);
    if (!current || current.resetAt <= now) {
      apiBuckets.set(key, { count: 1, resetAt: now + 60_000 });
      next();
      return;
    }
    current.count += 1;
    if (current.count > maxPerMin) {
      res.status(429).json({ error: 'تم تجاوز الحد المسموح من الطلبات. يرجى الانتظار دقيقة.' });
      return;
    }
    next();
  };
}

interface LoginAttemptState {
  failures: number;
  lockedUntil: number;
}
const loginAttempts = new Map<string, LoginAttemptState>();
const MAX_LOGIN_FAILURES = 5;
const LOCKOUT_MS = 5 * 60 * 1000;

export function getLoginAttemptKey(ip: string | undefined, identifier: string): string {
  return `${ip || 'unknown'}:${identifier.toLowerCase()}`;
}

export function checkLoginLockout(key: string): { locked: boolean; retryAfterSec: number } {
  const entry = loginAttempts.get(key);
  if (!entry) return { locked: false, retryAfterSec: 0 };
  const now = Date.now();
  if (entry.lockedUntil > now) {
    return { locked: true, retryAfterSec: Math.ceil((entry.lockedUntil - now) / 1000) };
  }
  if (entry.lockedUntil > 0 && entry.lockedUntil <= now) {
    loginAttempts.delete(key);
  }
  return { locked: false, retryAfterSec: 0 };
}

export function registerLoginFailure(key: string, ip: string | undefined, identifier: string) {
  const now = Date.now();
  const entry = loginAttempts.get(key) ?? { failures: 0, lockedUntil: 0 };
  entry.failures += 1;
  if (entry.failures >= MAX_LOGIN_FAILURES) {
    entry.lockedUntil = now + LOCKOUT_MS;
    recordSecurityEvent({
      severity: 'high',
      eventType: 'brute_force_lockout',
      ipAddress: ip,
      summary: `تم قفل محاولات تسجيل الدخول مؤقتاً بسبب ${entry.failures} محاولات فاشلة متتالية`,
      details: { identifier, failures: entry.failures },
    });
  } else {
    recordSecurityEvent({
      severity: 'low',
      eventType: 'login_failed',
      ipAddress: ip,
      summary: `محاولة تسجيل دخول فاشلة (${entry.failures}/${MAX_LOGIN_FAILURES})`,
      details: { identifier },
    });
  }
  loginAttempts.set(key, entry);
}

export function clearLoginFailures(key: string) {
  loginAttempts.delete(key);
}

export function resetSecurityRateLimitsForTests() {
  loginAttempts.clear();
  apiBuckets.clear();
}

// ==================== AES-256-GCM SENSITIVE DATA ENCRYPTION ====================
const EPHEMERAL_ENC_SECRET = crypto.randomBytes(32).toString('hex');

function getEncryptionKeyBuffer(): Buffer {
  const secret = process.env.DATA_ENCRYPTION_KEY?.trim() || EPHEMERAL_ENC_SECRET;
  return crypto.createHash('sha256').update(secret).digest();
}

export function encryptSensitiveBuffer(plain: Buffer): Buffer {
  const key = getEncryptionKeyBuffer();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plain), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([Buffer.from('MSW1'), iv, tag, encrypted]);
}

export function decryptSensitiveBuffer(payload: Buffer): Buffer {
  if (payload.subarray(0, 4).toString('ascii') !== 'MSW1') {
    throw new Error('صيغة البيانات المشفرة غير صالحة');
  }
  const key = getEncryptionKeyBuffer();
  const iv = payload.subarray(4, 16);
  const tag = payload.subarray(16, 32);
  const data = payload.subarray(32);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]);
}

// ==================== AUTOMATED SQLITE BACKUPS ====================
const BACKUPS_DIR = path.resolve(process.cwd(), 'data', 'backups');
fs.mkdirSync(BACKUPS_DIR, { recursive: true });

export async function createDatabaseBackup(triggerType: 'startup' | 'scheduled' | 'manual') {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const rawName = `mishwar-backup-${stamp}.db`;
  const rawPath = path.resolve(BACKUPS_DIR, rawName);

  await db.backup(rawPath);
  const rawBytes = fs.readFileSync(rawPath);
  const sha256 = crypto.createHash('sha256').update(rawBytes).digest('hex');

  let finalFilename = rawName;
  let finalSize = rawBytes.length;
  let encryptedFlag = 0;

  if (process.env.DATA_ENCRYPTION_KEY?.trim()) {
    const encBytes = encryptSensitiveBuffer(rawBytes);
    finalFilename = `${rawName}.enc`;
    fs.writeFileSync(path.resolve(BACKUPS_DIR, finalFilename), encBytes);
    fs.unlinkSync(rawPath);
    finalSize = encBytes.length;
    encryptedFlag = 1;
  }

  const id = crypto.randomUUID();
  const created_at = new Date().toISOString();
  db.prepare(
    `INSERT INTO backup_records (id, filename, size_bytes, sha256, encrypted, trigger_type, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(id, finalFilename, finalSize, sha256, encryptedFlag, triggerType, created_at);

  // Prune old backups beyond 10
  const old = db
    .prepare('SELECT id, filename FROM backup_records ORDER BY created_at DESC LIMIT -1 OFFSET 10')
    .all() as Array<{ id: string; filename: string }>;
  for (const b of old) {
    const p = path.resolve(BACKUPS_DIR, b.filename);
    if (p.startsWith(BACKUPS_DIR + path.sep) && fs.existsSync(p)) {
      fs.unlinkSync(p);
    }
    db.prepare('DELETE FROM backup_records WHERE id = ?').run(b.id);
  }

  return { id, filename: finalFilename, size_bytes: finalSize, sha256, encrypted: encryptedFlag, trigger_type: triggerType, created_at };
}

let backupIntervalStarted = false;
export function startPeriodicBackups() {
  if (backupIntervalStarted) return;
  backupIntervalStarted = true;
  // Run initial backup shortly after startup, then every 6 hours
  setTimeout(() => {
    createDatabaseBackup('startup').catch(() => {});
  }, 5000);
  setInterval(() => {
    createDatabaseBackup('scheduled').catch(() => {});
  }, 6 * 60 * 60 * 1000);
}
