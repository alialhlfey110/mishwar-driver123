import crypto from 'crypto';
import { db, writeAuditLog } from './db.ts';
import { createNotification, sendToAdmins, sendToUser } from './dispatch.ts';
import { recordSecurityEvent } from './security.ts';
import type { Ride, RideMessage } from '../src/types/mishwar.ts';

export function maskIraqiPhone(phone: string | null | undefined): string {
  if (!phone) return '';
  const digits = phone.replace(/\s+/g, '');
  if (digits.length < 6) return '***';
  return `${digits.slice(0, 7)} *** **${digits.slice(-2)}`;
}

export function assertRideChatParticipant(
  rideId: string,
  userId: string,
  requireActive = false,
): { ok: true; ride: Ride; role: 'customer' | 'driver'; otherUserId: string } | { ok: false; status: number; error: string } {
  const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(rideId) as Ride | undefined;
  if (!ride) {
    return { ok: false, status: 404, error: 'الرحلة غير موجودة' };
  }

  const isCustomer = ride.customer_id === userId;
  const isDriver = ride.driver_id === userId;
  if (!isCustomer && !isDriver) {
    recordSecurityEvent({
      severity: 'high',
      eventType: 'unauthorized_chat_access',
      actorUserId: userId,
      summary: `محاولة وصول غير مصرح به لمحادثة الرحلة ${rideId}`,
    });
    return { ok: false, status: 403, error: 'التواصل متاح فقط لأطراف هذه الرحلة' };
  }

  if (!ride.driver_id) {
    return { ok: false, status: 400, error: 'لم يتم تعيين سائق للرحلة بعد' };
  }

  if (requireActive && (ride.status === 'completed' || ride.status === 'cancelled')) {
    return { ok: false, status: 409, error: 'تم إغلاق المحادثة بعد انتهاء الرحلة' };
  }

  return {
    ok: true,
    ride,
    role: isCustomer ? 'customer' : 'driver',
    otherUserId: isCustomer ? ride.driver_id : ride.customer_id,
  };
}

export function listRideMessages(rideId: string): RideMessage[] {
  return db
    .prepare(
      `SELECT m.*, u.name AS sender_name
       FROM ride_messages m
       JOIN users u ON u.id = m.sender_id
       WHERE m.ride_id = ?
       ORDER BY m.created_at ASC`,
    )
    .all(rideId) as RideMessage[];
}

export function sendRideMessage(params: {
  rideId: string;
  senderId: string;
  senderRole: 'customer' | 'driver';
  otherUserId: string;
  body: string;
}): RideMessage {
  const cleanBody = params.body.trim().slice(0, 600);
  const id = crypto.randomUUID();
  const created_at = new Date().toISOString();

  db.prepare(
    `INSERT INTO ride_messages (id, ride_id, sender_id, sender_role, body, is_reported, created_at)
     VALUES (?, ?, ?, ?, ?, 0, ?)`,
  ).run(id, params.rideId, params.senderId, params.senderRole, cleanBody, created_at);

  const sender = db.prepare('SELECT name FROM users WHERE id = ?').get(params.senderId) as { name: string };
  const msg: RideMessage = {
    id,
    ride_id: params.rideId,
    sender_id: params.senderId,
    sender_role: params.senderRole,
    sender_name: sender?.name,
    body: cleanBody,
    is_reported: 0,
    created_at,
  };

  sendToUser(params.senderId, 'chat:message', msg);
  sendToUser(params.otherUserId, 'chat:message', msg);

  createNotification({
    userId: params.otherUserId,
    title: `رسالة جديدة من ${params.senderRole === 'driver' ? 'السائق' : 'الزبون'}`,
    body: cleanBody,
    type: 'chat_message',
    rideId: params.rideId,
  });

  return msg;
}

export function reportRideMessage(params: {
  rideId: string;
  messageId: string;
  reporterId: string;
  reason: string;
}) {
  const msg = db
    .prepare('SELECT * FROM ride_messages WHERE id = ? AND ride_id = ?')
    .get(params.messageId, params.rideId) as RideMessage | undefined;
  if (!msg) {
    throw new Error('الرسالة غير موجودة');
  }
  if (msg.sender_id === params.reporterId) {
    throw new Error('لا يمكنك الإبلاغ عن رسالتك الخاصة');
  }

  const reportId = crypto.randomUUID();
  const now = new Date().toISOString();
  const tx = db.transaction(() => {
    db.prepare('UPDATE ride_messages SET is_reported = 1 WHERE id = ?').run(msg.id);
    db.prepare(
      `INSERT INTO message_reports (id, ride_id, message_id, reporter_id, reported_user_id, message_body, reason, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?)`,
    ).run(reportId, params.rideId, msg.id, params.reporterId, msg.sender_id, msg.body, params.reason.trim().slice(0, 200), now);
  });
  tx();

  writeAuditLog({
    actorUserId: params.reporterId,
    actorRole: 'participant',
    action: 'chat.message_reported',
    targetType: 'message_report',
    targetId: reportId,
    details: { rideId: params.rideId, messageId: msg.id, reason: params.reason },
  });

  sendToAdmins('admin:message_report', { id: reportId, rideId: params.rideId, reason: params.reason });
  return reportId;
}

/**
 * Policy confirmed by owner:
 * Automatically purge all unflagged chat messages immediately when a ride ends or is cancelled,
 * retaining ONLY messages that were reported for administrative moderation.
 */
export function closeAndPurgeRideChat(rideId: string): number {
  const res = db
    .prepare('DELETE FROM ride_messages WHERE ride_id = ? AND is_reported = 0')
    .run(rideId);

  sendToUser(
    (db.prepare('SELECT customer_id FROM rides WHERE id = ?').get(rideId) as { customer_id?: string })?.customer_id || '',
    'chat:closed',
    { ride_id: rideId },
  );
  const drv = db.prepare('SELECT driver_id FROM rides WHERE id = ?').get(rideId) as { driver_id?: string | null };
  if (drv?.driver_id) {
    sendToUser(drv.driver_id, 'chat:closed', { ride_id: rideId });
  }
  return res.changes;
}

/**
 * Pluggable Masked Call Bridge:
 * Uses zero-cost WebRTC in-app masked audio by default.
 * Ready for external paid PSTN masked proxy (e.g. Twilio Proxy) when configured in env later.
 */
export function getMaskedCallCapabilities() {
  const pstnConfigured = Boolean(process.env.MASKED_CALL_PROVIDER_KEY?.trim());
  return {
    activeMode: pstnConfigured ? ('pstn_bridge' as const) : ('webrtc_masked' as const),
    pstnConfigured,
    privacyProtected: true,
  };
}

export function startMaskedCallSession(params: {
  rideId: string;
  callerId: string;
  calleeId: string;
}) {
  const caps = getMaskedCallCapabilities();
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO call_sessions (id, ride_id, caller_id, callee_id, mode, status, started_at)
     VALUES (?, ?, ?, ?, ?, 'ringing', ?)`,
  ).run(id, params.rideId, params.callerId, params.calleeId, caps.activeMode, now);

  return { id, mode: caps.activeMode, started_at: now };
}

export function endMaskedCallSession(callId: string) {
  db.prepare(`UPDATE call_sessions SET status = 'ended', ended_at = ? WHERE id = ?`).run(
    new Date().toISOString(),
    callId,
  );
}
