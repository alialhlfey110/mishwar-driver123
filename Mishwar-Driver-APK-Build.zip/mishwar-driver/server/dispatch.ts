import crypto from 'crypto';
import type { WebSocket } from 'ws';
import { db, writeAuditLog } from './db.ts';
import { haversineKm } from './geo.ts';
import { DRIVER_TERMS_VERSION } from '../src/legal/agreements.ts';
import type {
  AppSettings,
  FareEstimate,
  PlusSettings,
  PricingRules,
  PromoCode,
  Ride,
  UserRole,
  VehicleCategory,
} from '../src/types/mishwar.ts';

interface ClientSocket {
  ws: WebSocket;
  userId: string;
  role: UserRole;
}

const activeSockets = new Set<ClientSocket>();

export function registerSocket(ws: WebSocket, userId: string, role: UserRole) {
  const entry: ClientSocket = { ws, userId, role };
  activeSockets.add(entry);
  ws.on('close', () => {
    activeSockets.delete(entry);
  });
}

export function sendToUser(userId: string, event: string, payload: unknown) {
  const msg = JSON.stringify({ event, payload });
  for (const client of activeSockets) {
    if (client.userId === userId && client.ws.readyState === 1) {
      client.ws.send(msg);
    }
  }
}

export function sendToAdmins(event: string, payload: unknown) {
  const msg = JSON.stringify({ event, payload });
  for (const client of activeSockets) {
    if (client.role === 'admin' && client.ws.readyState === 1) {
      client.ws.send(msg);
    }
  }
}

export function createNotification(params: {
  userId: string;
  title: string;
  body: string;
  type: string;
  rideId?: string | null;
}) {
  const id = crypto.randomUUID();
  const created_at = new Date().toISOString();
  db.prepare(`
    INSERT INTO notifications (id, user_id, title, body, type, ride_id, is_read, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 0, ?)
  `).run(id, params.userId, params.title, params.body, params.type, params.rideId ?? null, created_at);

  sendToUser(params.userId, 'notification:new', {
    id,
    user_id: params.userId,
    title: params.title,
    body: params.body,
    type: params.type,
    ride_id: params.rideId ?? null,
    is_read: 0,
    created_at,
  });
}

function maskPhoneLocal(phone: string | null | undefined): string {
  if (!phone) return '';
  const digits = phone.replace(/\s+/g, '');
  if (digits.length < 6) return '***';
  return `${digits.slice(0, 7)} *** **${digits.slice(-2)}`;
}

export function triggerRideMilestone(rideId: string, milestone: string): boolean {
  const res = db
    .prepare(
      `INSERT OR IGNORE INTO ride_notification_milestones (ride_id, milestone, created_at)
       VALUES (?, ?, ?)`,
    )
    .run(rideId, milestone, new Date().toISOString());
  return res.changes > 0;
}

export function hasActivePlusSubscription(userId: string): boolean {
  const now = new Date().toISOString();
  const sub = db
    .prepare(
      `SELECT id FROM plus_subscriptions
       WHERE user_id = ? AND status = 'active' AND starts_at <= ? AND ends_at >= ?
       LIMIT 1`,
    )
    .get(userId, now, now) as { id: string } | undefined;
  return Boolean(sub);
}

export function calculateFareServer(params: {
  customerId: string;
  category: VehicleCategory;
  distanceKm: number;
  durationMin: number;
  promoCode?: string | null;
}): FareEstimate {
  const pricing = db.prepare('SELECT * FROM pricing_rules WHERE id = 1').get() as PricingRules;
  const plusSettings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get() as PlusSettings;

  const multMap: Record<VehicleCategory, number> = {
    Economy: pricing.economy_multiplier,
    Super: pricing.super_multiplier,
    Plus: pricing.plus_multiplier,
    Family: pricing.family_multiplier,
  };
  const multiplier = multMap[params.category] ?? 1.0;

  const round250 = (val: number) => Math.round(val / 250) * 250;
  const baseFare = round250(pricing.base_fare_iqd * multiplier);
  const distanceFare = round250(params.distanceKm * pricing.per_km_iqd * multiplier);
  const rawSubtotal = Math.max(round250(pricing.min_fare_iqd * multiplier), baseFare + distanceFare);

  let discount = 0;
  let plusApplied = false;
  let promoApplied: string | null = null;

  if (plusSettings.is_enabled === 1 && hasActivePlusSubscription(params.customerId)) {
    const plusDisc = Math.round((rawSubtotal * plusSettings.discount_percent) / 100);
    discount += plusDisc;
    plusApplied = true;
  }

  if (params.promoCode && params.promoCode.trim()) {
    const codeUpper = params.promoCode.trim().toUpperCase();
    const promo = db
      .prepare('SELECT * FROM promo_codes WHERE UPPER(code) = ? AND is_active = 1')
      .get(codeUpper) as PromoCode | undefined;
    const now = new Date().toISOString();
    if (promo && (!promo.expires_at || promo.expires_at >= now)) {
      const promoDisc = Math.min(
        promo.max_discount_iqd,
        Math.round((rawSubtotal * promo.discount_percent) / 100),
      );
      discount += promoDisc;
      promoApplied = promo.code;
    }
  }

  const finalFare = Math.max(1000, round250(Math.max(0, rawSubtotal - discount)));

  return {
    category: params.category,
    distance_km: params.distanceKm,
    duration_min: params.durationMin,
    base_fare_iqd: baseFare,
    distance_fare_iqd: distanceFare,
    subtotal_iqd: rawSubtotal,
    discount_iqd: discount,
    final_fare_iqd: finalFare,
    plus_applied: plusApplied,
    promo_applied: promoApplied,
  };
}

export function getEnrichedRide(rideId: string, includeRawPhones = false): Ride | null {
  const row = db
    .prepare(
      `SELECT r.*,
              cu.name AS customer_name, cu.account_number AS customer_account_number, cu.phone AS raw_customer_phone, cu.avatar_url AS customer_avatar,
              du.name AS driver_name, du.account_number AS driver_account_number, du.phone AS raw_driver_phone, du.avatar_url AS raw_driver_avatar,
              dp.photo_status AS driver_photo_status,
              dp.car_make, dp.car_model, dp.car_year, dp.car_color, dp.plate_number,
              dp.rating_avg AS driver_rating_avg,
              dp.current_lat AS driver_lat, dp.current_lng AS driver_lng,
              dp.current_speed_kmh AS driver_speed_kmh, dp.heading AS driver_heading
       FROM rides r
       JOIN users cu ON cu.id = r.customer_id
       LEFT JOIN users du ON du.id = r.driver_id
       LEFT JOIN driver_profiles dp ON dp.user_id = r.driver_id
       WHERE r.id = ?`,
    )
    .get(rideId) as
    | (Ride & {
        raw_customer_phone?: string | null;
        raw_driver_phone?: string | null;
        raw_driver_avatar?: string | null;
        driver_photo_status?: string | null;
      })
    | undefined;

  if (!row) return null;

  const canShowDriverPhoto = Boolean(
    row.driver_id &&
      row.status !== 'searching' &&
      row.status !== 'cancelled' &&
      row.driver_photo_status === 'approved' &&
      row.raw_driver_avatar,
  );

  const {
    raw_customer_phone,
    raw_driver_phone,
    raw_driver_avatar,
    driver_photo_status: _dps,
    ...rest
  } = row;

  const result: Ride = {
    ...rest,
    customer_phone_masked: maskPhoneLocal(raw_customer_phone),
    driver_phone_masked: maskPhoneLocal(raw_driver_phone),
    driver_avatar: canShowDriverPhoto ? (raw_driver_avatar ?? null) : null,
  };

  if (includeRawPhones) {
    result.customer_phone = raw_customer_phone ?? undefined;
    result.driver_phone = raw_driver_phone ?? undefined;
  }

  return result;
}

export function broadcastRideUpdate(ride: Ride) {
  const sanitized = getEnrichedRide(ride.id, false) ?? ride;
  sendToUser(sanitized.customer_id, 'ride:updated', sanitized);
  if (sanitized.driver_id) {
    sendToUser(sanitized.driver_id, 'ride:updated', sanitized);
  }
  const adminRide = getEnrichedRide(ride.id, true) ?? sanitized;
  sendToAdmins('ride:updated', adminRide);
}

/**
 * Smart automated ride dispatch engine:
 * Selects best available driver strictly within requested category, proximity, rating,
 * and Admin-configured PLUS priority rule. Never exposes car choice or driver photo to customer beforehand.
 */
export function dispatchNextDriver(rideId: string): boolean {
  const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(rideId) as Ride | undefined;
  if (!ride || ride.status !== 'searching') return false;

  const settings = db.prepare('SELECT * FROM app_settings WHERE id = 1').get() as AppSettings;
  const plusSettings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get() as PlusSettings;
  const customerHasPlus = hasActivePlusSubscription(ride.customer_id);
  const usePriority = plusSettings.is_enabled === 1 && plusSettings.priority_matching_enabled === 1 && customerHasPlus;

  const candidates = db
    .prepare(
      `SELECT dp.user_id, dp.current_lat, dp.current_lng, dp.rating_avg
       FROM driver_profiles dp
       JOIN users u ON u.id = dp.user_id
       JOIN driver_wallets dw ON dw.driver_id = dp.user_id
       JOIN pricing_rules pr ON pr.id = 1
       WHERE u.status = 'active'
         AND dp.approval_status = 'approved'
         AND dp.is_online = 1
         AND u.terms_accepted_version = ?
         AND dp.agreed_commission_percent IS NOT NULL
         AND dp.agreed_commission_percent = pr.commission_percent
         AND (dw.bonus_balance_iqd + dw.real_balance_iqd) > 0
         AND dp.category = ?
         AND dp.user_id NOT IN (
           SELECT driver_id FROM rides
           WHERE driver_id IS NOT NULL
             AND status IN ('found', 'on_the_way', 'arrived', 'in_progress')
         )
         AND dp.user_id NOT IN (
           SELECT driver_id FROM ride_dispatch_attempts
           WHERE ride_id = ?
         )`,
    )
    .all(DRIVER_TERMS_VERSION, ride.category, rideId) as Array<{
    user_id: string;
    current_lat: number | null;
    current_lng: number | null;
    rating_avg: number;
  }>;

  const ranked = candidates
    .map((c) => {
      const distKm =
        c.current_lat != null && c.current_lng != null
          ? haversineKm(ride.pickup_lat, ride.pickup_lng, c.current_lat, c.current_lng)
          : 5.0; // If driver just went online and GPS fix is pending, place in fallback range
      return { ...c, distKm };
    })
    .filter((c) => c.distKm <= settings.search_radius_km)
    .sort((a, b) => {
      if (usePriority) {
        const scoreA = a.distKm - a.rating_avg * 0.4;
        const scoreB = b.distKm - b.rating_avg * 0.4;
        return scoreA - scoreB;
      }
      if (Math.abs(a.distKm - b.distKm) > 0.3) return a.distKm - b.distKm;
      return b.rating_avg - a.rating_avg;
    });

  if (ranked.length === 0) {
    sendToUser(ride.customer_id, 'ride:no_drivers', {
      ride_id: ride.id,
      message: 'لا يوجد سائق متاح في منطقتك حالياً لهذه الفئة',
    });
    return false;
  }

  const chosen = ranked[0];
  const now = new Date();
  const expires = new Date(now.getTime() + settings.dispatch_timeout_sec * 1000);
  const attemptId = crypto.randomUUID();

  db.prepare(
    `INSERT INTO ride_dispatch_attempts (id, ride_id, driver_id, status, offered_at, expires_at)
     VALUES (?, ?, ?, 'offered', ?, ?)`,
  ).run(attemptId, ride.id, chosen.user_id, now.toISOString(), expires.toISOString());

  const enriched = getEnrichedRide(ride.id, false);
  sendToUser(chosen.user_id, 'ride:offer', {
    attempt_id: attemptId,
    ride: enriched,
    distance_to_pickup_km: Number(chosen.distKm.toFixed(2)),
    expires_at: expires.toISOString(),
    timeout_sec: settings.dispatch_timeout_sec,
  });

  createNotification({
    userId: chosen.user_id,
    title: 'لديك طلب رحلة جديد.',
    body: `طلب ${ride.category} من ${ride.pickup_address} إلى ${ride.dropoff_address} (${ride.final_fare_iqd.toLocaleString()} د.ع)`,
    type: 'driver_offer',
    rideId: ride.id,
  });

  return true;
}

export function acceptRideAtomic(rideId: string, driverId: string): { ok: boolean; error?: string; ride?: Ride } {
  const tx = db.transaction(() => {
    const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(rideId) as Ride | undefined;
    if (!ride) return { ok: false, error: 'الرحلة غير موجودة' };
    if (ride.status !== 'searching' || ride.driver_id) {
      return { ok: false, error: 'عذراً، تم قبول هذه الرحلة من سائق آخر أو تم إلغاؤها' };
    }

    const driver = db
      .prepare(
        `SELECT dp.approval_status, dp.is_online, dp.category, dp.agreed_commission_percent,
                u.terms_accepted_version, u.status AS user_status
         FROM driver_profiles dp
         JOIN users u ON u.id = dp.user_id
         WHERE dp.user_id = ?`,
      )
      .get(driverId) as
      | {
          approval_status: string;
          is_online: number;
          category: string;
          agreed_commission_percent: number | null;
          terms_accepted_version: string | null;
          user_status: string;
        }
      | undefined;
    if (!driver || driver.user_status !== 'active' || driver.approval_status !== 'approved' || driver.is_online !== 1) {
      return { ok: false, error: 'يجب أن يكون حسابك مفعلاً وزر مشوار يعمل لقبول الرحلات' };
    }
    if (driver.terms_accepted_version !== DRIVER_TERMS_VERSION) {
      return { ok: false, error: 'يرجى قراءة والموافقة على اتفاقية السائق المحدّثة قبل قبول الطلبات' };
    }
    const activePricing = db.prepare('SELECT commission_percent FROM pricing_rules WHERE id = 1').get() as
      | { commission_percent: number }
      | undefined;
    const activePct = Number(activePricing?.commission_percent ?? 10);
    if (driver.agreed_commission_percent === null || Math.abs(driver.agreed_commission_percent - activePct) > 0.0001) {
      return {
        ok: false,
        error: `تم تعديل نسبة عمولة مشوار إلى ${activePct}% — يجب الموافقة على التعديل أولاً قبل استقبال طلبات جديدة`,
      };
    }
    const wallet = db
      .prepare('SELECT bonus_balance_iqd, real_balance_iqd FROM driver_wallets WHERE driver_id = ?')
      .get(driverId) as { bonus_balance_iqd: number; real_balance_iqd: number } | undefined;
    if (!wallet || wallet.bonus_balance_iqd + wallet.real_balance_iqd <= 0) {
      return { ok: false, error: 'نفد رصيد محفظتك — يرجى شحن المحفظة لاستقبال الطلبات' };
    }
    if (driver.category !== ride.category) {
      return { ok: false, error: 'فئة سيارتك لا تطابق الفئة المطلوبة' };
    }

    const activeOther = db
      .prepare(
        `SELECT id FROM rides
         WHERE driver_id = ? AND status IN ('found', 'on_the_way', 'arrived', 'in_progress')`,
      )
      .get(driverId) as { id: string } | undefined;
    if (activeOther) {
      return { ok: false, error: 'لديك رحلة نشطة حالياً ولا يمكنك قبول رحلة أخرى' };
    }

    const now = new Date().toISOString();
    const res = db
      .prepare(
        `UPDATE rides SET driver_id = ?, status = 'on_the_way', accepted_at = ?
         WHERE id = ? AND status = 'searching' AND driver_id IS NULL`,
      )
      .run(driverId, now, rideId);

    if (res.changes === 0) {
      return { ok: false, error: 'تم تخصيص الرحلة بالفعل لسائق آخر' };
    }

    db.prepare(
      `UPDATE ride_dispatch_attempts SET status = 'accepted', responded_at = ?
       WHERE ride_id = ? AND driver_id = ? AND status = 'offered'`,
    ).run(now, rideId, driverId);

    db.prepare(
      `UPDATE ride_dispatch_attempts SET status = 'timeout', responded_at = ?
       WHERE ride_id = ? AND driver_id != ? AND status = 'offered'`,
    ).run(now, rideId, driverId);

    return { ok: true };
  });

  const result = tx.immediate();
  if (!result.ok) return result;

  const updated = getEnrichedRide(rideId, false)!;
  broadcastRideUpdate(updated);

  if (triggerRideMilestone(updated.id, 'customer_accepted')) {
    createNotification({
      userId: updated.customer_id,
      title: 'تم قبول رحلتك.',
      body: `الكابتن ${updated.driver_name} قبل طلبك (${updated.car_make} ${updated.car_model} - ${updated.car_color})`,
      type: 'ride_accepted',
      rideId: updated.id,
    });
  }

  if (triggerRideMilestone(updated.id, 'customer_driver_on_the_way')) {
    createNotification({
      userId: updated.customer_id,
      title: 'السائق في طريقه إليك.',
      body: `الكابتن ${updated.driver_name} متجه الآن إلى نقطة الانطلاق.`,
      type: 'driver_on_the_way',
      rideId: updated.id,
    });
  }

  if (triggerRideMilestone(updated.id, 'driver_accepted')) {
    createNotification({
      userId: driverId,
      title: 'تم قبول الرحلة.',
      body: `توجه إلى نقطة الانطلاق: ${updated.pickup_address}`,
      type: 'ride_confirmed',
      rideId: updated.id,
    });
  }

  writeAuditLog({
    actorUserId: driverId,
    actorRole: 'driver',
    action: 'ride.accepted',
    targetType: 'ride',
    targetId: rideId,
  });

  return { ok: true, ride: updated };
}

let dispatchTimerStarted = false;
export function startDispatchSweepTimer() {
  if (dispatchTimerStarted) return;
  dispatchTimerStarted = true;

  setInterval(() => {
    try {
      const nowMs = Date.now();
      const now = new Date(nowMs).toISOString();
      const expired = db
        .prepare(
          `SELECT a.id, a.ride_id, a.driver_id
           FROM ride_dispatch_attempts a
           JOIN rides r ON r.id = a.ride_id
           WHERE a.status = 'offered' AND a.expires_at <= ? AND r.status = 'searching'`,
        )
        .all(now) as Array<{ id: string; ride_id: string; driver_id: string }>;

      for (const item of expired) {
        db.prepare(
          `UPDATE ride_dispatch_attempts SET status = 'timeout', responded_at = ? WHERE id = ?`,
        ).run(now, item.id);
        sendToUser(item.driver_id, 'ride:offer_expired', {
          attempt_id: item.id,
          ride_id: item.ride_id,
        });
        dispatchNextDriver(item.ride_id);
      }

      // Auto-emit Customer Notification #7 ("السائق ينتظرك.") 60 seconds after arrival if ride hasn't started
      const waitingThreshold = new Date(nowMs - 60_000).toISOString();
      const arrivedRides = db
        .prepare(
          `SELECT id, customer_id FROM rides
           WHERE status = 'arrived' AND arrived_at IS NOT NULL AND arrived_at <= ?`,
        )
        .all(waitingThreshold) as Array<{ id: string; customer_id: string }>;

      for (const r of arrivedRides) {
        if (triggerRideMilestone(r.id, 'customer_driver_waiting')) {
          createNotification({
            userId: r.customer_id,
            title: 'السائق ينتظرك.',
            body: 'الكابتن بانتظارك في نقطة الانطلاق.',
            type: 'driver_waiting',
            rideId: r.id,
          });
        }
      }
    } catch {
      // Keep interval resilient
    }
  }, 1000);
}
