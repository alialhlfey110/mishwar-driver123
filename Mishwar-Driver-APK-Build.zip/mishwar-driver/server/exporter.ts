import { execFileSync } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';

export type StandaloneProjectTarget = 'customer' | 'driver' | 'admin';

interface StandaloneSpec {
  target: StandaloneProjectTarget;
  packageName: string;
  title: string;
  shortName: string;
  description: string;
  themeColor: string;
  capacitorAppId: string;
  components: string[];
  appTsx: string;
  readmeAr: string;
}

const CUSTOMER_APP_TSX = `import React, { useCallback, useEffect, useState } from 'react';
import { CustomerApp } from './components/CustomerApp';
import { CustomerAppLogo } from './components/CustomerAppLogo';
import { OfflineIndicator, PWAInstallBanner, PWAInstallButton } from './components/PWAInstallButton';
import { TripShareView } from './components/TripShareView';
import { apiRequest } from './lib/api';
import type { User } from './types/mishwar';

const DEFAULT_DOCUMENT_TITLE = 'MISHWAR – مشوار | تطبيق الزبون';

export default function App() {
  const shareToken =
    typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('share') : null;

  if (shareToken && shareToken.trim().length >= 16) {
    return <TripShareView shareToken={shareToken.trim()} />;
  }

  const [auth, setAuth] = useState<{ token: string | null; user: User | null }>({
    token: null,
    user: null,
  });
  const [unreadCount, setUnreadCount] = useState(0);

  const handleUnreadCount = useCallback((count: number) => {
    setUnreadCount((prev) => (prev === count ? prev : count));
  }, []);

  useEffect(() => {
    document.title = unreadCount > 0 ? \`(\${unreadCount}) MISHWAR – مشوار\` : DEFAULT_DOCUMENT_TITLE;
    const nav = navigator as Navigator & {
      setAppBadge?: (contents?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    if (unreadCount > 0) {
      nav.setAppBadge?.(unreadCount).catch(() => {});
    } else {
      nav.clearAppBadge?.().catch(() => {});
    }
  }, [unreadCount]);

  const handleLogout = async () => {
    if (auth.token) {
      await apiRequest('/api/auth/logout', { method: 'POST', token: auth.token }).catch(() => {});
    }
    setUnreadCount(0);
    setAuth({ token: null, user: null });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-lg font-extrabold font-display text-slate-900 whitespace-nowrap shrink-0">
            <CustomerAppLogo className="w-9 h-9 shrink-0" />
            <span>مشوار — تطبيق الزبون</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
          </div>
        </div>
      </header>

      <PWAInstallBanner />

      <div className="flex-1">
        <CustomerApp
          token={auth.token}
          user={auth.user}
          onAuthSuccess={(token, user) => setAuth({ token, user })}
          onLogout={handleLogout}
          onUnreadCountChange={handleUnreadCount}
        />
      </div>

      <OfflineIndicator />
    </div>
  );
}
`;

const DRIVER_APP_TSX = `import React, { useCallback, useEffect, useState } from 'react';
import { DriverApp } from './components/DriverApp';
import { OfflineIndicator, PWAInstallBanner, PWAInstallButton } from './components/PWAInstallButton';
import { apiRequest } from './lib/api';
import type { DriverProfile, User } from './types/mishwar';

const DEFAULT_DOCUMENT_TITLE = 'MISHWAR – كابتن مشوار | تطبيق السائق';

export default function App() {
  const [auth, setAuth] = useState<{
    token: string | null;
    user: User | null;
    profile: DriverProfile | null;
  }>({
    token: null,
    user: null,
    profile: null,
  });
  const [unreadCount, setUnreadCount] = useState(0);

  const handleUnreadCount = useCallback((count: number) => {
    setUnreadCount((prev) => (prev === count ? prev : count));
  }, []);

  useEffect(() => {
    document.title = unreadCount > 0 ? \`(\${unreadCount}) كابتن مشوار – السائق\` : DEFAULT_DOCUMENT_TITLE;
    const nav = navigator as Navigator & {
      setAppBadge?: (contents?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    if (unreadCount > 0) {
      nav.setAppBadge?.(unreadCount).catch(() => {});
    } else {
      nav.clearAppBadge?.().catch(() => {});
    }
  }, [unreadCount]);

  const handleLogout = async () => {
    if (auth.token) {
      await apiRequest('/api/auth/logout', { method: 'POST', token: auth.token }).catch(() => {});
    }
    setUnreadCount(0);
    setAuth({ token: null, user: null, profile: null });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-lg font-extrabold font-display text-slate-900 whitespace-nowrap shrink-0">
            <img
              src="/src/assets/images/mishwar_brand_mark_1795221944568.jpg"
              alt="شعار مشوار"
              className="w-8 h-8 rounded-lg object-cover"
              referrerPolicy="no-referrer"
            />
            <span>كابتن مشوار — السائق</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
          </div>
        </div>
      </header>

      <PWAInstallBanner />

      <div className="flex-1">
        <DriverApp
          token={auth.token}
          user={auth.user}
          driverProfile={auth.profile}
          onAuthSuccess={(token, user, profile) => setAuth({ token, user, profile })}
          onProfileUpdate={(profile) => setAuth((prev) => ({ ...prev, profile }))}
          onLogout={handleLogout}
          onUnreadCountChange={handleUnreadCount}
        />
      </div>

      <OfflineIndicator />
    </div>
  );
}
`;

const ADMIN_APP_TSX = `import React, { useCallback, useEffect, useState } from 'react';
import { AdminDashboard } from './components/AdminDashboard';
import { OfflineIndicator, PWAInstallBanner, PWAInstallButton } from './components/PWAInstallButton';
import { apiRequest } from './lib/api';
import type { User } from './types/mishwar';

const DEFAULT_DOCUMENT_TITLE = 'MISHWAR – إدارة مشوار | لوحة التحكم';

export default function App() {
  const [auth, setAuth] = useState<{ token: string | null; user: User | null }>({
    token: null,
    user: null,
  });
  const [alertCount, setAlertCount] = useState(0);

  const handleAlertCount = useCallback((count: number) => {
    setAlertCount((prev) => (prev === count ? prev : count));
  }, []);

  useEffect(() => {
    document.title = alertCount > 0 ? \`(\${alertCount}) إدارة مشوار\` : DEFAULT_DOCUMENT_TITLE;
    const nav = navigator as Navigator & {
      setAppBadge?: (contents?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    if (alertCount > 0) {
      nav.setAppBadge?.(alertCount).catch(() => {});
    } else {
      nav.clearAppBadge?.().catch(() => {});
    }
  }, [alertCount]);

  const handleLogout = async () => {
    if (auth.token) {
      await apiRequest('/api/auth/logout', { method: 'POST', token: auth.token }).catch(() => {});
    }
    setAlertCount(0);
    setAuth({ token: null, user: null });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-lg font-extrabold font-display text-slate-900 whitespace-nowrap shrink-0">
            <img
              src="/src/assets/images/mishwar_brand_mark_1795221944568.jpg"
              alt="شعار مشوار"
              className="w-8 h-8 rounded-lg object-cover"
              referrerPolicy="no-referrer"
            />
            <span>إدارة مشوار — لوحة التحكم</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
          </div>
        </div>
      </header>

      <PWAInstallBanner />

      <div className="flex-1">
        <AdminDashboard
          token={auth.token}
          user={auth.user}
          onAuthSuccess={(token, user) => setAuth({ token, user })}
          onLogout={handleLogout}
          onUnreadCountChange={handleAlertCount}
        />
      </div>

      <OfflineIndicator />
    </div>
  );
}
`;

export const STANDALONE_SPECS: Record<StandaloneProjectTarget, StandaloneSpec> = {
  customer: {
    target: 'customer',
    packageName: 'mishwar-customer',
    title: 'MISHWAR – مشوار | تطبيق الزبون',
    shortName: 'مشوار',
    description:
      'تطبيق الزبون المستقل لمنصة مشوار في العراق: طلب الرحلات، التتبع المباشر، الدفع النقدي وسوبر كي وزين كاش، ورقم حساب فريد.',
    themeColor: '#6D28D9',
    capacitorAppId: 'iq.mishwar.customer',
    components: [
      'CustomerApp.tsx',
      'CustomerAppLogo.tsx',
      'CustomerPWAWelcomeModal.tsx',
      'LegalTermsModal.tsx',
      'MishwarMap.tsx',
      'ProtectedImage.tsx',
      'PWAInstallButton.tsx',
      'RideCommBar.tsx',
      'SosModalButton.tsx',
      'TripShareView.tsx',
    ],
    appTsx: CUSTOMER_APP_TSX,
    readmeAr: `# MISHWAR – مشوار (تطبيق الزبون المستقل)

مشروع مستقل كامل لتطبيق الزبون مع جميع ملفات الواجهة، الصور، الشروط والأحكام (14 بنداً)، بوابات الدفع الرسمية، والخادم الخلفي.

## التشغيل المحلي
\`\`\`bash
npm install
cp .env.example .env
npm run dev
\`\`\`

## البناء والإنتاج
\`\`\`bash
npm run build
npm start
\`\`\`

راجع ملف \`BUILD_AND_DEPLOY_AR.md\` لخطوات استخراج ملفات Android (APK / AAB) و iOS عبر Capacitor.
`,
  },
  driver: {
    target: 'driver',
    packageName: 'mishwar-driver',
    title: 'MISHWAR – كابتن مشوار | تطبيق السائق',
    shortName: 'كابتن مشوار',
    description:
      'تطبيق السائق المستقل لمنصة مشوار: زر مشوار، المحفظة الإلكترونية والرصيد الافتتاحي 10,000 د.ع، العمولات، واتفاقية السائق.',
    themeColor: '#0F172A',
    capacitorAppId: 'iq.mishwar.driver',
    components: [
      'DriverApp.tsx',
      'LegalTermsModal.tsx',
      'MishwarMap.tsx',
      'ProtectedImage.tsx',
      'PWAInstallButton.tsx',
      'RideCommBar.tsx',
      'SosModalButton.tsx',
    ],
    appTsx: DRIVER_APP_TSX,
    readmeAr: `# MISHWAR – كابتن مشوار (تطبيق السائق المستقل)

مشروع مستقل كامل لتطبيق السائق مع زر مشوار، المحفظة الإلكترونية، الرصيد الافتتاحي المجاني 10,000 د.ع، الشحن الإلكتروني، التظلّم، والخادم الخلفي.

## التشغيل المحلي
\`\`\`bash
npm install
cp .env.example .env
npm run dev
\`\`\`

## البناء والإنتاج
\`\`\`bash
npm run build
npm start
\`\`\`

راجع ملف \`BUILD_AND_DEPLOY_AR.md\` لخطوات استخراج ملفات Android (APK / AAB) و iOS عبر Capacitor.
`,
  },
  admin: {
    target: 'admin',
    packageName: 'mishwar-admin',
    title: 'MISHWAR – إدارة مشوار | لوحة التحكم',
    shortName: 'إدارة مشوار',
    description:
      'لوحة الإدارة المستقلة لمنصة مشوار: إدارة السائقين والزبائن والرحلات، المحاسبة وبوابات الدفع، التسعير، الشكاوى والتظلّمات، والأمان.',
    themeColor: '#1D4ED8',
    capacitorAppId: 'iq.mishwar.admin',
    components: [
      'AdminDashboard.tsx',
      'MishwarMap.tsx',
      'ProtectedImage.tsx',
      'PWAInstallButton.tsx',
    ],
    appTsx: ADMIN_APP_TSX,
    readmeAr: `# MISHWAR – إدارة مشوار (لوحة الإدارة المستقلة)

مشروع مستقل كامل للوحة تحكم الإدارة مع البحث برقم الحساب (MSH-C / MSH-D / MSH-A / MSH-TR)، إدارة المحافظ وبوابات الدفع، التظلّمات، والنسخ الاحتياطية المشفرة.

## التشغيل المحلي
\`\`\`bash
npm install
cp .env.example .env
npm run dev
\`\`\`

## البناء والإنتاج
\`\`\`bash
npm run build
npm start
\`\`\`
`,
  },
};

function copyDirRecursive(srcDir: string, destDir: string) {
  if (!fs.existsSync(srcDir)) return;
  fs.mkdirSync(destDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, destPath);
    } else if (entry.isFile()) {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function buildCustomViteConfig(rawViteConfig: string, spec: StandaloneSpec): string {
  return rawViteConfig
    .replace(/name:\s*'[^']*'/m, `name: '${spec.title.replace(/'/g, "\\'")}'`)
    .replace(/short_name:\s*'[^']*'/m, `short_name: '${spec.shortName.replace(/'/g, "\\'")}'`)
    .replace(/description:\s*'[^']*'/m, `description: '${spec.description.replace(/'/g, "\\'")}'`)
    .replace(/theme_color:\s*'[^']*'/m, `theme_color: '${spec.themeColor}'`);
}

function buildCustomIndexHtml(rawHtml: string, spec: StandaloneSpec): string {
  return rawHtml
    .replace(/<title>.*?<\/title>/i, `<title>${spec.title}</title>`)
    .replace(/(<meta name="description" content=")[^"]*(")/i, `$1${spec.description}$2`)
    .replace(/(<meta property="og:title" content=")[^"]*(")/i, `$1${spec.title}$2`)
    .replace(/(<meta property="og:description" content=")[^"]*(")/i, `$1${spec.description}$2`)
    .replace(/(<meta name="theme-color" content=")[^"]*(")/i, `$1${spec.themeColor}$2`)
    .replace(/(<meta name="apple-mobile-web-app-title" content=")[^"]*(")/i, `$1${spec.shortName}$2`);
}

function buildCustomCapacitorConfig(rawCap: string, spec: StandaloneSpec): string {
  return rawCap
    .replace(/appId:\s*'[^']*'/m, `appId: '${spec.capacitorAppId}'`)
    .replace(/appName:\s*'[^']*'/m, `appName: '${spec.shortName.replace(/'/g, "\\'")}'`);
}

export function generateStandaloneProjectZip(target: StandaloneProjectTarget): {
  zipPath: string;
  filename: string;
  sizeBytes: number;
} {
  const spec = STANDALONE_SPECS[target];
  const rootDir = process.cwd();
  const exportsDir = path.resolve(rootDir, 'exports');
  fs.mkdirSync(exportsDir, { recursive: true });

  const filename = `${spec.packageName}.zip`;
  const zipPath = path.join(exportsDir, filename);

  const stageParent = fs.mkdtempSync(path.join(os.tmpdir(), `mishwar-stage-${target}-`));
  const projectDir = path.join(stageParent, spec.packageName);
  fs.mkdirSync(projectDir, { recursive: true });

  try {
    // 1. Root configuration & docs
    const pkgJson = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf-8'));
    pkgJson.name = spec.packageName;
    pkgJson.version = '1.0.0';
    pkgJson.description = spec.description;
    fs.writeFileSync(path.join(projectDir, 'package.json'), JSON.stringify(pkgJson, null, 2) + '\n', 'utf-8');

    const metaJson = JSON.parse(fs.readFileSync(path.join(rootDir, 'metadata.json'), 'utf-8'));
    metaJson.name = spec.title;
    metaJson.description = spec.description;
    fs.writeFileSync(path.join(projectDir, 'metadata.json'), JSON.stringify(metaJson, null, 2) + '\n', 'utf-8');

    const rawVite = fs.readFileSync(path.join(rootDir, 'vite.config.ts'), 'utf-8');
    fs.writeFileSync(path.join(projectDir, 'vite.config.ts'), buildCustomViteConfig(rawVite, spec), 'utf-8');

    const rawHtml = fs.readFileSync(path.join(rootDir, 'index.html'), 'utf-8');
    fs.writeFileSync(path.join(projectDir, 'index.html'), buildCustomIndexHtml(rawHtml, spec), 'utf-8');

    const rawCap = fs.readFileSync(path.join(rootDir, 'capacitor.config.ts'), 'utf-8');
    fs.writeFileSync(path.join(projectDir, 'capacitor.config.ts'), buildCustomCapacitorConfig(rawCap, spec), 'utf-8');

    for (const rootFile of ['tsconfig.json', '.env.example', '.gitignore', 'BUILD_AND_DEPLOY_AR.md']) {
      const srcFile = path.join(rootDir, rootFile);
      if (fs.existsSync(srcFile)) {
        fs.copyFileSync(srcFile, path.join(projectDir, rootFile));
      }
    }
    fs.writeFileSync(path.join(projectDir, 'README.md'), spec.readmeAr, 'utf-8');

    // 2. Public icons & assets
    copyDirRecursive(path.join(rootDir, 'public'), path.join(projectDir, 'public'));

    // 3. Backend source & tests (without live DB or .env secrets)
    fs.copyFileSync(path.join(rootDir, 'server.ts'), path.join(projectDir, 'server.ts'));
    copyDirRecursive(path.join(rootDir, 'server'), path.join(projectDir, 'server'));
    copyDirRecursive(path.join(rootDir, 'tests'), path.join(projectDir, 'tests'));

    // 4. Frontend src
    const srcDest = path.join(projectDir, 'src');
    fs.mkdirSync(srcDest, { recursive: true });
    fs.copyFileSync(path.join(rootDir, 'src', 'main.tsx'), path.join(srcDest, 'main.tsx'));
    fs.copyFileSync(path.join(rootDir, 'src', 'index.css'), path.join(srcDest, 'index.css'));
    fs.writeFileSync(path.join(srcDest, 'App.tsx'), spec.appTsx, 'utf-8');

    copyDirRecursive(path.join(rootDir, 'src', 'assets'), path.join(srcDest, 'assets'));
    copyDirRecursive(path.join(rootDir, 'src', 'legal'), path.join(srcDest, 'legal'));
    copyDirRecursive(path.join(rootDir, 'src', 'lib'), path.join(srcDest, 'lib'));
    copyDirRecursive(path.join(rootDir, 'src', 'types'), path.join(srcDest, 'types'));

    const compDest = path.join(srcDest, 'components');
    fs.mkdirSync(compDest, { recursive: true });
    for (const compFile of spec.components) {
      const srcComp = path.join(rootDir, 'src', 'components', compFile);
      if (fs.existsSync(srcComp)) {
        fs.copyFileSync(srcComp, path.join(compDest, compFile));
      }
    }

    // 5. Pack cleanly into ZIP via Python zipfile (zero external npm dependencies, deterministic paths)
    const tmpZipPath = `${zipPath}.tmp`;
    if (fs.existsSync(tmpZipPath)) fs.unlinkSync(tmpZipPath);
    const pyScript = `
import os, sys, zipfile
root_parent = sys.argv[1]
folder_name = sys.argv[2]
out_zip = sys.argv[3]
src_dir = os.path.join(root_parent, folder_name)
with zipfile.ZipFile(out_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for dirpath, _, filenames in os.walk(src_dir):
        filenames.sort()
        for fn in filenames:
            full_path = os.path.join(dirpath, fn)
            rel_path = os.path.relpath(full_path, root_parent)
            zf.write(full_path, rel_path)
`;
    execFileSync('python3', ['-c', pyScript, stageParent, spec.packageName, tmpZipPath], {
      stdio: 'pipe',
    });
    fs.renameSync(tmpZipPath, zipPath);

    const stat = fs.statSync(zipPath);
    return { zipPath, filename, sizeBytes: stat.size };
  } finally {
    fs.rmSync(stageParent, { recursive: true, force: true });
  }
}

export function generateAllStandaloneExports(): Array<{
  target: StandaloneProjectTarget;
  filename: string;
  sizeBytes: number;
}> {
  const targets: StandaloneProjectTarget[] = ['customer', 'driver', 'admin'];
  return targets.map((t) => {
    const res = generateStandaloneProjectZip(t);
    return { target: t, filename: res.filename, sizeBytes: res.sizeBytes };
  });
}
