export interface RouteResult {
  distance_km: number;
  duration_min: number;
  geometry: [number, number][]; // [lat, lng]
  source: 'osrm' | 'fallback';
}

export interface PlaceSuggestion {
  name: string;
  display_name: string;
  lat: number;
  lng: number;
  source: 'nominatim' | 'iraq_index';
}

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export async function computeRouteOSRM(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): Promise<RouteResult> {
  const straightKm = haversineKm(lat1, lng1, lat2, lng2);
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4500);
    const url = `https://router.project-osrm.org/route/v1/driving/${lng1},${lat1};${lng2},${lat2}?overview=full&geometries=geojson`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'MishwarIraqRideApp/1.0' },
    });
    clearTimeout(timer);
    if (res.ok) {
      const data = (await res.json()) as {
        code?: string;
        routes?: Array<{
          distance: number;
          duration: number;
          geometry?: { coordinates: [number, number][] };
        }>;
      };
      const route = data.routes?.[0];
      if (data.code === 'Ok' && route) {
        const coords: [number, number][] = (route.geometry?.coordinates ?? []).map(([lng, lat]) => [
          lat,
          lng,
        ]);
        return {
          distance_km: Math.max(0.2, Number((route.distance / 1000).toFixed(2))),
          duration_min: Math.max(1, Math.round(route.duration / 60)),
          geometry: coords.length >= 2 ? coords : [[lat1, lng1], [lat2, lng2]],
          source: 'osrm',
        };
      }
    }
  } catch {
    // Fall back cleanly to road-adjusted geodesic estimate if OSRM is unreachable
  }

  const estimatedRoadKm = Math.max(0.3, Number((straightKm * 1.28).toFixed(2)));
  const estimatedMin = Math.max(2, Math.round((estimatedRoadKm / 32) * 60));
  return {
    distance_km: estimatedRoadKm,
    duration_min: estimatedMin,
    geometry: [
      [lat1, lng1],
      [lat2, lng2],
    ],
    source: 'fallback',
  };
}

const IRAQ_PLACES_INDEX: PlaceSuggestion[] = [
  { name: 'ساحة التحرير - بغداد', display_name: 'ساحة التحرير، مركز بغداد', lat: 33.3292, lng: 44.4106, source: 'iraq_index' },
  { name: 'المنصور - مول المنصور', display_name: 'المنصور، بغداد', lat: 33.3144, lng: 44.3422, source: 'iraq_index' },
  { name: 'الكرادة داخل', display_name: 'الكرادة، بغداد', lat: 33.3036, lng: 44.4222, source: 'iraq_index' },
  { name: 'الجادرية - جامعة بغداد', display_name: 'الجادرية، بغداد', lat: 33.2747, lng: 44.3822, source: 'iraq_index' },
  { name: 'زيونة - مول النخيل', display_name: 'زيونة، الرصافة، بغداد', lat: 33.3474, lng: 44.4567, source: 'iraq_index' },
  { name: 'الأعظمية - ساحة عنتر', display_name: 'الأعظمية، بغداد', lat: 33.3687, lng: 44.3646, source: 'iraq_index' },
  { name: 'الكاظمية المقدسة', display_name: 'الكاظمية، بغداد', lat: 33.3802, lng: 44.3372, source: 'iraq_index' },
  { name: 'مطار بغداد الدولي', display_name: 'مطار بغداد الدولي، غرب بغداد', lat: 33.2625, lng: 44.2346, source: 'iraq_index' },
  { name: 'بغداد مول - الحارثية', display_name: 'الحارثية، بغداد', lat: 33.3094, lng: 44.3596, source: 'iraq_index' },
  { name: 'الدورة - بغداد', display_name: 'الدورة، جنوب بغداد', lat: 33.2498, lng: 44.3905, source: 'iraq_index' },
  { name: 'البصرة - العشار', display_name: 'العشار، مركز البصرة', lat: 30.5156, lng: 47.8294, source: 'iraq_index' },
  { name: 'أربيل - القلعة', display_name: 'قلعة أربيل، أربيل', lat: 36.1912, lng: 44.0092, source: 'iraq_index' },
  { name: 'النجف الأشرف - المركز', display_name: 'النجف الأشرف، العراق', lat: 32.0005, lng: 44.3168, source: 'iraq_index' },
  { name: 'كربلاء المقدسة - المركز', display_name: 'كربلاء المقدسة، العراق', lat: 32.616, lng: 44.0249, source: 'iraq_index' },
  { name: 'الموصل - الجانب الأيسر', display_name: 'الموصل، نينوى، العراق', lat: 36.3489, lng: 43.1577, source: 'iraq_index' },
];

export async function searchPlacesIraq(query: string): Promise<PlaceSuggestion[]> {
  const clean = query.trim();
  if (!clean) return IRAQ_PLACES_INDEX.slice(0, 8);

  const localMatches = IRAQ_PLACES_INDEX.filter(
    (p) => p.name.includes(clean) || p.display_name.includes(clean),
  );

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3500);
    const url = `https://nominatim.openstreetmap.org/search?format=json&countrycodes=iq&accept-language=ar&limit=6&q=${encodeURIComponent(clean)}`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'MishwarIraqRideApp/1.0' },
    });
    clearTimeout(timer);
    if (res.ok) {
      const items = (await res.json()) as Array<{
        display_name: string;
        lat: string;
        lon: string;
      }>;
      const remote: PlaceSuggestion[] = items.map((item) => ({
        name: item.display_name.split(',')[0].trim(),
        display_name: item.display_name,
        lat: Number(item.lat),
        lng: Number(item.lon),
        source: 'nominatim',
      }));
      const seen = new Set(remote.map((r) => `${r.lat.toFixed(3)},${r.lng.toFixed(3)}`));
      return [...remote, ...localMatches.filter((m) => !seen.has(`${m.lat.toFixed(3)},${m.lng.toFixed(3)}`))].slice(0, 8);
    }
  } catch {
    // Fallback to Iraq landmarks index
  }

  return localMatches.length > 0 ? localMatches : IRAQ_PLACES_INDEX.slice(0, 5);
}

export async function reverseGeocodeIraq(lat: number, lng: number): Promise<string> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3000);
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&accept-language=ar&lat=${lat}&lon=${lng}`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'MishwarIraqRideApp/1.0' },
    });
    clearTimeout(timer);
    if (res.ok) {
      const data = (await res.json()) as {
        address?: { road?: string; suburb?: string; city?: string; town?: string; state?: string };
        display_name?: string;
      };
      const addr = data.address;
      if (addr) {
        const parts = [addr.road, addr.suburb, addr.city || addr.town || addr.state].filter(Boolean);
        if (parts.length > 0) return parts.join('، ');
      }
      if (data.display_name) return data.display_name.split(',').slice(0, 3).join('، ');
    }
  } catch {
    // Ignore and return nearest known landmark or coordinates
  }

  let nearest = IRAQ_PLACES_INDEX[0];
  let minKm = Infinity;
  for (const place of IRAQ_PLACES_INDEX) {
    const d = haversineKm(lat, lng, place.lat, place.lng);
    if (d < minKm) {
      minKm = d;
      nearest = place;
    }
  }
  if (minKm <= 2.5) {
    return `قرب ${nearest.name}`;
  }
  return `موقع محدد (${lat.toFixed(4)}, ${lng.toFixed(4)})`;
}
