import 'dotenv/config';
import crypto from 'crypto';
import express from 'express';
import fs from 'fs';
import http from 'http';
import path from 'path';
import { WebSocketServer } from 'ws';
import {
  authenticateToken,
  hashPassword,
  isEnvPasscodeConfigured,
  normalizeIraqiPhone,
  requireAuth,
  requireRole,
  revokeTokenJti,
  signToken,
  verifyEnvAdminPasscode,
  verifyPassword,
  type AuthedRequest,
} from './server/auth.ts';
import { allocateSequenceNumberInTx, db, initDatabase, writeAuditLog } from './server/db.ts';
import {
  CUSTOMER_TERMS_ACKNOWLEDGEMENT,
  CUSTOMER_TERMS_CLAUSES,
  CUSTOMER_TERMS_INTRO,
  CUSTOMER_TERMS_TITLE,
  CUSTOMER_TERMS_VERSION,
  DRIVER_TERMS_ACKNOWLEDGEMENT,
  DRIVER_TERMS_CLAUSES,
  DRIVER_TERMS_INTRO,
  DRIVER_TERMS_TITLE,
  DRIVER_TERMS_VERSION,
  PRIVACY_POLICY_SECTIONS,
  PRIVACY_POLICY_VERSION,
} from './src/legal/agreements.ts';
import {
  acceptRideAtomic,
  broadcastRideUpdate,
  calculateFareServer,
  createNotification,
  dispatchNextDriver,
  getEnrichedRide,
  hasActivePlusSubscription,
  registerSocket,
  sendToAdmins,
  sendToUser,
  startDispatchSweepTimer,
  triggerRideMilestone,
} from './server/dispatch.ts';
import {
  assertRideChatParticipant,
  closeAndPurgeRideChat,
  endMaskedCallSession,
  getMaskedCallCapabilities,
  listRideMessages,
  maskIraqiPhone,
  reportRideMessage,
  sendRideMessage,
  startMaskedCallSession,
} from './server/comm.ts';
import { computeRouteOSRM, haversineKm, reverseGeocodeIraq, searchPlacesIraq } from './server/geo.ts';
import {
  apiRateLimiter,
  checkLoginLockout,
  clearLoginFailures,
  createDatabaseBackup,
  getLoginAttemptKey,
  recordSecurityEvent,
  registerLoginFailure,
  securityHeadersMiddleware,
  startPeriodicBackups,
} from './server/security.ts';
import {
  getUploadRecord,
  resolveSafeUploadPath,
  saveUploadedImageBase64,
  type UploadPurpose,
} from './server/uploads.ts';
import {
  generateStandaloneProjectZip,
  type StandaloneProjectTarget,
} from './server/exporter.ts';
import {
  adjustDriverWalletByAdmin,
  assertGatewayAvailable,
  completeRideSettlementAtomic,
  computeCommissionSplit,
  confirmPaymentTransactionAtomic,
  ensureExistingApprovedDriversHaveOpeningBonus,
  getCommissionPercent,
  getFinancialAccountingReport,
  getOrCreateDriverWallet,
  grantDriverOpeningBonusAtomic,
  initiateOfficialGatewayCheckout,
  listPaymentGatewayConfigs,
  validateGatewayBaseUrl,
  verifySuperQiRsaSignature,
  verifyZainCashJwtToken,
} from './server/payments.ts';
import type {
  AppSettings,
  DriverProfile,
  PaymentMethod,
  PaymentTransaction,
  PlusSettings,
  PricingRules,
  Ride,
  VehicleCategory,
} from './src/types/mishwar.ts';

initDatabase();
ensureExistingApprovedDriversHaveOpeningBonus();
if (process.env.MISHWAR_TEST_MODE !== '1') {
  startDispatchSweepTimer();
  startPeriodicBackups();
}

export function createMishwarServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(securityHeadersMiddleware);

  const configuredOrigins = new Set<string>([
    'https://localhost',
    'http://localhost',
    'capacitor://localhost',
    ...(process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL' ? [process.env.APP_URL.replace(/\/+$/, '')] : []),
    ...(process.env.ALLOWED_ORIGINS
      ? process.env.ALLOWED_ORIGINS.split(',').map((o) => o.trim().replace(/\/+$/, '')).filter(Boolean)
      : []),
  ]);

  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && configuredOrigins.has(origin.replace(/\/+$/, ''))) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Signature');
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
    }
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.use(
    express.json({
      limit: '8mb',
      verify: (req, _res, buf) => {
        (req as express.Request & { rawBody?: Buffer }).rawBody = buf;
      },
    }),
  );

  app.get('/api/health', (_req, res) => {
    try {
      db.prepare('SELECT 1 AS ok').get();
      res.json({
        ok: true,
        service: 'mishwar',
        db: 'connected',
        timestamp: new Date().toISOString(),
      });
    } catch {
      res.status(503).json({ ok: false, service: 'mishwar', db: 'error' });
    }
  });

  app.use('/api/', apiRateLimiter(240));

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    try {
      const url = new URL(req.url || '/', 'http://localhost');
      const token = url.searchParams.get('token');
      const auth = authenticateToken(token);
      if (!auth) {
        ws.close(4001, 'Unauthorized');
        return;
      }
      registerSocket(ws, auth.userId, auth.role);
      ws.send(JSON.stringify({ event: 'ws:ready', payload: { userId: auth.userId, role: auth.role } }));

      ws.on('message', (raw) => {
        try {
          const parsed = JSON.parse(raw.toString()) as { event?: string; payload?: Record<string, unknown> };
          const evt = parsed?.event;
          const payload = parsed?.payload;
          if (!evt || !payload) return;

          const allowedCallSignals = new Set(['call:offer', 'call:answer', 'call:ice', 'call:hangup', 'call:reject']);
          if (allowedCallSignals.has(evt)) {
            const rideId = String(payload.ride_id || '');
            const check = assertRideChatParticipant(rideId, auth.userId, true);
            if (!check.ok) {
              ws.send(JSON.stringify({ event: 'call:error', payload: { error: check.error } }));
              return;
            }
            if ((evt === 'call:hangup' || evt === 'call:reject') && payload.call_id) {
              endMaskedCallSession(String(payload.call_id));
            }
            sendToUser(check.otherUserId, evt, {
              ...payload,
              from_user_id: auth.userId,
              from_role: check.role,
            });
          }
        } catch {
          // Ignore malformed WS frames
        }
      });
    } catch {
      ws.close(4000, 'Bad Request');
    }
  });

  // ==================== HEALTH & LEGAL AGREEMENTS ====================
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'MISHWAR – مشوار' });
  });

  app.get('/api/legal/terms', (_req, res) => {
    res.json({
      customer: {
        version: CUSTOMER_TERMS_VERSION,
        title: CUSTOMER_TERMS_TITLE,
        intro: CUSTOMER_TERMS_INTRO,
        clauses: CUSTOMER_TERMS_CLAUSES,
        acknowledgement: CUSTOMER_TERMS_ACKNOWLEDGEMENT,
      },
      driver: {
        version: DRIVER_TERMS_VERSION,
        title: DRIVER_TERMS_TITLE,
        intro: DRIVER_TERMS_INTRO,
        clauses: DRIVER_TERMS_CLAUSES,
        acknowledgement: DRIVER_TERMS_ACKNOWLEDGEMENT,
      },
      privacy: {
        version: PRIVACY_POLICY_VERSION,
        sections: PRIVACY_POLICY_SECTIONS,
      },
    });
  });

  // ==================== UPLOADS (STRICT VALIDATION, DB STORAGE & ACCESS CONTROL) ====================
  app.post('/api/uploads', (req: AuthedRequest, res) => {
    try {
      const { dataUrl, purpose } = req.body as { dataUrl?: string; purpose?: UploadPurpose };
      if (!dataUrl) {
        res.status(400).json({ error: 'الملف مطلوب' });
        return;
      }
      const header = req.headers.authorization;
      const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : null;
      const auth = authenticateToken(token);
      const safePurpose: UploadPurpose =
        purpose === 'driver_doc'
          ? 'driver_doc'
          : purpose === 'driver_avatar'
            ? 'driver_avatar'
            : purpose === 'complaint_attachment'
              ? 'complaint_attachment'
              : 'avatar';
      const url = saveUploadedImageBase64(dataUrl, safePurpose, auth?.userId ?? null);
      res.json({ url });
    } catch (err) {
      recordSecurityEvent({
        severity: 'medium',
        eventType: 'invalid_upload_rejected',
        ipAddress: req.ip,
        summary: 'تم رفض محاولة رفع ملف غير صالح أو بصيغة غير مدعومة',
      });
      res.status(400).json({ error: err instanceof Error ? err.message : 'فشل رفع الصورة' });
    }
  });

  app.get('/api/uploads/:filename', (req, res) => {
    const record = getUploadRecord(req.params.filename);
    const safePath = resolveSafeUploadPath(req.params.filename);
    if (!record || (!safePath && !record.image_blob)) {
      res.status(404).json({ error: 'الملف غير موجود' });
      return;
    }

    if (record.purpose === 'driver_doc') {
      const header = req.headers.authorization;
      const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : null;
      const auth = authenticateToken(token);
      if (!auth) {
        res.status(401).json({ error: 'يجب تسجيل الدخول للوصول إلى مستمسكات السائق' });
        return;
      }
      if (auth.role !== 'admin' && auth.userId !== record.owner_user_id) {
        recordSecurityEvent({
          severity: 'high',
          eventType: 'unauthorized_doc_access',
          actorUserId: auth.userId,
          ipAddress: req.ip,
          summary: `محاولة وصول غير مصرح به إلى مستمسك سائق (${req.params.filename})`,
        });
        res.status(403).json({ error: 'غير مصرح بعرض مستمسكات السائقين' });
        return;
      }
    } else if (record.purpose === 'driver_avatar') {
      const header = req.headers.authorization;
      const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : null;
      const auth = authenticateToken(token);
      if (!auth) {
        res.status(401).json({ error: 'يجب تسجيل الدخول لعرض صورة السائق' });
        return;
      }
      if (auth.role !== 'admin' && auth.userId !== record.owner_user_id) {
        let allowedForCustomer = false;
        if (auth.role === 'customer' && record.owner_user_id) {
          const driverRow = db
            .prepare(
              `SELECT u.avatar_url, dp.photo_status
               FROM users u
               JOIN driver_profiles dp ON dp.user_id = u.id
               WHERE u.id = ?`,
            )
            .get(record.owner_user_id) as { avatar_url: string | null; photo_status: string } | undefined;

          const requestedUrl = `/api/uploads/${record.filename}`;
          if (driverRow && driverRow.photo_status === 'approved' && driverRow.avatar_url === requestedUrl) {
            const matchedRide = db
              .prepare(
                `SELECT id FROM rides
                 WHERE customer_id = ? AND driver_id = ?
                   AND status IN ('found', 'on_the_way', 'arrived', 'in_progress', 'completed')
                 LIMIT 1`,
              )
              .get(auth.userId, record.owner_user_id);
            allowedForCustomer = Boolean(matchedRide);
          }
        }
        if (!allowedForCustomer) {
          recordSecurityEvent({
            severity: 'high',
            eventType: 'unauthorized_driver_photo_access',
            actorUserId: auth.userId,
            ipAddress: req.ip,
            summary: `محاولة وصول غير مصرح به إلى صورة سائق (${req.params.filename})`,
          });
          res.status(403).json({ error: 'لا يمكن عرض صورة السائق قبل قبول الرحلة أو اعتماد الصورة' });
          return;
        }
      }
    } else if (record.purpose === 'complaint_attachment') {
      const header = req.headers.authorization;
      const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : null;
      const auth = authenticateToken(token);
      if (!auth) {
        res.status(401).json({ error: 'يجب تسجيل الدخول لعرض مرفق الشكوى' });
        return;
      }
      if (auth.role !== 'admin' && auth.userId !== record.owner_user_id) {
        recordSecurityEvent({
          severity: 'high',
          eventType: 'unauthorized_doc_access',
          actorUserId: auth.userId,
          ipAddress: req.ip,
          summary: `محاولة وصول غير مصرح به إلى مرفق شكوى (${req.params.filename})`,
        });
        res.status(403).json({ error: 'غير مصرح بعرض مرفق الشكوى' });
        return;
      }
    }

    if (safePath) {
      res.sendFile(safePath);
      return;
    }
    res.setHeader('Content-Type', record.mime_type || 'image/jpeg');
    res.send(record.image_blob);
  });

  // ==================== MAPS / GEO PROXY ====================
  app.get('/api/maps/search', async (req, res) => {
    const q = String(req.query.q ?? '');
    const places = await searchPlacesIraq(q);
    res.json({ places });
  });

  app.get('/api/maps/reverse', async (req, res) => {
    const lat = Number(req.query.lat);
    const lng = Number(req.query.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      res.status(400).json({ error: 'إحداثيات غير صالحة' });
      return;
    }
    const address = await reverseGeocodeIraq(lat, lng);
    res.json({ address });
  });

  app.get('/api/maps/route', async (req, res) => {
    const fromLat = Number(req.query.fromLat);
    const fromLng = Number(req.query.fromLng);
    const toLat = Number(req.query.toLat);
    const toLng = Number(req.query.toLng);
    if (![fromLat, fromLng, toLat, toLng].every(Number.isFinite)) {
      res.status(400).json({ error: 'إحداثيات المسار غير صالحة' });
      return;
    }
    const route = await computeRouteOSRM(fromLat, fromLng, toLat, toLng);
    res.json(route);
  });

  // ==================== AUTHENTICATION & LOCKOUT ====================
  app.post('/api/auth/customer/register', (req, res) => {
    const { name, phone, password, avatarUrl, acceptTerms } = req.body as {
      name?: string;
      phone?: string;
      password?: string;
      avatarUrl?: string | null;
      acceptTerms?: boolean;
    };
    const cleanName = name?.trim();
    const normalizedPhone = normalizeIraqiPhone(phone ?? '');
    if (!cleanName || cleanName.length < 2 || cleanName.length > 80) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل بشكل صحيح' });
      return;
    }
    if (!normalizedPhone) {
      res.status(400).json({ error: 'يرجى إدخال رقم هاتف عراقي صحيح (مثال: 07701234567)' });
      return;
    }
    if (!password || password.length < 6) {
      res.status(400).json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
      return;
    }
    if (acceptTerms !== true) {
      res.status(400).json({ error: 'يجب قراءة والموافقة على اتفاقية الاستخدام والشروط والأحكام لإكمال التسجيل' });
      return;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    let duplicatePhone = false;
    let accountNumber = '';

    const tx = db.transaction(() => {
      const existing = db.prepare('SELECT id FROM users WHERE phone = ?').get(normalizedPhone);
      if (existing) {
        duplicatePhone = true;
        return;
      }
      accountNumber = allocateSequenceNumberInTx('MSH-C');
      db.prepare(
        `INSERT INTO users (
          id, account_number, role, name, phone, password_hash, avatar_url, status,
          terms_accepted_version, terms_accepted_at, token_version, created_at
        ) VALUES (?, ?, 'customer', ?, ?, ?, ?, 'active', ?, ?, 1, ?)`,
      ).run(
        id,
        accountNumber,
        cleanName,
        normalizedPhone,
        hashPassword(password),
        avatarUrl || null,
        CUSTOMER_TERMS_VERSION,
        now,
        now,
      );
      db.prepare(
        `INSERT INTO legal_acceptances (id, user_id, account_number, role, doc_type, version, commission_percent, accepted_at, ip_address)
         VALUES (?, ?, ?, 'customer', 'customer_terms', ?, NULL, ?, ?)`,
      ).run(crypto.randomUUID(), id, accountNumber, CUSTOMER_TERMS_VERSION, now, req.ip || null);
    });
    tx.immediate();

    if (duplicatePhone) {
      res.status(409).json({ error: 'رقم الهاتف مسجل مسبقاً' });
      return;
    }

    writeAuditLog({
      actorUserId: id,
      actorRole: 'customer',
      action: 'customer.registered',
      targetType: 'user',
      targetId: id,
      details: { account_number: accountNumber, phone: normalizedPhone, terms_version: CUSTOMER_TERMS_VERSION },
    });

    const token = signToken(id, 'customer', 1);
    const user = db
      .prepare(
        'SELECT id, account_number, role, name, phone, avatar_url, status, terms_accepted_version, terms_accepted_at, created_at FROM users WHERE id = ?',
      )
      .get(id);
    res.status(201).json({
      token,
      user,
      needsTermsAcceptance: false,
      currentTermsVersion: CUSTOMER_TERMS_VERSION,
    });
  });

  app.post('/api/auth/customer/login', (req, res) => {
    const { phone, password } = req.body as { phone?: string; password?: string };
    const normalized = normalizeIraqiPhone(phone ?? '');
    if (!normalized || !password) {
      res.status(400).json({ error: 'يرجى إدخال رقم الهاتف العراقي وكلمة المرور' });
      return;
    }

    const lockKey = getLoginAttemptKey(req.ip, `customer:${normalized}`);
    const lock = checkLoginLockout(lockKey);
    if (lock.locked) {
      res.status(429).json({ error: `تم قفل تسجيل الدخول مؤقتاً. حاول بعد ${lock.retryAfterSec} ثانية.` });
      return;
    }

    const row = db
      .prepare("SELECT * FROM users WHERE phone = ? AND role = 'customer'")
      .get(normalized) as
      | (Record<string, unknown> & {
          id: string;
          password_hash: string;
          status: string;
          token_version: number;
          terms_accepted_version?: string | null;
        })
      | undefined;

    if (!row || !verifyPassword(password, row.password_hash)) {
      registerLoginFailure(lockKey, req.ip, normalized);
      res.status(401).json({ error: 'رقم الهاتف أو كلمة المرور غير صحيحة' });
      return;
    }
    if (row.status !== 'active') {
      res.status(403).json({ error: 'تم إيقاف هذا الحساب من قبل الإدارة' });
      return;
    }
    clearLoginFailures(lockKey);
    const token = signToken(row.id, 'customer', row.token_version);
    const { password_hash: _ph, token_version: _tv, ...user } = row;
    res.json({
      token,
      user,
      needsTermsAcceptance: row.terms_accepted_version !== CUSTOMER_TERMS_VERSION,
      currentTermsVersion: CUSTOMER_TERMS_VERSION,
    });
  });

  app.post('/api/auth/driver/register', (req, res) => {
    const settings = db.prepare('SELECT allow_driver_registration FROM app_settings WHERE id = 1').get() as {
      allow_driver_registration: number;
    };
    if (settings && settings.allow_driver_registration !== 1) {
      res.status(403).json({ error: 'تسجيل السائقين الجدد متوقف مؤقتاً من الإدارة' });
      return;
    }

    const {
      name,
      phone,
      password,
      avatarUrl,
      carMake,
      carModel,
      carYear,
      carColor,
      plateNumber,
      category,
      licenseDocUrl,
      registrationDocUrl,
      nationalIdDocUrl,
      acceptTerms,
    } = req.body as Record<string, string | number | boolean | null | undefined>;

    const cleanName = String(name ?? '').trim();
    const normalizedPhone = normalizeIraqiPhone(String(phone ?? ''));
    const validCategories: VehicleCategory[] = ['Economy', 'Super', 'Plus', 'Family'];

    if (cleanName.length < 2 || cleanName.length > 80) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل' });
      return;
    }
    if (!normalizedPhone) {
      res.status(400).json({ error: 'يرجى إدخال رقم هاتف عراقي صحيح (07XXXXXXXXX)' });
      return;
    }
    if (!password || String(password).length < 6) {
      res.status(400).json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
      return;
    }
    if (acceptTerms !== true) {
      res.status(400).json({ error: 'يجب قراءة والموافقة على اتفاقية السائق والشروط والأحكام لإكمال التسجيل' });
      return;
    }
    if (!carMake || !carModel || !carColor || !plateNumber) {
      res.status(400).json({ error: 'يرجى إكمال جميع معلومات السيارة ورقم اللوحة' });
      return;
    }
    if (!validCategories.includes(category as VehicleCategory)) {
      res.status(400).json({ error: 'يرجى اختيار فئة السيارة' });
      return;
    }
    if (!avatarUrl || !licenseDocUrl || !registrationDocUrl || !nationalIdDocUrl) {
      res.status(400).json({
        error: 'يرجى رفع الصورة الشخصية وجميع المستمسكات المطلوبة (إجازة السوق، السنوية، البطاقة الوطنية)',
      });
      return;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const yearNum = Math.min(2030, Math.max(1995, Number(carYear) || 2020));
    const activeCommPct = getCommissionPercent();

    const bindUploadOwner = (urlVal: unknown, forcePurpose?: UploadPurpose) => {
      const m = String(urlVal || '').match(/\/api\/uploads\/([a-f0-9-]+\.(?:jpg|png|webp))$/i);
      if (m) {
        if (forcePurpose) {
          db.prepare('UPDATE upload_records SET owner_user_id = ?, purpose = ? WHERE filename = ? AND owner_user_id IS NULL').run(
            id,
            forcePurpose,
            m[1],
          );
        } else {
          db.prepare('UPDATE upload_records SET owner_user_id = ? WHERE filename = ? AND owner_user_id IS NULL').run(
            id,
            m[1],
          );
        }
      }
    };

    let duplicatePhone = false;
    let accountNumber = '';

    const tx = db.transaction(() => {
      const existing = db.prepare('SELECT id FROM users WHERE phone = ?').get(normalizedPhone);
      if (existing) {
        duplicatePhone = true;
        return;
      }

      accountNumber = allocateSequenceNumberInTx('MSH-D');
      db.prepare(
        `INSERT INTO users (
          id, account_number, role, name, phone, password_hash, avatar_url, status,
          terms_accepted_version, terms_accepted_at, token_version, created_at
        ) VALUES (?, ?, 'driver', ?, ?, ?, ?, 'active', ?, ?, 1, ?)`,
      ).run(
        id,
        accountNumber,
        cleanName,
        normalizedPhone,
        hashPassword(String(password)),
        String(avatarUrl),
        DRIVER_TERMS_VERSION,
        now,
        now,
      );

      db.prepare(
        `INSERT INTO driver_profiles (
          user_id, approval_status, photo_status, pending_avatar_url, car_make, car_model, car_year, car_color,
          plate_number, category, license_doc_url, registration_doc_url,
          national_id_doc_url, is_online, rating_avg, rating_count,
          agreed_commission_percent, commission_agreed_at
        ) VALUES (?, 'pending', 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 5.0, 0, ?, ?)`,
      ).run(
        id,
        String(avatarUrl),
        String(carMake).trim(),
        String(carModel).trim(),
        yearNum,
        String(carColor).trim(),
        String(plateNumber).trim(),
        String(category),
        String(licenseDocUrl),
        String(registrationDocUrl),
        String(nationalIdDocUrl),
        activeCommPct,
        now,
      );

      db.prepare(
        `INSERT INTO legal_acceptances (id, user_id, account_number, role, doc_type, version, commission_percent, accepted_at, ip_address)
         VALUES (?, ?, ?, 'driver', 'driver_terms', ?, ?, ?, ?)`,
      ).run(crypto.randomUUID(), id, accountNumber, DRIVER_TERMS_VERSION, activeCommPct, now, req.ip || null);

      bindUploadOwner(avatarUrl, 'driver_avatar');
      bindUploadOwner(licenseDocUrl, 'driver_doc');
      bindUploadOwner(registrationDocUrl, 'driver_doc');
      bindUploadOwner(nationalIdDocUrl, 'driver_doc');
    });
    tx.immediate();

    if (duplicatePhone) {
      res.status(409).json({ error: 'رقم الهاتف مسجل مسبقاً' });
      return;
    }

    writeAuditLog({
      actorUserId: id,
      actorRole: 'driver',
      action: 'driver.registered',
      targetType: 'user',
      targetId: id,
      details: { account_number: accountNumber, phone: normalizedPhone, category, plateNumber, agreed_commission_percent: activeCommPct },
    });

    sendToAdmins('admin:driver_pending', { userId: id, accountNumber, name: cleanName, category });

    const token = signToken(id, 'driver', 1);
    const user = db
      .prepare(
        'SELECT id, account_number, role, name, phone, avatar_url, status, terms_accepted_version, terms_accepted_at, created_at FROM users WHERE id = ?',
      )
      .get(id);
    const driverProfile = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(id);
    res.status(201).json({
      token,
      user,
      driverProfile,
      needsTermsAcceptance: false,
      currentTermsVersion: DRIVER_TERMS_VERSION,
      activeCommissionPercent: activeCommPct,
      requiresCommissionConsent: false,
    });
  });

  app.post('/api/auth/driver/login', (req, res) => {
    const { phone, password } = req.body as { phone?: string; password?: string };
    const normalized = normalizeIraqiPhone(phone ?? '');
    if (!normalized || !password) {
      res.status(400).json({ error: 'يرجى إدخال رقم الهاتف وكلمة المرور' });
      return;
    }

    const lockKey = getLoginAttemptKey(req.ip, `driver:${normalized}`);
    const lock = checkLoginLockout(lockKey);
    if (lock.locked) {
      res.status(429).json({ error: `تم قفل تسجيل الدخول مؤقتاً. حاول بعد ${lock.retryAfterSec} ثانية.` });
      return;
    }

    const row = db
      .prepare("SELECT * FROM users WHERE phone = ? AND role = 'driver'")
      .get(normalized) as
      | (Record<string, unknown> & {
          id: string;
          password_hash: string;
          status: string;
          token_version: number;
          terms_accepted_version?: string | null;
        })
      | undefined;

    if (!row || !verifyPassword(password, row.password_hash)) {
      registerLoginFailure(lockKey, req.ip, normalized);
      res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
      return;
    }
    if (row.status !== 'active') {
      res.status(403).json({ error: 'تم إيقاف حساب السائق من قبل الإدارة' });
      return;
    }
    clearLoginFailures(lockKey);
    const token = signToken(row.id, 'driver', row.token_version);
    const driverProfile = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(row.id) as
      | DriverProfile
      | undefined;
    const activeCommPct = getCommissionPercent();
    const { password_hash: _ph, token_version: _tv, ...user } = row;
    res.json({
      token,
      user,
      driverProfile,
      needsTermsAcceptance: row.terms_accepted_version !== DRIVER_TERMS_VERSION,
      currentTermsVersion: DRIVER_TERMS_VERSION,
      activeCommissionPercent: activeCommPct,
      requiresCommissionConsent:
        driverProfile?.agreed_commission_percent == null ||
        Math.abs(driverProfile.agreed_commission_percent - activeCommPct) > 0.0001,
    });
  });

  // Admin bootstrap / claim & login
  app.get('/api/admin/bootstrap-status', (_req, res) => {
    const existingAdmin = db.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();
    res.json({
      configured: isEnvPasscodeConfigured() || Boolean(existingAdmin),
      usesEnvPasscode: isEnvPasscodeConfigured(),
    });
  });

  app.post('/api/admin/claim', (req, res) => {
    if (isEnvPasscodeConfigured()) {
      res.status(403).json({ error: 'رمز المدير مضبوط مسبقاً عبر إعدادات الخادم' });
      return;
    }
    const { name, password } = req.body as { name?: string; password?: string };
    if (!password || password.length < 8) {
      res.status(400).json({ error: 'يجب أن لا تقل كلمة مرور المدير عن 8 أحرف' });
      return;
    }

    let createdId = '';
    const tx = db.transaction(() => {
      const existing = db.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();
      if (existing) {
        return false;
      }
      createdId = crypto.randomUUID();
      const accountNumber = allocateSequenceNumberInTx('MSH-A');
      const now = new Date().toISOString();
      db.prepare(
        `INSERT INTO users (id, account_number, role, name, phone, password_hash, status, token_version, created_at)
         VALUES (?, ?, 'admin', ?, '+9647000000000', ?, 'active', 1, ?)`,
      ).run(createdId, accountNumber, name?.trim() || 'مدير منصة مشوار', hashPassword(password), now);
      return true;
    });

    const ok = tx.immediate();
    if (!ok) {
      recordSecurityEvent({
        severity: 'high',
        eventType: 'unauthorized_admin_attempt',
        ipAddress: req.ip,
        summary: 'محاولة إعادة تعيين حساب المدير بعد إعداده مسبقاً',
      });
      res.status(409).json({ error: 'تم إعداد حساب المدير مسبقاً' });
      return;
    }

    writeAuditLog({
      actorUserId: createdId,
      actorRole: 'admin',
      action: 'admin.claimed',
      targetType: 'user',
      targetId: createdId,
    });

    const token = signToken(createdId, 'admin', 1);
    const user = db
      .prepare('SELECT id, account_number, role, name, phone, avatar_url, status, created_at FROM users WHERE id = ?')
      .get(createdId);
    res.status(201).json({ token, user });
  });

  app.post('/api/auth/admin/login', (req, res) => {
    const { password } = req.body as { password?: string };
    if (!password) {
      res.status(400).json({ error: 'يرجى إدخال كلمة مرور الإدارة' });
      return;
    }

    const lockKey = getLoginAttemptKey(req.ip, 'admin');
    const lock = checkLoginLockout(lockKey);
    if (lock.locked) {
      res.status(429).json({ error: `تم قفل دخول الإدارة مؤقتاً. حاول بعد ${lock.retryAfterSec} ثانية.` });
      return;
    }

    if (isEnvPasscodeConfigured()) {
      if (!verifyEnvAdminPasscode(password)) {
        registerLoginFailure(lockKey, req.ip, 'admin');
        res.status(401).json({ error: 'رمز الإدارة غير صحيح' });
        return;
      }
      let admin = db
        .prepare("SELECT id, account_number, role, name, phone, avatar_url, status, token_version, created_at FROM users WHERE role = 'admin' LIMIT 1")
        .get() as { id: string; account_number: string; role: 'admin'; name: string; phone: string; token_version: number } | undefined;
      if (!admin) {
        const tx = db.transaction(() => {
          const id = crypto.randomUUID();
          const accountNumber = allocateSequenceNumberInTx('MSH-A');
          db.prepare(
            `INSERT INTO users (id, account_number, role, name, phone, password_hash, status, token_version, created_at)
             VALUES (?, ?, 'admin', 'مدير منصة مشوار', '+9647000000000', ?, 'active', 1, ?)`,
          ).run(id, accountNumber, hashPassword(crypto.randomBytes(24).toString('hex')), new Date().toISOString());
          return id;
        });
        const newId = tx.immediate();
        admin = db
          .prepare('SELECT id, account_number, role, name, phone, avatar_url, status, token_version, created_at FROM users WHERE id = ?')
          .get(newId) as typeof admin;
      }
      clearLoginFailures(lockKey);
      const token = signToken(admin!.id, 'admin', admin!.token_version);
      res.json({ token, user: admin });
      return;
    }

    const adminRow = db.prepare("SELECT * FROM users WHERE role = 'admin' LIMIT 1").get() as
      | (Record<string, unknown> & { id: string; password_hash: string; token_version: number })
      | undefined;
    if (!adminRow || !verifyPassword(password, adminRow.password_hash)) {
      registerLoginFailure(lockKey, req.ip, 'admin');
      res.status(401).json({ error: 'كلمة مرور الإدارة غير صحيحة' });
      return;
    }
    clearLoginFailures(lockKey);
    const token = signToken(adminRow.id, 'admin', adminRow.token_version);
    const { password_hash: _ph, token_version: _tv, ...user } = adminRow;
    res.json({ token, user });
  });

  app.post('/api/auth/logout', requireAuth, (req: AuthedRequest, res) => {
    revokeTokenJti(req.auth!.jti, req.auth!.exp);
    res.json({ ok: true });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
    const user = db
      .prepare(
        'SELECT id, account_number, role, name, phone, avatar_url, status, terms_accepted_version, terms_accepted_at, created_at FROM users WHERE id = ?',
      )
      .get(req.auth!.userId) as
      | {
          id: string;
          account_number: string;
          role: string;
          terms_accepted_version?: string | null;
        }
      | undefined;
    let driverProfile: DriverProfile | null = null;
    let driverWallet = null;
    let plusSubscription = null;
    const activeCommissionPercent = getCommissionPercent();

    if (req.auth!.role === 'driver') {
      driverProfile = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(req.auth!.userId) as DriverProfile | null;
      driverWallet = getOrCreateDriverWallet(req.auth!.userId);
    }
    if (req.auth!.role === 'customer') {
      const now = new Date().toISOString();
      plusSubscription =
        db
          .prepare(
            `SELECT * FROM plus_subscriptions
             WHERE user_id = ? AND status = 'active' AND ends_at >= ?
             ORDER BY ends_at DESC LIMIT 1`,
          )
          .get(req.auth!.userId, now) ?? null;
    }
    const currentTermsVersion =
      req.auth!.role === 'driver' ? DRIVER_TERMS_VERSION : req.auth!.role === 'customer' ? CUSTOMER_TERMS_VERSION : null;
    const needsTermsAcceptance = Boolean(
      currentTermsVersion && user && user.terms_accepted_version !== currentTermsVersion,
    );
    const requiresCommissionConsent =
      req.auth!.role === 'driver' &&
      Boolean(
        !driverProfile ||
          driverProfile.agreed_commission_percent == null ||
          Math.abs(driverProfile.agreed_commission_percent - activeCommissionPercent) > 0.0001,
      );

    res.json({
      user,
      driverProfile,
      driverWallet,
      plusSubscription,
      needsTermsAcceptance,
      currentTermsVersion,
      activeCommissionPercent,
      requiresCommissionConsent,
    });
  });

  app.patch('/api/auth/profile', requireAuth, (req: AuthedRequest, res) => {
    if ('account_number' in req.body) {
      recordSecurityEvent({
        severity: 'high',
        eventType: 'tampered_input_blocked',
        actorUserId: req.auth!.userId,
        ipAddress: req.ip,
        summary: 'محاولة تعديل رقم الحساب التسلسلي الثابت من طرف العميل — تم رفض الطلب',
      });
      res.status(403).json({ error: 'رقم الحساب التسلسلي ثابت ولا يمكن تعديله نهائياً' });
      return;
    }

    const { name, avatarUrl } = req.body as { name?: string; avatarUrl?: string | null };
    const cleanName = name?.trim();
    if (cleanName && (cleanName.length < 2 || cleanName.length > 80)) {
      res.status(400).json({ error: 'الاسم غير صالح' });
      return;
    }
    db.prepare(
      `UPDATE users SET name = COALESCE(?, name), avatar_url = COALESCE(?, avatar_url) WHERE id = ?`,
    ).run(cleanName || null, avatarUrl ?? null, req.auth!.userId);
    const user = db
      .prepare(
        'SELECT id, account_number, role, name, phone, avatar_url, status, terms_accepted_version, terms_accepted_at, created_at FROM users WHERE id = ?',
      )
      .get(req.auth!.userId);
    res.json({ user });
  });

  app.post('/api/legal/accept-terms', requireAuth, (req: AuthedRequest, res) => {
    if (req.auth!.role !== 'customer' && req.auth!.role !== 'driver') {
      res.status(400).json({ error: 'موافقة الاتفاقية مخصصة للزبائن والسائقين' });
      return;
    }
    const now = new Date().toISOString();
    const version = req.auth!.role === 'driver' ? DRIVER_TERMS_VERSION : CUSTOMER_TERMS_VERSION;
    const docType = req.auth!.role === 'driver' ? 'driver_terms' : 'customer_terms';
    const commPct = req.auth!.role === 'driver' ? getCommissionPercent() : null;

    const tx = db.transaction(() => {
      const uRow = db.prepare('SELECT account_number FROM users WHERE id = ?').get(req.auth!.userId) as
        | { account_number: string }
        | undefined;
      db.prepare('UPDATE users SET terms_accepted_version = ?, terms_accepted_at = ? WHERE id = ?').run(
        version,
        now,
        req.auth!.userId,
      );
      db.prepare(
        `INSERT INTO legal_acceptances (id, user_id, account_number, role, doc_type, version, commission_percent, accepted_at, ip_address)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        crypto.randomUUID(),
        req.auth!.userId,
        uRow?.account_number || req.auth!.userId,
        req.auth!.role,
        docType,
        version,
        commPct,
        now,
        req.ip || null,
      );
    });
    tx.immediate();

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: req.auth!.role,
      action: 'legal.terms_accepted',
      targetType: 'user',
      targetId: req.auth!.userId,
      details: { docType, version },
    });

    const user = db
      .prepare(
        'SELECT id, account_number, role, name, phone, avatar_url, status, terms_accepted_version, terms_accepted_at, created_at FROM users WHERE id = ?',
      )
      .get(req.auth!.userId);
    res.json({ user, needsTermsAcceptance: false, currentTermsVersion: version });
  });

  // ==================== CUSTOMER PRICING, PLUS & RIDES ====================
  function areValidCoords(lat1: number, lng1: number, lat2: number, lng2: number): boolean {
    if (![lat1, lng1, lat2, lng2].every(Number.isFinite)) return false;
    if (lat1 < -90 || lat1 > 90 || lat2 < -90 || lat2 > 90) return false;
    if (lng1 < -180 || lng1 > 180 || lng2 < -180 || lng2 > 180) return false;
    return true;
  }

  app.post('/api/rides/estimate', requireAuth, requireRole('customer'), async (req: AuthedRequest, res) => {
    const { pickupLat, pickupLng, dropoffLat, dropoffLng, promoCode } = req.body as {
      pickupLat: number;
      pickupLng: number;
      dropoffLat: number;
      dropoffLng: number;
      promoCode?: string;
    };
    if (!areValidCoords(pickupLat, pickupLng, dropoffLat, dropoffLng)) {
      res.status(400).json({ error: 'إحداثيات الانطلاق والوجهة غير صالحة' });
      return;
    }
    const straightKm = haversineKm(pickupLat, pickupLng, dropoffLat, dropoffLng);
    if (straightKm < 0.05) {
      res.status(400).json({ error: 'نقطة الانطلاق والوجهة متطابقتان تقريباً' });
      return;
    }
    const route = await computeRouteOSRM(pickupLat, pickupLng, dropoffLat, dropoffLng);
    const categories: VehicleCategory[] = ['Economy', 'Super', 'Plus', 'Family'];
    const estimates = categories.map((category) =>
      calculateFareServer({
        customerId: req.auth!.userId,
        category,
        distanceKm: route.distance_km,
        durationMin: route.duration_min,
        promoCode,
      }),
    );
    res.json({ route, estimates });
  });

  app.get('/api/plus/info', requireAuth, (req: AuthedRequest, res) => {
    const settings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get();
    const sub = db
      .prepare('SELECT * FROM plus_subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1')
      .get(req.auth!.userId);
    res.json({ settings, subscription: sub ?? null });
  });

  app.post('/api/plus/subscribe', requireAuth, requireRole('customer'), (req: AuthedRequest, res) => {
    const settings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get() as PlusSettings;
    if (settings.is_enabled !== 1) {
      res.status(400).json({ error: 'نظام اشتراك MISHWAR PLUS غير مفعل حالياً' });
      return;
    }
    const existing = hasActivePlusSubscription(req.auth!.userId);
    if (existing) {
      res.status(409).json({ error: 'لديك اشتراك MISHWAR PLUS نشط بالفعل' });
      return;
    }

    const now = new Date();
    const ends = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO plus_subscriptions (id, user_id, status, price_iqd, starts_at, ends_at, created_at)
       VALUES (?, ?, 'active', ?, ?, ?, ?)`,
    ).run(id, req.auth!.userId, settings.monthly_price_iqd, now.toISOString(), ends.toISOString(), now.toISOString());

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'customer',
      action: 'plus.subscribed',
      targetType: 'plus_subscription',
      targetId: id,
      details: { price_iqd: settings.monthly_price_iqd },
    });

    const subscription = db.prepare('SELECT * FROM plus_subscriptions WHERE id = ?').get(id);
    res.status(201).json({ subscription });
  });

  app.post('/api/rides', requireAuth, requireRole('customer'), async (req: AuthedRequest, res) => {
    const {
      category,
      pickupLat,
      pickupLng,
      pickupAddress,
      dropoffLat,
      dropoffLng,
      dropoffAddress,
      promoCode,
      paymentMethod,
    } = req.body as Record<string, unknown>;

    const validCats: VehicleCategory[] = ['Economy', 'Super', 'Plus', 'Family'];
    if (!validCats.includes(category as VehicleCategory)) {
      res.status(400).json({ error: 'فئة الخدمة غير صالحة' });
      return;
    }
    const chosenMethod: PaymentMethod =
      paymentMethod === 'superqi' || paymentMethod === 'zaincash' ? paymentMethod : 'cash';
    try {
      assertGatewayAvailable(chosenMethod);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'طريقة الدفع غير متاحة حالياً' });
      return;
    }
    const pLat = Number(pickupLat);
    const pLng = Number(pickupLng);
    const dLat = Number(dropoffLat);
    const dLng = Number(dropoffLng);
    if (!areValidCoords(pLat, pLng, dLat, dLng)) {
      res.status(400).json({ error: 'إحداثيات الرحلة غير صالحة' });
      return;
    }
    if (haversineKm(pLat, pLng, dLat, dLng) < 0.05) {
      res.status(400).json({ error: 'يرجى تحديد وجهة مختلفة عن نقطة الانطلاق' });
      return;
    }

    // Detect suspicious client attempt to inject price/discount fields
    if ('final_fare_iqd' in req.body || 'base_fare_iqd' in req.body || 'discount_iqd' in req.body) {
      recordSecurityEvent({
        severity: 'medium',
        eventType: 'tampered_input_blocked',
        actorUserId: req.auth!.userId,
        ipAddress: req.ip,
        summary: 'محاولة إرسال حقول تسعير معدلة من طرف العميل — تم تجاهلها وحساب السعر من الخادم',
      });
    }

    const custTerms = db
      .prepare('SELECT terms_accepted_version FROM users WHERE id = ?')
      .get(req.auth!.userId) as { terms_accepted_version?: string | null } | undefined;
    if (!custTerms || custTerms.terms_accepted_version !== CUSTOMER_TERMS_VERSION) {
      res.status(403).json({
        error: 'يرجى قراءة والموافقة على اتفاقية الاستخدام المحدّثة قبل طلب رحلة',
      });
      return;
    }

    const activeExisting = db
      .prepare(
        `SELECT id FROM rides
         WHERE customer_id = ? AND status IN ('searching', 'found', 'on_the_way', 'arrived', 'in_progress')`,
      )
      .get(req.auth!.userId);
    if (activeExisting) {
      res.status(409).json({ error: 'لديك رحلة جارية بالفعل' });
      return;
    }

    const route = await computeRouteOSRM(pLat, pLng, dLat, dLng);
    const fare = calculateFareServer({
      customerId: req.auth!.userId,
      category: category as VehicleCategory,
      distanceKm: route.distance_km,
      durationMin: route.duration_min,
      promoCode: typeof promoCode === 'string' ? promoCode : undefined,
    });
    const commSplit = computeCommissionSplit(fare.final_fare_iqd);

    const rideId = crypto.randomUUID();
    const now = new Date().toISOString();
    let rideNumber = '';

    const insertTx = db.transaction(() => {
      rideNumber = allocateSequenceNumberInTx('MSH-TR');
      db.prepare(
        `INSERT INTO rides (
          id, ride_number, customer_id, category, status,
          pickup_lat, pickup_lng, pickup_address,
          dropoff_lat, dropoff_lng, dropoff_address,
          distance_km, duration_min,
          base_fare_iqd, distance_fare_iqd, discount_iqd, final_fare_iqd,
          promo_code, payment_method, payment_status,
          commission_percent, commission_iqd, driver_net_iqd, created_at
        ) VALUES (?, ?, ?, ?, 'searching', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)`,
      ).run(
        rideId,
        rideNumber,
        req.auth!.userId,
        category,
        pLat,
        pLng,
        String(pickupAddress || 'نقطة الانطلاق').trim().slice(0, 180),
        dLat,
        dLng,
        String(dropoffAddress || 'الوجهة المحددة').trim().slice(0, 180),
        fare.distance_km,
        fare.duration_min,
        fare.base_fare_iqd,
        fare.distance_fare_iqd,
        fare.discount_iqd,
        fare.final_fare_iqd,
        fare.promo_applied,
        chosenMethod,
        commSplit.commission_percent,
        commSplit.commission_iqd,
        commSplit.driver_net_iqd,
        now,
      );
    });
    insertTx.immediate();

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'customer',
      action: 'ride.created',
      targetType: 'ride',
      targetId: rideId,
      details: { ride_number: rideNumber, category, distance_km: fare.distance_km, final_fare_iqd: fare.final_fare_iqd, payment_method: chosenMethod },
    });

    const ride = getEnrichedRide(rideId)!;
    broadcastRideUpdate(ride);

    // Customer Notification #1 & #2
    if (triggerRideMilestone(ride.id, 'customer_received')) {
      createNotification({
        userId: ride.customer_id,
        title: 'تم استلام طلب رحلتك.',
        body: `من ${ride.pickup_address} إلى ${ride.dropoff_address}`,
        type: 'ride_received',
        rideId: ride.id,
      });
    }
    if (triggerRideMilestone(ride.id, 'customer_searching')) {
      createNotification({
        userId: ride.customer_id,
        title: 'جاري البحث عن سائق.',
        body: 'يقوم النظام بالبحث عن أقرب سائق متاح لفئتك.',
        type: 'ride_searching',
        rideId: ride.id,
      });
    }

    const dispatched = dispatchNextDriver(rideId);

    res.status(201).json({ ride, dispatched, route });
  });

  app.post('/api/rides/:id/retry', requireAuth, requireRole('customer'), (req: AuthedRequest, res) => {
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND customer_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride || ride.status !== 'searching') {
      res.status(400).json({ error: 'لا يمكن إعادة البحث لهذه الرحلة' });
      return;
    }
    db.prepare('DELETE FROM ride_dispatch_attempts WHERE ride_id = ?').run(ride.id);
    const dispatched = dispatchNextDriver(ride.id);
    res.json({ dispatched });
  });

  app.patch('/api/rides/:id/pickup', requireAuth, requireRole('customer'), async (req: AuthedRequest, res) => {
    const { pickupLat, pickupLng, pickupAddress } = req.body as {
      pickupLat?: number;
      pickupLng?: number;
      pickupAddress?: string;
    };
    const pLat = Number(pickupLat);
    const pLng = Number(pickupLng);
    if (!areValidCoords(pLat, pLng, pLat, pLng)) {
      res.status(400).json({ error: 'إحداثيات نقطة الانطلاق غير صالحة' });
      return;
    }
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND customer_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }
    if (!['searching', 'found', 'on_the_way', 'arrived'].includes(ride.status)) {
      res.status(400).json({ error: 'لا يمكن تعديل موقع الانطلاق بعد بدء الرحلة' });
      return;
    }

    const cleanAddr = String(pickupAddress || '').trim().slice(0, 180) || (await reverseGeocodeIraq(pLat, pLng));
    db.prepare('UPDATE rides SET pickup_lat = ?, pickup_lng = ?, pickup_address = ? WHERE id = ?').run(
      pLat,
      pLng,
      cleanAddr,
      ride.id,
    );

    const updated = getEnrichedRide(ride.id)!;
    broadcastRideUpdate(updated);
    if (ride.driver_id) {
      createNotification({
        userId: ride.driver_id,
        title: 'تم تحديث موقع الانطلاق.',
        body: `الموقع الجديد للزبون: ${cleanAddr}`,
        type: 'pickup_updated',
        rideId: ride.id,
      });
    }
    res.json({ ride: updated });
  });

  app.post('/api/rides/:id/notify-waiting', requireAuth, (req: AuthedRequest, res) => {
    const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }
    if (ride.status === 'completed' || ride.status === 'cancelled') {
      res.status(400).json({ error: 'الرحلة منتهية' });
      return;
    }

    if (req.auth!.role === 'customer' && ride.customer_id === req.auth!.userId) {
      if (!ride.driver_id) {
        res.status(400).json({ error: 'لم يتم تعيين سائق بعد' });
        return;
      }
      createNotification({
        userId: ride.driver_id,
        title: 'الزبون ينتظرك.',
        body: `الزبون بانتظارك عند نقطة الانطلاق: ${ride.pickup_address}`,
        type: 'customer_waiting',
        rideId: ride.id,
      });
      res.json({ ok: true });
      return;
    }

    if (req.auth!.role === 'driver' && ride.driver_id === req.auth!.userId) {
      createNotification({
        userId: ride.customer_id,
        title: 'السائق ينتظرك.',
        body: 'الكابتن بانتظارك في نقطة الانطلاق.',
        type: 'driver_waiting',
        rideId: ride.id,
      });
      res.json({ ok: true });
      return;
    }

    res.status(403).json({ error: 'غير مصرح' });
  });

  app.get('/api/rides/active', requireAuth, (req: AuthedRequest, res) => {
    let row: { id: string } | undefined;
    if (req.auth!.role === 'customer') {
      row = db
        .prepare(
          `SELECT id FROM rides
           WHERE customer_id = ? AND status IN ('searching', 'found', 'on_the_way', 'arrived', 'in_progress')
           ORDER BY created_at DESC LIMIT 1`,
        )
        .get(req.auth!.userId) as { id: string } | undefined;
    } else if (req.auth!.role === 'driver') {
      row = db
        .prepare(
          `SELECT id FROM rides
           WHERE driver_id = ? AND status IN ('found', 'on_the_way', 'arrived', 'in_progress')
           ORDER BY created_at DESC LIMIT 1`,
        )
        .get(req.auth!.userId) as { id: string } | undefined;
    }
    const ride = row ? getEnrichedRide(row.id) : null;
    res.json({ ride });
  });

  app.get('/api/rides/history', requireAuth, (req: AuthedRequest, res) => {
    const col = req.auth!.role === 'driver' ? 'r.driver_id' : 'r.customer_id';
    const rows = db
      .prepare(
        `SELECT r.*,
                cu.name AS customer_name, cu.account_number AS customer_account_number, cu.phone AS raw_customer_phone,
                du.name AS driver_name, du.account_number AS driver_account_number, du.phone AS raw_driver_phone, du.avatar_url AS raw_driver_avatar,
                dp.photo_status AS driver_photo_status,
                dp.car_make, dp.car_model, dp.car_color, dp.plate_number
         FROM rides r
         JOIN users cu ON cu.id = r.customer_id
         LEFT JOIN users du ON du.id = r.driver_id
         LEFT JOIN driver_profiles dp ON dp.user_id = r.driver_id
         WHERE ${col} = ?
         ORDER BY r.created_at DESC
         LIMIT 50`,
      )
      .all(req.auth!.userId) as Array<
      Ride & {
        raw_customer_phone?: string | null;
        raw_driver_phone?: string | null;
        raw_driver_avatar?: string | null;
        driver_photo_status?: string | null;
      }
    >;

    const rides = rows.map(
      ({ raw_customer_phone, raw_driver_phone, raw_driver_avatar, driver_photo_status, ...rest }) => ({
        ...rest,
        customer_phone_masked: maskIraqiPhone(raw_customer_phone),
        driver_phone_masked: maskIraqiPhone(raw_driver_phone),
        driver_avatar:
          rest.driver_id &&
          rest.status !== 'searching' &&
          rest.status !== 'cancelled' &&
          driver_photo_status === 'approved'
            ? (raw_driver_avatar ?? null)
            : null,
      }),
    );

    res.json({ rides });
  });

  app.post('/api/rides/:id/cancel', requireAuth, (req: AuthedRequest, res) => {
    const { reason } = req.body as { reason?: string };
    const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }
    const isOwner =
      (req.auth!.role === 'customer' && ride.customer_id === req.auth!.userId) ||
      (req.auth!.role === 'driver' && ride.driver_id === req.auth!.userId) ||
      req.auth!.role === 'admin';
    if (!isOwner) {
      res.status(403).json({ error: 'غير مصرح بإلغاء هذه الرحلة' });
      return;
    }
    if (ride.status === 'completed' || ride.status === 'cancelled') {
      res.status(400).json({ error: 'الرحلة منتهية بالفعل' });
      return;
    }
    if (ride.status === 'in_progress' && req.auth!.role === 'customer') {
      res.status(400).json({ error: 'لا يمكن إلغاء الرحلة بعد بدئها، يرجى الطلب من السائق إنهاء الرحلة' });
      return;
    }

    let cancellationFee = 0;
    if (req.auth!.role === 'customer' && (ride.status === 'on_the_way' || ride.status === 'arrived')) {
      const pricing = db.prepare('SELECT cancellation_fee_iqd FROM pricing_rules WHERE id = 1').get() as {
        cancellation_fee_iqd: number;
      };
      const plusSettings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get() as PlusSettings;
      const waive =
        plusSettings.is_enabled === 1 &&
        plusSettings.waive_cancellation_fee === 1 &&
        hasActivePlusSubscription(ride.customer_id);
      cancellationFee = waive ? 0 : pricing.cancellation_fee_iqd;
    }

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE rides
       SET status = 'cancelled', cancelled_by = ?, cancel_reason = ?,
           cancellation_fee_iqd = ?, final_fare_iqd = ?, cancelled_at = ?
       WHERE id = ?`,
    ).run(
      req.auth!.role,
      reason?.trim().slice(0, 200) || 'إلغاء من المستخدم',
      cancellationFee,
      cancellationFee > 0 ? cancellationFee : 0,
      now,
      ride.id,
    );

    db.prepare(
      `UPDATE ride_dispatch_attempts SET status = 'timeout', responded_at = ?
       WHERE ride_id = ? AND status = 'offered'`,
    ).run(now, ride.id);

    // Auto-purge unflagged ride chat messages immediately upon cancellation
    closeAndPurgeRideChat(ride.id);
    // Auto-stop any live trip share links immediately upon cancellation
    db.prepare(
      `UPDATE ride_shares SET is_active = 0, revoked_at = COALESCE(revoked_at, ?) WHERE ride_id = ? AND is_active = 1`,
    ).run(now, ride.id);

    const updated = getEnrichedRide(ride.id)!;
    broadcastRideUpdate(updated);

    if (ride.driver_id) {
      createNotification({
        userId: ride.driver_id,
        title: 'تم إلغاء الرحلة.',
        body: `تم إلغاء الرحلة (${updated.pickup_address})`,
        type: 'ride_cancelled',
        rideId: ride.id,
      });
    }
    createNotification({
      userId: ride.customer_id,
      title: 'تم إلغاء الرحلة.',
      body: updated.cancel_reason || 'تم إلغاء الرحلة',
      type: 'ride_cancelled',
      rideId: ride.id,
    });

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: req.auth!.role,
      action: 'ride.cancelled',
      targetType: 'ride',
      targetId: ride.id,
      details: { cancellationFee, reason },
    });

    res.json({ ride: updated });
  });

  app.post('/api/rides/:id/rate', requireAuth, requireRole('customer'), (req: AuthedRequest, res) => {
    const { rating, review } = req.body as { rating: number; review?: string };
    const numRating = Math.round(Number(rating));
    if (!Number.isFinite(numRating) || numRating < 1 || numRating > 5) {
      res.status(400).json({ error: 'التقييم يجب أن يكون من 1 إلى 5' });
      return;
    }
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND customer_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride || ride.status !== 'completed' || !ride.driver_id) {
      res.status(400).json({ error: 'يمكن تقييم السائق فقط بعد انتهاء الرحلة' });
      return;
    }
    if (ride.driver_rating != null) {
      res.status(409).json({ error: 'تم تقييم هذه الرحلة مسبقاً' });
      return;
    }

    const tx = db.transaction(() => {
      db.prepare('UPDATE rides SET driver_rating = ?, driver_review = ? WHERE id = ?').run(
        numRating,
        review?.trim().slice(0, 300) || null,
        ride.id,
      );
      const stats = db
        .prepare(
          `SELECT AVG(driver_rating) AS avg_r, COUNT(driver_rating) AS cnt
           FROM rides WHERE driver_id = ? AND driver_rating IS NOT NULL AND rating_moderated = 0`,
        )
        .get(ride.driver_id) as { avg_r: number; cnt: number };
      db.prepare('UPDATE driver_profiles SET rating_avg = ?, rating_count = ? WHERE user_id = ?').run(
        Number((stats.avg_r || 5).toFixed(2)),
        stats.cnt,
        ride.driver_id,
      );
    });
    tx();

    const updated = getEnrichedRide(ride.id)!;
    res.json({ ride: updated });
  });

  app.post('/api/rides/:id/rate-customer', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const { rating, review } = req.body as { rating: number; review?: string };
    const numRating = Math.round(Number(rating));
    if (!Number.isFinite(numRating) || numRating < 1 || numRating > 5) {
      res.status(400).json({ error: 'التقييم يجب أن يكون من 1 إلى 5' });
      return;
    }
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND driver_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride || ride.status !== 'completed') {
      res.status(400).json({ error: 'يمكن تقييم الزبون فقط بعد انتهاء الرحلة' });
      return;
    }
    if (ride.customer_rating != null) {
      res.status(409).json({ error: 'تم تقييم الزبون لهذه الرحلة مسبقاً' });
      return;
    }

    const tx = db.transaction(() => {
      db.prepare('UPDATE rides SET customer_rating = ?, customer_review = ? WHERE id = ?').run(
        numRating,
        review?.trim().slice(0, 300) || null,
        ride.id,
      );
      const stats = db
        .prepare(
          `SELECT AVG(customer_rating) AS avg_r, COUNT(customer_rating) AS cnt
           FROM rides WHERE customer_id = ? AND customer_rating IS NOT NULL AND rating_moderated = 0`,
        )
        .get(ride.customer_id) as { avg_r: number; cnt: number };
      db.prepare('UPDATE users SET rating_avg = ?, rating_count = ? WHERE id = ?').run(
        Number((stats.avg_r || 5).toFixed(2)),
        stats.cnt,
        ride.customer_id,
      );
    });
    tx();

    const updated = getEnrichedRide(ride.id)!;
    res.json({ ride: updated });
  });

  // ==================== DRIVER APP, زر مشوار & ANTI-SPOOFING GPS ====================
  app.post('/api/driver/commission/accept', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const activeCommPct = getCommissionPercent();
    const now = new Date().toISOString();

    const tx = db.transaction(() => {
      const uRow = db.prepare('SELECT account_number FROM users WHERE id = ?').get(req.auth!.userId) as
        | { account_number: string }
        | undefined;
      db.prepare(
        `UPDATE driver_profiles
         SET agreed_commission_percent = ?, commission_agreed_at = ?
         WHERE user_id = ?`,
      ).run(activeCommPct, now, req.auth!.userId);
      db.prepare(
        `INSERT INTO legal_acceptances (id, user_id, account_number, role, doc_type, version, commission_percent, accepted_at, ip_address)
         VALUES (?, ?, ?, 'driver', 'commission_change', ?, ?, ?, ?)`,
      ).run(
        crypto.randomUUID(),
        req.auth!.userId,
        uRow?.account_number || req.auth!.userId,
        DRIVER_TERMS_VERSION,
        activeCommPct,
        now,
        req.ip || null,
      );
    });
    tx.immediate();

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'driver',
      action: 'driver.commission_accepted',
      targetType: 'driver_profile',
      targetId: req.auth!.userId,
      details: { agreed_commission_percent: activeCommPct },
    });

    const driverProfile = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(req.auth!.userId);
    res.json({
      driverProfile,
      activeCommissionPercent: activeCommPct,
      requiresCommissionConsent: false,
    });
  });

  app.post('/api/driver/mishwar-toggle', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const { isOnline, lat, lng } = req.body as { isOnline: boolean; lat?: number; lng?: number };
    const profile = db
      .prepare('SELECT * FROM driver_profiles WHERE user_id = ?')
      .get(req.auth!.userId) as DriverProfile | undefined;

    if (!profile) {
      res.status(404).json({ error: 'ملف السائق غير موجود' });
      return;
    }
    if (profile.approval_status !== 'approved') {
      res.status(403).json({
        error:
          profile.approval_status === 'rejected'
            ? `تم رفض طلبك: ${profile.rejection_reason || 'يرجى التواصل مع الإدارة'}`
            : 'حسابك بانتظار موافقة الإدارة قبل تفعيل مشوار',
      });
      return;
    }

    if (!isOnline) {
      const activeRide = db
        .prepare(
          `SELECT id FROM rides
           WHERE driver_id = ? AND status IN ('found', 'on_the_way', 'arrived', 'in_progress')`,
        )
        .get(req.auth!.userId);
      if (activeRide) {
        res.status(409).json({ error: 'لا يمكن إطفاء زر مشوار أثناء وجود رحلة نشطة' });
        return;
      }
      db.prepare('UPDATE driver_wallets SET auto_paused_zero_balance = 0 WHERE driver_id = ?').run(req.auth!.userId);
    } else {
      const driverUser = db
        .prepare('SELECT terms_accepted_version FROM users WHERE id = ?')
        .get(req.auth!.userId) as { terms_accepted_version?: string | null } | undefined;
      if (!driverUser || driverUser.terms_accepted_version !== DRIVER_TERMS_VERSION) {
        res.status(403).json({
          error: 'يرجى قراءة والموافقة على اتفاقية السائق المحدّثة أولاً قبل تفعيل زر مشوار',
        });
        return;
      }
      const activeCommPct = getCommissionPercent();
      if (
        profile.agreed_commission_percent == null ||
        Math.abs(profile.agreed_commission_percent - activeCommPct) > 0.0001
      ) {
        res.status(403).json({
          error: `تم تعديل نسبة عمولة مشوار إلى ${activeCommPct}% — يجب الموافقة على النسبة الجديدة أولاً قبل استقبال طلبات جديدة`,
        });
        return;
      }
      const wallet = getOrCreateDriverWallet(req.auth!.userId);
      if (wallet.bonus_balance_iqd + wallet.real_balance_iqd <= 0) {
        res.status(403).json({
          error: 'نفد رصيد محفظتك (0 د.ع) — يرجى شحن المحفظة لاستقبال الطلبات',
        });
        return;
      }
    }

    const nextState = isOnline ? 1 : 0;
    const now = new Date().toISOString();
    if (isOnline && Number.isFinite(lat) && Number.isFinite(lng) && lat! >= -90 && lat! <= 90 && lng! >= -180 && lng! <= 180) {
      db.prepare(
        `UPDATE driver_profiles
         SET is_online = ?, current_lat = ?, current_lng = ?, last_location_at = ?
         WHERE user_id = ?`,
      ).run(nextState, lat, lng, now, req.auth!.userId);
    } else {
      db.prepare(
        `UPDATE driver_profiles
         SET is_online = ?, current_speed_kmh = CASE WHEN ? = 0 THEN NULL ELSE current_speed_kmh END
         WHERE user_id = ?`,
      ).run(nextState, nextState, req.auth!.userId);
    }

    const updated = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(req.auth!.userId);
    sendToAdmins('admin:driver_status', updated);
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'driver',
      action: isOnline ? 'driver.mishwar_on' : 'driver.mishwar_off',
      targetType: 'driver_profile',
      targetId: req.auth!.userId,
    });

    res.json({ driverProfile: updated });
  });

  app.post('/api/driver/location', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const { lat, lng, speedMs, heading, gpsAvailable } = req.body as {
      lat?: number;
      lng?: number;
      speedMs?: number | null;
      heading?: number | null;
      gpsAvailable?: boolean;
    };

    const profile = db
      .prepare('SELECT * FROM driver_profiles WHERE user_id = ?')
      .get(req.auth!.userId) as DriverProfile | undefined;
    if (!profile) {
      res.status(404).json({ error: 'ملف السائق غير موجود' });
      return;
    }

    const activeRide = db
      .prepare(
        `SELECT id, customer_id, status FROM rides
         WHERE driver_id = ? AND status IN ('found', 'on_the_way', 'arrived', 'in_progress')
         LIMIT 1`,
      )
      .get(req.auth!.userId) as { id: string; customer_id: string; status: string } | undefined;

    if (profile.is_online !== 1 && !activeRide) {
      res.status(409).json({ error: 'مشوار متوقف ولا توجد رحلة نشطة' });
      return;
    }

    if (gpsAvailable === false || !Number.isFinite(lat) || !Number.isFinite(lng)) {
      db.prepare('UPDATE driver_profiles SET current_speed_kmh = NULL WHERE user_id = ?').run(req.auth!.userId);
      if (activeRide) {
        sendToUser(activeRide.customer_id, 'driver:location', {
          ride_id: activeRide.id,
          lat: profile.current_lat,
          lng: profile.current_lng,
          speed_kmh: null,
          heading: profile.heading,
          gps_lost: true,
        });
      }
      res.json({ speed_kmh: null, gps_lost: true });
      return;
    }

    if (lat! < -90 || lat! > 90 || lng! < -180 || lng! > 180) {
      res.status(400).json({ error: 'إحداثيات الموقع غير صالحة' });
      return;
    }

    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();

    // Anti-GPS-Spoofing & Impossible Jump Detection
    let displacementSpeedKmh: number | null = null;
    if (profile.current_lat != null && profile.current_lng != null && profile.last_location_at) {
      const prevMs = Date.parse(profile.last_location_at);
      const dtSec = (nowMs - prevMs) / 1000;
      const distKm = haversineKm(profile.current_lat, profile.current_lng, lat!, lng!);

      if (dtSec > 0 && dtSec < 120) {
        const impliedKmh = (distKm / dtSec) * 3600;
        // Reject impossible teleportation jumps (> 180 km/h)
        if (impliedKmh > 180 && distKm > 0.5) {
          recordSecurityEvent({
            severity: 'high',
            eventType: 'gps_spoof_suspected',
            actorUserId: req.auth!.userId,
            ipAddress: req.ip,
            summary: `اشتباه في تزوير موقع GPS للسائق: قفزة ${distKm.toFixed(1)} كم خلال ${dtSec.toFixed(1)} ثانية (${Math.round(impliedKmh)} كم/س)`,
            details: { distKm, dtSec, impliedKmh, lat, lng },
          });
          res.status(422).json({ error: 'تم رصد قفزة غير منطقية في إحداثيات GPS وتم تجاهل التحديث' });
          return;
        }
        if (dtSec >= 1 && dtSec <= 30) {
          displacementSpeedKmh = Math.round(impliedKmh);
        }
      }
    }

    let computedSpeedKmh: number | null = null;
    if (typeof speedMs === 'number' && Number.isFinite(speedMs) && speedMs >= 0) {
      const reportedKmh = Math.round(speedMs * 3.6);
      if (reportedKmh > 180) {
        recordSecurityEvent({
          severity: 'medium',
          eventType: 'gps_speed_tampering',
          actorUserId: req.auth!.userId,
          ipAddress: req.ip,
          summary: `سرعة GPS غير منطقية مرسلة من جهاز السائق (${reportedKmh} كم/س)`,
        });
        computedSpeedKmh = displacementSpeedKmh;
      } else if (displacementSpeedKmh != null && Math.abs(reportedKmh - displacementSpeedKmh) > 65) {
        // Cross-check client speed against actual displacement
        computedSpeedKmh = displacementSpeedKmh;
      } else {
        computedSpeedKmh = reportedKmh;
      }
    } else {
      computedSpeedKmh = displacementSpeedKmh;
    }

    db.prepare(
      `UPDATE driver_profiles
       SET current_lat = ?, current_lng = ?, current_speed_kmh = ?, heading = ?, last_location_at = ?
       WHERE user_id = ?`,
    ).run(
      lat,
      lng,
      computedSpeedKmh,
      typeof heading === 'number' && Number.isFinite(heading) ? heading : profile.heading,
      nowIso,
      req.auth!.userId,
    );

    if (activeRide) {
      sendToUser(activeRide.customer_id, 'driver:location', {
        ride_id: activeRide.id,
        lat,
        lng,
        speed_kmh: computedSpeedKmh,
        heading: heading ?? profile.heading,
        gps_lost: false,
        updated_at: nowIso,
      });

      const fullRide = db.prepare('SELECT * FROM rides WHERE id = ?').get(activeRide.id) as Ride | undefined;
      if (fullRide) {
        if (fullRide.status === 'on_the_way') {
          const distToPickup = haversineKm(lat!, lng!, fullRide.pickup_lat, fullRide.pickup_lng);
          if (distToPickup <= 0.6 && triggerRideMilestone(fullRide.id, 'customer_driver_approaching')) {
            createNotification({
              userId: fullRide.customer_id,
              title: 'السائق يقترب من موقعك.',
              body: `السائق على بعد ${Math.max(100, Math.round(distToPickup * 1000))} متر تقريباً.`,
              type: 'driver_approaching',
              rideId: fullRide.id,
            });
          }
        } else if (fullRide.status === 'in_progress') {
          if (triggerRideMilestone(fullRide.id, 'customer_en_route_dropoff')) {
            createNotification({
              userId: fullRide.customer_id,
              title: 'الرحلة في الطريق إلى الوجهة.',
              body: `نتمنى لك رحلة مريحة إلى ${fullRide.dropoff_address}`,
              type: 'ride_en_route',
              rideId: fullRide.id,
            });
          }
          const distToDropoff = haversineKm(lat!, lng!, fullRide.dropoff_lat, fullRide.dropoff_lng);
          if (distToDropoff <= 0.6 && triggerRideMilestone(fullRide.id, 'customer_approaching_dropoff')) {
            createNotification({
              userId: fullRide.customer_id,
              title: 'اقتربت من وجهتك.',
              body: `أنت على مقربة من ${fullRide.dropoff_address}`,
              type: 'approaching_dropoff',
              rideId: fullRide.id,
            });
          }
          if (distToDropoff <= 0.15 && triggerRideMilestone(fullRide.id, 'customer_arrived_dropoff')) {
            createNotification({
              userId: fullRide.customer_id,
              title: 'وصلت إلى وجهتك.',
              body: `تم الوصول إلى ${fullRide.dropoff_address}`,
              type: 'arrived_dropoff',
              rideId: fullRide.id,
            });
          }
        }
      }
    }

    sendToAdmins('admin:driver_location', {
      driver_id: req.auth!.userId,
      lat,
      lng,
      speed_kmh: computedSpeedKmh,
      heading: heading ?? profile.heading,
      active_ride_id: activeRide?.id ?? null,
    });

    res.json({ lat, lng, speed_kmh: computedSpeedKmh, updated_at: nowIso });
  });

  app.patch('/api/driver/photo', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const { avatarUrl } = req.body as { avatarUrl?: string };
    const m = String(avatarUrl || '').match(/^\/api\/uploads\/([a-f0-9-]+\.(?:jpg|png|webp))$/i);
    if (!m) {
      res.status(400).json({ error: 'رابط الصورة غير صالح' });
      return;
    }
    const filename = m[1];
    const rec = getUploadRecord(filename);
    if (!rec || (rec.owner_user_id && rec.owner_user_id !== req.auth!.userId)) {
      res.status(403).json({ error: 'غير مصرح باستخدام هذه الصورة' });
      return;
    }

    const tx = db.transaction(() => {
      db.prepare('UPDATE upload_records SET owner_user_id = ?, purpose = ? WHERE filename = ?').run(
        req.auth!.userId,
        'driver_avatar',
        filename,
      );
      const profile = db
        .prepare('SELECT photo_status FROM driver_profiles WHERE user_id = ?')
        .get(req.auth!.userId) as { photo_status: string } | undefined;

      // Never replace an already-approved customer-facing avatar with an unapproved one; hold in pending_avatar_url until Admin approves.
      if (!profile || profile.photo_status !== 'approved') {
        db.prepare('UPDATE users SET avatar_url = ? WHERE id = ?').run(avatarUrl, req.auth!.userId);
      }
      db.prepare(
        `UPDATE driver_profiles
         SET pending_avatar_url = ?, photo_status = 'pending', photo_rejection_reason = NULL
         WHERE user_id = ?`,
      ).run(avatarUrl, req.auth!.userId);
    });
    tx();

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'driver',
      action: 'driver.photo_uploaded',
      targetType: 'driver_profile',
      targetId: req.auth!.userId,
      details: { avatarUrl },
    });
    sendToAdmins('admin:driver_photo_pending', { userId: req.auth!.userId });

    const user = db
      .prepare(
        'SELECT id, account_number, role, name, phone, avatar_url, status, terms_accepted_version, terms_accepted_at, created_at FROM users WHERE id = ?',
      )
      .get(req.auth!.userId);
    const driverProfile = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(req.auth!.userId);
    res.json({ user, driverProfile });
  });

  app.get('/api/driver/offers', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const now = new Date().toISOString();
    const offer = db
      .prepare(
        `SELECT a.id AS attempt_id, a.ride_id, a.expires_at
         FROM ride_dispatch_attempts a
         JOIN rides r ON r.id = a.ride_id
         WHERE a.driver_id = ? AND a.status = 'offered' AND a.expires_at > ? AND r.status = 'searching'
         ORDER BY a.offered_at DESC LIMIT 1`,
      )
      .get(req.auth!.userId, now) as { attempt_id: string; ride_id: string; expires_at: string } | undefined;

    if (!offer) {
      res.json({ offer: null });
      return;
    }
    const ride = getEnrichedRide(offer.ride_id);
    res.json({
      offer: ride
        ? {
            attempt_id: offer.attempt_id,
            ride,
            expires_at: offer.expires_at,
          }
        : null,
    });
  });

  app.post('/api/driver/rides/:id/accept', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const result = acceptRideAtomic(req.params.id, req.auth!.userId);
    if (!result.ok) {
      res.status(409).json({ error: result.error });
      return;
    }
    res.json({ ride: result.ride });
  });

  app.post('/api/driver/rides/:id/reject', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const now = new Date().toISOString();
    db.prepare(
      `UPDATE ride_dispatch_attempts SET status = 'rejected', responded_at = ?
       WHERE ride_id = ? AND driver_id = ? AND status = 'offered'`,
    ).run(now, req.params.id, req.auth!.userId);

    dispatchNextDriver(req.params.id);
    res.json({ ok: true });
  });

  app.post('/api/driver/rides/:id/status', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const { status } = req.body as { status: 'arrived' | 'in_progress' | 'completed' };
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND driver_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }

    const now = new Date();
    const nowIso = now.toISOString();

    if (status === 'arrived') {
      if (ride.status !== 'on_the_way' && ride.status !== 'found') {
        res.status(400).json({ error: 'تسلسل حالة الرحلة غير صحيح' });
        return;
      }
      db.prepare(`UPDATE rides SET status = 'arrived', arrived_at = ? WHERE id = ?`).run(nowIso, ride.id);
      if (triggerRideMilestone(ride.id, 'customer_arrived_pickup')) {
        createNotification({
          userId: ride.customer_id,
          title: 'وصل السائق إلى موقعك.',
          body: 'الكابتن وصل إلى نقطة الانطلاق وبانتظارك.',
          type: 'ride_arrived',
          rideId: ride.id,
        });
      }
    } else if (status === 'in_progress') {
      if (ride.status !== 'arrived' && ride.status !== 'on_the_way') {
        res.status(400).json({ error: 'يجب الوصول لنقطة الانطلاق أولاً' });
        return;
      }
      let waitingMinutes = 0;
      let waitingFee = 0;
      if (ride.arrived_at) {
        const waited = Math.floor((now.getTime() - Date.parse(ride.arrived_at)) / 60000);
        if (waited > 3) {
          const pricing = db.prepare('SELECT waiting_fee_per_min_iqd FROM pricing_rules WHERE id = 1').get() as {
            waiting_fee_per_min_iqd: number;
          };
          waitingMinutes = waited - 3;
          waitingFee = waitingMinutes * pricing.waiting_fee_per_min_iqd;
        }
      }
      const newTotal = ride.final_fare_iqd + waitingFee;
      db.prepare(
        `UPDATE rides
         SET status = 'in_progress', started_at = ?, waiting_minutes = ?, waiting_fee_iqd = ?, final_fare_iqd = ?
         WHERE id = ?`,
      ).run(nowIso, waitingMinutes, waitingFee, newTotal, ride.id);

      if (triggerRideMilestone(ride.id, 'customer_started')) {
        createNotification({
          userId: ride.customer_id,
          title: 'بدأت الرحلة.',
          body: `رحلة سعيدة إلى ${ride.dropoff_address}`,
          type: 'ride_started',
          rideId: ride.id,
        });
      }
      if (triggerRideMilestone(ride.id, 'customer_en_route_dropoff')) {
        createNotification({
          userId: ride.customer_id,
          title: 'الرحلة في الطريق إلى الوجهة.',
          body: `متجهون الآن إلى ${ride.dropoff_address}`,
          type: 'ride_en_route',
          rideId: ride.id,
        });
      }
      if (triggerRideMilestone(ride.id, 'driver_started')) {
        createNotification({
          userId: req.auth!.userId,
          title: 'تم تأكيد بدء الرحلة.',
          body: `الوجهة: ${ride.dropoff_address}`,
          type: 'driver_ride_started',
          rideId: ride.id,
        });
      }
    } else if (status === 'completed') {
      if (ride.status !== 'in_progress') {
        res.status(400).json({ error: 'يجب بدء الرحلة أولاً قبل إنهائها' });
        return;
      }
      db.prepare(`UPDATE rides SET status = 'completed', completed_at = ? WHERE id = ?`).run(nowIso, ride.id);

      const method: PaymentMethod =
        ride.payment_method === 'superqi' || ride.payment_method === 'zaincash' ? ride.payment_method : 'cash';
      const settlement = completeRideSettlementAtomic({
        rideId: ride.id,
        rideNumber: ride.ride_number,
        driverId: req.auth!.userId,
        customerId: ride.customer_id,
        fareIqd: ride.final_fare_iqd,
        paymentMethod: method,
      });

      sendToUser(req.auth!.userId, 'wallet:updated', settlement.wallet);
      if (settlement.autoPausedZeroBalance) {
        const pausedDp = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(req.auth!.userId);
        sendToAdmins('admin:driver_status', pausedDp);
        createNotification({
          userId: req.auth!.userId,
          title: 'نفد رصيد محفظتك — يرجى شحن المحفظة',
          body: 'تم إيقاف استقبال الطلبات الجديدة تلقائياً لوصول رصيد المحفظة إلى 0 د.ع. اشحن المحفظة لإعادة التفعيل.',
          type: 'wallet_zero_balance',
          rideId: ride.id,
        });
      }

      if (triggerRideMilestone(ride.id, 'customer_arrived_dropoff')) {
        createNotification({
          userId: ride.customer_id,
          title: 'وصلت إلى وجهتك.',
          body: `وصلت إلى ${ride.dropoff_address}`,
          type: 'arrived_dropoff',
          rideId: ride.id,
        });
      }
      if (triggerRideMilestone(ride.id, 'customer_completed')) {
        const payMsg =
          method === 'cash'
            ? `المبلغ المطلوب نقداً: ${ride.final_fare_iqd.toLocaleString()} د.ع. يرجى تقييم الكابتن.`
            : `المبلغ المطلوب: ${ride.final_fare_iqd.toLocaleString()} د.ع — يرجى إتمام الدفع عبر ${method === 'superqi' ? 'سوبر كي' : 'زين كاش'}.`;
        createNotification({
          userId: ride.customer_id,
          title: 'انتهت الرحلة بنجاح.',
          body: payMsg,
          type: 'ride_completed',
          rideId: ride.id,
        });
      }

      // Policy: Auto-purge all unflagged messages immediately upon ride completion
      closeAndPurgeRideChat(ride.id);
      // Auto-stop any live trip share links immediately upon ride completion
      db.prepare(
        `UPDATE ride_shares SET is_active = 0, revoked_at = COALESCE(revoked_at, ?) WHERE ride_id = ? AND is_active = 1`,
      ).run(nowIso, ride.id);
    } else {
      res.status(400).json({ error: 'حالة غير مدعومة' });
      return;
    }

    const updated = getEnrichedRide(ride.id)!;
    broadcastRideUpdate(updated);
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'driver',
      action: `ride.${status}`,
      targetType: 'ride',
      targetId: ride.id,
    });
    res.json({ ride: updated });
  });

  // ==================== IN-RIDE INLINE CHAT & MASKED CALLS ====================
  app.get('/api/comm/capabilities', requireAuth, (_req, res) => {
    res.json(getMaskedCallCapabilities());
  });

  app.get('/api/rides/:id/messages', requireAuth, (req: AuthedRequest, res) => {
    const check = assertRideChatParticipant(req.params.id, req.auth!.userId, false);
    if (!check.ok) {
      res.status(check.status).json({ error: check.error });
      return;
    }
    const closed = check.ride.status === 'completed' || check.ride.status === 'cancelled';
    const messages = listRideMessages(req.params.id);
    res.json({ messages, closed });
  });

  app.post('/api/rides/:id/messages', requireAuth, (req: AuthedRequest, res) => {
    const check = assertRideChatParticipant(req.params.id, req.auth!.userId, true);
    if (!check.ok) {
      res.status(check.status).json({ error: check.error });
      return;
    }
    const { body } = req.body as { body?: string };
    if (!body || !body.trim()) {
      res.status(400).json({ error: 'لا يمكن إرسال رسالة فارغة' });
      return;
    }
    const message = sendRideMessage({
      rideId: req.params.id,
      senderId: req.auth!.userId,
      senderRole: check.role,
      otherUserId: check.otherUserId,
      body,
    });
    res.status(201).json({ message });
  });

  app.post('/api/rides/:id/messages/:msgId/report', requireAuth, (req: AuthedRequest, res) => {
    const check = assertRideChatParticipant(req.params.id, req.auth!.userId, false);
    if (!check.ok) {
      res.status(check.status).json({ error: check.error });
      return;
    }
    const { reason } = req.body as { reason?: string };
    try {
      const reportId = reportRideMessage({
        rideId: req.params.id,
        messageId: req.params.msgId,
        reporterId: req.auth!.userId,
        reason: reason?.trim() || 'محتوى غير مناسب أو إساءة',
      });
      res.status(201).json({ reportId });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر الإبلاغ عن الرسالة' });
    }
  });

  app.post('/api/rides/:id/call/start', requireAuth, (req: AuthedRequest, res) => {
    const check = assertRideChatParticipant(req.params.id, req.auth!.userId, true);
    if (!check.ok) {
      res.status(check.status).json({ error: check.error });
      return;
    }
    const session = startMaskedCallSession({
      rideId: req.params.id,
      callerId: req.auth!.userId,
      calleeId: check.otherUserId,
    });
    sendToUser(check.otherUserId, 'call:incoming', {
      call_id: session.id,
      ride_id: req.params.id,
      caller_id: req.auth!.userId,
      caller_name: req.auth!.name,
      caller_role: check.role,
      mode: session.mode,
    });
    createNotification({
      userId: check.otherUserId,
      title: `مكالمة صوتية واردة (${check.role === 'driver' ? 'السائق' : 'الزبون'})`,
      body: `${req.auth!.name} يتصل بك عبر اتصال مشوار الآمن برقم مخفي`,
      type: 'incoming_call',
      rideId: req.params.id,
    });
    res.status(201).json({ session });
  });

  app.post('/api/rides/:id/call/end', requireAuth, (req: AuthedRequest, res) => {
    const check = assertRideChatParticipant(req.params.id, req.auth!.userId, false);
    if (!check.ok) {
      res.status(check.status).json({ error: check.error });
      return;
    }
    const { callId } = req.body as { callId?: string };
    if (callId) {
      endMaskedCallSession(callId);
    }
    sendToUser(check.otherUserId, 'call:hangup', { ride_id: req.params.id, call_id: callId ?? null });
    res.json({ ok: true });
  });

  app.get('/api/driver/earnings', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

    const daily = db
      .prepare(
        `SELECT COALESCE(SUM(final_fare_iqd), 0) AS total, COUNT(*) AS count
         FROM rides WHERE driver_id = ? AND status = 'completed' AND completed_at >= ?`,
      )
      .get(req.auth!.userId, startOfDay) as { total: number; count: number };

    const monthly = db
      .prepare(
        `SELECT COALESCE(SUM(final_fare_iqd), 0) AS total, COUNT(*) AS count
         FROM rides WHERE driver_id = ? AND status = 'completed' AND completed_at >= ?`,
      )
      .get(req.auth!.userId, startOfMonth) as { total: number; count: number };

    const reviews = db
      .prepare(
        `SELECT r.id, r.ride_number, r.driver_rating, r.driver_review, r.customer_rating, r.customer_review, r.completed_at,
                u.name AS customer_name, u.account_number AS customer_account_number
         FROM rides r
         JOIN users u ON u.id = r.customer_id
         WHERE r.driver_id = ? AND r.driver_rating IS NOT NULL AND r.rating_moderated = 0
         ORDER BY r.completed_at DESC LIMIT 20`,
      )
      .all(req.auth!.userId);

    const wallet = getOrCreateDriverWallet(req.auth!.userId);
    const walletTransactions = db
      .prepare(
        `SELECT wt.*, r.ride_number
         FROM wallet_transactions wt
         LEFT JOIN rides r ON r.id = wt.ride_id
         WHERE wt.driver_id = ? ORDER BY wt.created_at DESC LIMIT 50`,
      )
      .all(req.auth!.userId);

    res.json({ daily, monthly, reviews, wallet, walletTransactions });
  });

  // ==================== PAYMENT GATEWAYS & DRIVER WALLETS ====================
  app.get('/api/payments/methods', (_req, res) => {
    res.json({
      methods: listPaymentGatewayConfigs(),
      commission_percent: getCommissionPercent(),
    });
  });

  app.get('/api/payments/my', requireAuth, (req: AuthedRequest, res) => {
    const rows = db
      .prepare(
        `SELECT * FROM payment_transactions
         WHERE user_id = ? OR driver_id = ?
         ORDER BY created_at DESC LIMIT 50`,
      )
      .all(req.auth!.userId, req.auth!.userId);
    res.json({ payments: rows });
  });

  app.post('/api/rides/:id/pay', requireAuth, requireRole('customer'), async (req: AuthedRequest, res) => {
    const { provider } = req.body as { provider?: PaymentMethod };
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND customer_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }
    if (ride.status === 'cancelled') {
      res.status(400).json({ error: 'لا يمكن دفع أجرة رحلة ملغاة' });
      return;
    }
    if (ride.payment_status === 'paid') {
      res.status(409).json({ error: 'تم دفع وتأكيد أجرة هذه الرحلة مسبقاً' });
      return;
    }

    const chosenProvider: PaymentMethod =
      provider === 'superqi' || provider === 'zaincash'
        ? provider
        : ride.payment_method === 'superqi' || ride.payment_method === 'zaincash'
          ? ride.payment_method
          : 'cash';

    if (chosenProvider === 'cash') {
      res.status(400).json({ error: 'طريقة الدفع المختارة هي الدفع النقدي للسائق' });
      return;
    }

    try {
      assertGatewayAvailable(chosenProvider);
    } catch (err) {
      res.status(403).json({ error: err instanceof Error ? err.message : 'بوابة الدفع غير مفعلة حالياً' });
      return;
    }

    const now = new Date().toISOString();
    const split = computeCommissionSplit(ride.final_fare_iqd);
    let payment = db
      .prepare("SELECT * FROM payment_transactions WHERE ride_id = ? AND purpose = 'ride_payment' LIMIT 1")
      .get(ride.id) as PaymentTransaction | undefined;

    if (!payment || payment.provider !== chosenProvider || payment.amount_iqd !== ride.final_fare_iqd) {
      const id = crypto.randomUUID();
      const ref = `MSH-RIDE-${Date.now()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(
        `INSERT INTO payment_transactions (
          id, reference_id, purpose, ride_id, user_id, driver_id, provider,
          amount_iqd, commission_percent, commission_iqd, driver_net_iqd,
          status, created_at, updated_at
        ) VALUES (?, ?, 'ride_payment', ?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_gateway', ?, ?)`,
      ).run(
        id,
        ref,
        ride.id,
        req.auth!.userId,
        ride.driver_id,
        chosenProvider,
        ride.final_fare_iqd,
        split.commission_percent,
        split.commission_iqd,
        split.driver_net_iqd,
        now,
        now,
      );
      payment = db.prepare('SELECT * FROM payment_transactions WHERE id = ?').get(id) as PaymentTransaction;
      db.prepare('UPDATE rides SET payment_id = ?, payment_method = ? WHERE id = ?').run(
        payment.id,
        chosenProvider,
        ride.id,
      );
    }

    const appBaseUrl = (process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL'
      ? process.env.APP_URL
      : `${req.protocol}://${req.get('host')}`
    ).replace(/\/+$/, '');

    try {
      const checkout = await initiateOfficialGatewayCheckout({
        payment,
        appBaseUrl,
        description: `دفع أجرة رحلة مشوار ${ride.ride_number || ride.id.slice(0, 8)} (${ride.pickup_address} -> ${ride.dropoff_address})`,
      });
      db.prepare(
        `UPDATE payment_transactions
         SET status = 'awaiting_gateway', gateway_transaction_id = ?, checkout_url = ?, updated_at = ?
         WHERE id = ?`,
      ).run(checkout.gatewayTransactionId, checkout.checkoutUrl, new Date().toISOString(), payment.id);
      const refreshed = db.prepare('SELECT * FROM payment_transactions WHERE id = ?').get(payment.id);
      res.json({ payment: refreshed, checkoutUrl: checkout.checkoutUrl });
    } catch (err) {
      res.status(502).json({ error: err instanceof Error ? err.message : 'فشل الاتصال ببوابة الدفع الرسمية' });
    }
  });

  app.get('/api/driver/wallet', requireAuth, requireRole('driver'), (req: AuthedRequest, res) => {
    const wallet = getOrCreateDriverWallet(req.auth!.userId);
    const transactions = db
      .prepare(
        `SELECT wt.*, r.ride_number
         FROM wallet_transactions wt
         LEFT JOIN rides r ON r.id = wt.ride_id
         WHERE wt.driver_id = ? ORDER BY wt.created_at DESC LIMIT 80`,
      )
      .all(req.auth!.userId);
    const topups = db
      .prepare(
        "SELECT * FROM payment_transactions WHERE driver_id = ? AND purpose = 'driver_wallet_topup' ORDER BY created_at DESC LIMIT 30",
      )
      .all(req.auth!.userId);
    res.json({
      wallet,
      transactions,
      topups,
      gateways: listPaymentGatewayConfigs().filter((g) => g.provider !== 'cash'),
      commission_percent: getCommissionPercent(),
    });
  });

  app.post('/api/driver/wallet/topup/initiate', requireAuth, requireRole('driver'), async (req: AuthedRequest, res) => {
    const { provider, amountIqd } = req.body as { provider?: PaymentMethod; amountIqd?: number };
    if (provider !== 'superqi' && provider !== 'zaincash') {
      res.status(400).json({ error: 'يجب اختيار سوبر كي أو زين كاش لشحن المحفظة' });
      return;
    }

    let cfg;
    try {
      cfg = assertGatewayAvailable(provider);
    } catch (err) {
      res.status(403).json({ error: err instanceof Error ? err.message : 'بوابة الشحن غير مفعلة حالياً' });
      return;
    }

    const amt = Math.round(Number(amountIqd));
    const minTopup = Math.max(1000, cfg.min_topup_iqd || 5000);
    if (!Number.isFinite(amt) || amt < minTopup || amt > 5000000) {
      res.status(400).json({
        error: `مبلغ الشحن يجب أن يكون بين ${minTopup.toLocaleString()} و 5,000,000 د.ع`,
      });
      return;
    }

    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    const ref = `MSH-TOPUP-${Date.now()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;

    db.prepare(
      `INSERT INTO payment_transactions (
        id, reference_id, purpose, ride_id, user_id, driver_id, provider,
        amount_iqd, commission_percent, commission_iqd, driver_net_iqd,
        status, created_at, updated_at
      ) VALUES (?, ?, 'driver_wallet_topup', NULL, ?, ?, ?, ?, 0, 0, ?, 'awaiting_gateway', ?, ?)`,
    ).run(id, ref, req.auth!.userId, req.auth!.userId, provider, amt, amt, now, now);

    const payment = db.prepare('SELECT * FROM payment_transactions WHERE id = ?').get(id) as PaymentTransaction;
    const appBaseUrl = (process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL'
      ? process.env.APP_URL
      : `${req.protocol}://${req.get('host')}`
    ).replace(/\/+$/, '');

    try {
      const checkout = await initiateOfficialGatewayCheckout({
        payment,
        appBaseUrl,
        description: `شحن محفظة كابتن مشوار (${amt.toLocaleString()} د.ع)`,
      });
      db.prepare(
        `UPDATE payment_transactions
         SET gateway_transaction_id = ?, checkout_url = ?, updated_at = ?
         WHERE id = ?`,
      ).run(checkout.gatewayTransactionId, checkout.checkoutUrl, new Date().toISOString(), payment.id);
      const updated = db.prepare('SELECT * FROM payment_transactions WHERE id = ?').get(payment.id);
      res.status(201).json({ payment: updated, checkoutUrl: checkout.checkoutUrl });
    } catch (err) {
      db.prepare("UPDATE payment_transactions SET status = 'failed', failure_reason = ?, updated_at = ? WHERE id = ?").run(
        err instanceof Error ? err.message : 'فشل الاتصال بالبوابة',
        new Date().toISOString(),
        payment.id,
      );
      res.status(502).json({ error: err instanceof Error ? err.message : 'تعذر بدء عملية الشحن عبر البوابة الرسمية' });
    }
  });

  // SuperQi / Qi Card Official Gateway RSA-SHA256 Signed Webhook
  app.post('/api/payments/superqi/webhook', (req, res) => {
    const rawBody = (req as express.Request & { rawBody?: Buffer }).rawBody ?? JSON.stringify(req.body ?? {});
    const sigHeader = String(req.headers['x-signature'] ?? '');
    if (!verifySuperQiRsaSignature(rawBody, sigHeader)) {
      recordSecurityEvent({
        severity: 'critical',
        eventType: 'invalid_payment_webhook_signature',
        ipAddress: req.ip,
        summary: 'رفض إشعار دفع SuperQi/QiCard بتوقيع RSA غير صالح',
      });
      res.status(403).json({ error: 'Invalid X-Signature' });
      return;
    }

    const body = req.body as {
      requestId?: string;
      paymentId?: string;
      status?: string;
      amount?: number;
      currency?: string;
    };
    const referenceId = String(body.requestId || '').trim();
    const rawStatus = String(body.status || '').toUpperCase();
    if (!referenceId) {
      res.status(400).json({ error: 'Missing requestId' });
      return;
    }

    if (rawStatus !== 'SUCCESS' && rawStatus !== 'PAID') {
      if (rawStatus === 'FAILED' || rawStatus === 'CANCELLED') {
        db.prepare(
          `UPDATE payment_transactions SET status = 'failed', raw_status = ?, updated_at = ?
           WHERE reference_id = ? AND provider = 'superqi' AND status != 'confirmed'`,
        ).run(rawStatus, new Date().toISOString(), referenceId);
      }
      res.json({ ok: true, status: rawStatus });
      return;
    }

    try {
      const outcome = confirmPaymentTransactionAtomic({
        referenceId,
        provider: 'superqi',
        gatewayTransactionId: String(body.paymentId || referenceId),
        verifiedAmountIqd: Number(body.amount),
        verifiedCurrency: String(body.currency || 'IQD'),
        verifiedSource: 'superqi_rsa_webhook',
        rawStatus,
      });

      if (!outcome.alreadyConfirmed) {
        if (outcome.payment.driver_id) {
          const w = getOrCreateDriverWallet(outcome.payment.driver_id);
          sendToUser(outcome.payment.driver_id, 'wallet:updated', w);
          if (outcome.driverIdReactivated) {
            const dp = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(outcome.driverIdReactivated);
            sendToAdmins('admin:driver_status', dp);
            createNotification({
              userId: outcome.driverIdReactivated,
              title: 'تم شحن المحفظة وإعادة تفعيلك تلقائياً',
              body: `تمت إضافة ${outcome.payment.amount_iqd.toLocaleString()} د.ع عبر سوبر كي وإعادة تفعيل استقبال الطلبات.`,
              type: 'wallet_reactivated',
            });
          } else {
            createNotification({
              userId: outcome.payment.driver_id,
              title: 'تم تأكيد الدفع في محفظتك (سوبر كي)',
              body: `المبلغ المضاف: ${(outcome.payment.purpose === 'driver_wallet_topup' ? outcome.payment.amount_iqd : outcome.payment.driver_net_iqd).toLocaleString()} د.ع`,
              type: 'payment_confirmed',
              rideId: outcome.payment.ride_id,
            });
          }
        }
        if (outcome.rideUpdatedId) {
          const updatedRide = getEnrichedRide(outcome.rideUpdatedId);
          if (updatedRide) broadcastRideUpdate(updatedRide);
          createNotification({
            userId: outcome.payment.user_id,
            title: 'تم تأكيد الدفع عبر سوبر كي بنجاح',
            body: `المبلغ: ${outcome.payment.amount_iqd.toLocaleString()} د.ع`,
            type: 'payment_confirmed',
            rideId: outcome.rideUpdatedId,
          });
        }
        sendToAdmins('admin:payment_confirmed', outcome.payment);
      }
      res.status(200).json({ ok: true, payment: outcome.payment });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر تأكيد العملية' });
    }
  });

  // ZainCash Official Gateway JWT HS256 Verified Callback & Webhook
  const handleZainCashVerifiedPayload = (tokenStr: string, source: 'zaincash_jwt_callback' | 'zaincash_webhook', ipAddress?: string) => {
    const decoded = verifyZainCashJwtToken(tokenStr);
    if (!decoded) {
      recordSecurityEvent({
        severity: 'critical',
        eventType: 'invalid_payment_webhook_signature',
        ipAddress,
        summary: 'رفض استجابة دفع ZainCash بتوقيع JWT غير صالح أو منتهي الصلاحية',
      });
      return { ok: false as const, status: 403, error: 'توقيع بوابة زين كاش غير صالح' };
    }

    const referenceId = String(decoded.externalReferenceId || decoded.orderId || '').trim();
    const rawStatus = String(decoded.status || '').toLowerCase();
    if (!referenceId) {
      return { ok: false as const, status: 400, error: 'مرجع العملية مفقود' };
    }

    if (rawStatus !== 'success' && rawStatus !== 'completed') {
      db.prepare(
        `UPDATE payment_transactions SET status = 'failed', raw_status = ?, failure_reason = ?, updated_at = ?
         WHERE reference_id = ? AND provider = 'zaincash' AND status != 'confirmed'`,
      ).run(rawStatus, decoded.msg || 'فشل الدفع في البوابة', new Date().toISOString(), referenceId);
      return { ok: false as const, status: 400, error: decoded.msg || 'لم تكتمل عملية الدفع في زين كاش' };
    }

    const existing = db
      .prepare("SELECT amount_iqd FROM payment_transactions WHERE reference_id = ? AND provider = 'zaincash'")
      .get(referenceId) as { amount_iqd: number } | undefined;
    if (!existing) {
      return { ok: false as const, status: 404, error: 'معاملة الدفع غير موجودة' };
    }

    try {
      const outcome = confirmPaymentTransactionAtomic({
        referenceId,
        provider: 'zaincash',
        gatewayTransactionId: String(decoded.transactionId || decoded.id || referenceId),
        verifiedAmountIqd: Number(decoded.amount ?? existing.amount_iqd),
        verifiedCurrency: String(decoded.currency || 'IQD'),
        verifiedSource: source,
        rawStatus,
      });

      if (!outcome.alreadyConfirmed) {
        if (outcome.payment.driver_id) {
          const w = getOrCreateDriverWallet(outcome.payment.driver_id);
          sendToUser(outcome.payment.driver_id, 'wallet:updated', w);
          if (outcome.driverIdReactivated) {
            const dp = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(outcome.driverIdReactivated);
            sendToAdmins('admin:driver_status', dp);
            createNotification({
              userId: outcome.driverIdReactivated,
              title: 'تم شحن المحفظة عبر زين كاش وإعادة تفعيلك تلقائياً',
              body: `تمت إضافة ${outcome.payment.amount_iqd.toLocaleString()} د.ع وإعادة تفعيل استقبال الطلبات.`,
              type: 'wallet_reactivated',
            });
          } else {
            createNotification({
              userId: outcome.payment.driver_id,
              title: 'تم تأكيد الدفع عبر زين كاش',
              body: `المبلغ المضاف: ${(outcome.payment.purpose === 'driver_wallet_topup' ? outcome.payment.amount_iqd : outcome.payment.driver_net_iqd).toLocaleString()} د.ع`,
              type: 'payment_confirmed',
              rideId: outcome.payment.ride_id,
            });
          }
        }
        if (outcome.rideUpdatedId) {
          const updatedRide = getEnrichedRide(outcome.rideUpdatedId);
          if (updatedRide) broadcastRideUpdate(updatedRide);
          createNotification({
            userId: outcome.payment.user_id,
            title: 'تم تأكيد الدفع عبر زين كاش بنجاح',
            body: `المبلغ: ${outcome.payment.amount_iqd.toLocaleString()} د.ع`,
            type: 'payment_confirmed',
            rideId: outcome.rideUpdatedId,
          });
        }
        sendToAdmins('admin:payment_confirmed', outcome.payment);
      }

      return { ok: true as const, status: 200, payment: outcome.payment };
    } catch (err) {
      return { ok: false as const, status: 400, error: err instanceof Error ? err.message : 'فشل التحقق من الدفع' };
    }
  };

  app.get('/api/payments/zaincash/callback', (req, res) => {
    const tokenStr = String(req.query.token || '');
    const result = handleZainCashVerifiedPayload(tokenStr, 'zaincash_jwt_callback', req.ip);
    if (!result.ok) {
      res.status(result.status).json({ error: result.error });
      return;
    }
    res.redirect(`/?payment_confirmed=${encodeURIComponent(result.payment.reference_id)}`);
  });

  app.post('/api/payments/zaincash/webhook', (req, res) => {
    const tokenStr = String((req.body as { token?: string })?.token || '');
    const result = handleZainCashVerifiedPayload(tokenStr, 'zaincash_webhook', req.ip);
    if (!result.ok) {
      res.status(result.status).json({ error: result.error });
      return;
    }
    res.status(200).json({ ok: true, payment: result.payment });
  });

  // ==================== SOS EMERGENCY & TRIP SHARING ====================
  app.get('/api/app/emergency-info', requireAuth, (_req, res) => {
    const s = db.prepare('SELECT emergency_phone FROM app_settings WHERE id = 1').get() as
      | { emergency_phone: string }
      | undefined;
    res.json({ emergency_phone: s?.emergency_phone || '104' });
  });

  app.post('/api/sos', requireAuth, (req: AuthedRequest, res) => {
    if (req.auth!.role !== 'customer' && req.auth!.role !== 'driver') {
      res.status(403).json({ error: 'نظام الطوارئ مخصص للزبائن والسائقين' });
      return;
    }
    const { rideId, lat, lng, incidentType, notes } = req.body as {
      rideId?: string | null;
      lat?: number | null;
      lng?: number | null;
      incidentType?: string;
      notes?: string;
    };

    let validRideId: string | null = null;
    if (rideId) {
      const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(rideId) as Ride | undefined;
      if (!ride || (ride.customer_id !== req.auth!.userId && ride.driver_id !== req.auth!.userId)) {
        res.status(403).json({ error: 'لا يمكنك ربط تنبيه الطوارئ برحلة لا تخصك' });
        return;
      }
      validRideId = ride.id;
    }

    const safeLat = typeof lat === 'number' && Number.isFinite(lat) && lat >= -90 && lat <= 90 ? lat : null;
    const safeLng = typeof lng === 'number' && Number.isFinite(lng) && lng >= -180 && lng <= 180 ? lng : null;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const cleanType = incidentType?.trim().slice(0, 80) || 'طوارئ عاجلة';
    const cleanNotes = notes?.trim().slice(0, 600) || null;

    db.prepare(
      `INSERT INTO sos_alerts (id, ride_id, user_id, user_role, lat, lng, incident_type, notes, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)`,
    ).run(id, validRideId, req.auth!.userId, req.auth!.role, safeLat, safeLng, cleanType, cleanNotes, now);

    const alert = db
      .prepare(
        `SELECT sa.*, u.name AS user_name, u.account_number AS user_account_number, u.phone AS user_phone,
                r.ride_number, r.pickup_address, r.dropoff_address, r.status AS ride_status,
                cu.name AS customer_name, cu.account_number AS customer_account_number,
                du.name AS driver_name, du.account_number AS driver_account_number
         FROM sos_alerts sa
         JOIN users u ON u.id = sa.user_id
         LEFT JOIN rides r ON r.id = sa.ride_id
         LEFT JOIN users cu ON cu.id = r.customer_id
         LEFT JOIN users du ON du.id = r.driver_id
         WHERE sa.id = ?`,
      )
      .get(id) as Record<string, unknown>;

    recordSecurityEvent({
      severity: 'critical',
      eventType: 'sos_triggered',
      actorUserId: req.auth!.userId,
      ipAddress: req.ip,
      summary: `تنبيه طوارئ SOS من ${req.auth!.name} (${req.auth!.role === 'driver' ? 'سائق' : 'زبون'}) — ${cleanType}`,
      details: { sosId: id, rideId: validRideId, lat: safeLat, lng: safeLng },
    });

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: req.auth!.role,
      action: 'sos.triggered',
      targetType: 'sos_alert',
      targetId: id,
      details: { rideId: validRideId, incidentType: cleanType },
    });

    const admins = db.prepare("SELECT id FROM users WHERE role = 'admin'").all() as Array<{ id: string }>;
    const rideLabel = alert?.ride_number ? ` — رحلة ${alert.ride_number}` : validRideId ? ` — رحلة رقم ${validRideId.slice(0, 8)}` : '';
    for (const adm of admins) {
      createNotification({
        userId: adm.id,
        title: `تنبيه طوارئ SOS: ${cleanType}`,
        body: `من ${req.auth!.name}${rideLabel}`,
        type: 'sos_alert',
        rideId: validRideId,
      });
    }
    sendToAdmins('admin:sos_alert', alert);

    const settings = db.prepare('SELECT emergency_phone FROM app_settings WHERE id = 1').get() as
      | { emergency_phone: string }
      | undefined;
    res.status(201).json({ alert, emergency_phone: settings?.emergency_phone || '104' });
  });

  app.post('/api/sos/:id/cancel', requireAuth, (req: AuthedRequest, res) => {
    const existing = db
      .prepare('SELECT * FROM sos_alerts WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.auth!.userId) as { id: string; status: string } | undefined;
    if (!existing) {
      res.status(404).json({ error: 'تنبيه الطوارئ غير موجود' });
      return;
    }
    if (existing.status === 'resolved' || existing.status === 'cancelled_false_alarm') {
      res.status(400).json({ error: 'تم إغلاق هذا التنبيه مسبقاً' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare(`UPDATE sos_alerts SET status = 'cancelled_false_alarm', resolved_at = ? WHERE id = ?`).run(
      now,
      existing.id,
    );
    const updated = db.prepare('SELECT * FROM sos_alerts WHERE id = ?').get(existing.id);
    sendToAdmins('admin:sos_updated', updated);
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: req.auth!.role,
      action: 'sos.cancelled_false_alarm',
      targetType: 'sos_alert',
      targetId: existing.id,
    });
    res.json({ alert: updated });
  });

  app.get('/api/sos/my', requireAuth, (req: AuthedRequest, res) => {
    const alerts = db
      .prepare('SELECT * FROM sos_alerts WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(req.auth!.userId);
    res.json({ alerts });
  });

  app.post('/api/rides/:id/share', requireAuth, requireRole('customer'), (req: AuthedRequest, res) => {
    const ride = db
      .prepare('SELECT * FROM rides WHERE id = ? AND customer_id = ?')
      .get(req.params.id, req.auth!.userId) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }
    if (ride.status === 'completed' || ride.status === 'cancelled') {
      res.status(400).json({ error: 'لا يمكن مشاركة رحلة منتهية أو ملغاة' });
      return;
    }

    const rawToken = crypto.randomBytes(24).toString('base64url');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const id = crypto.randomUUID();
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 12 * 60 * 60 * 1000).toISOString();

    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE ride_shares SET is_active = 0, revoked_at = COALESCE(revoked_at, ?)
         WHERE ride_id = ? AND is_active = 1`,
      ).run(now.toISOString(), ride.id);
      db.prepare(
        `INSERT INTO ride_shares (id, ride_id, created_by_user_id, token_hash, is_active, expires_at, created_at)
         VALUES (?, ?, ?, ?, 1, ?, ?)`,
      ).run(id, ride.id, req.auth!.userId, tokenHash, expiresAt, now.toISOString());
    });
    tx();

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'customer',
      action: 'ride_share.created',
      targetType: 'ride_share',
      targetId: id,
      details: { rideId: ride.id },
    });

    res.status(201).json({
      shareId: id,
      token: rawToken,
      shareUrl: `/?share=${rawToken}`,
      expires_at: expiresAt,
    });
  });

  app.post('/api/rides/:id/share/revoke', requireAuth, (req: AuthedRequest, res) => {
    const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id) as Ride | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }
    if (req.auth!.role !== 'admin' && ride.customer_id !== req.auth!.userId) {
      res.status(403).json({ error: 'غير مصرح بإيقاف مشاركة هذه الرحلة' });
      return;
    }
    db.prepare(
      `UPDATE ride_shares SET is_active = 0, revoked_at = COALESCE(revoked_at, ?)
       WHERE ride_id = ? AND is_active = 1`,
    ).run(new Date().toISOString(), ride.id);
    res.json({ ok: true });
  });

  app.get('/api/share/:token', (req, res) => {
    const rawToken = String(req.params.token || '').trim();
    if (!rawToken || rawToken.length < 16) {
      res.status(404).json({ error: 'رابط المشاركة غير صالح' });
      return;
    }
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const share = db
      .prepare('SELECT * FROM ride_shares WHERE token_hash = ?')
      .get(tokenHash) as
      | { id: string; ride_id: string; is_active: number; expires_at: string }
      | undefined;
    if (!share) {
      res.status(404).json({ error: 'رابط المشاركة غير موجود أو غير صحيح' });
      return;
    }

    const now = new Date().toISOString();
    const ride = getEnrichedRide(share.ride_id, false);
    if (
      !ride ||
      share.is_active !== 1 ||
      share.expires_at <= now ||
      ride.status === 'completed' ||
      ride.status === 'cancelled'
    ) {
      if (share.is_active === 1) {
        db.prepare(`UPDATE ride_shares SET is_active = 0, revoked_at = COALESCE(revoked_at, ?) WHERE id = ?`).run(
          now,
          share.id,
        );
      }
      res.status(410).json({ error: 'توقفت مشاركة الموقع تلقائياً بعد انتهاء الرحلة أو إلغاء الرابط' });
      return;
    }

    res.json({
      share: {
        ride_id: ride.id,
        ride_number: ride.ride_number,
        status: ride.status,
        category: ride.category,
        pickup_address: ride.pickup_address,
        pickup_lat: ride.pickup_lat,
        pickup_lng: ride.pickup_lng,
        dropoff_address: ride.dropoff_address,
        dropoff_lat: ride.dropoff_lat,
        dropoff_lng: ride.dropoff_lng,
        driver_name: ride.driver_name ?? null,
        driver_rating_avg: ride.driver_rating_avg ?? null,
        car_make: ride.car_make ?? null,
        car_model: ride.car_model ?? null,
        car_color: ride.car_color ?? null,
        plate_number: ride.plate_number ?? null,
        driver_lat: ride.driver_lat ?? null,
        driver_lng: ride.driver_lng ?? null,
        driver_speed_kmh: ride.driver_speed_kmh ?? null,
        driver_heading: ride.driver_heading ?? null,
        expires_at: share.expires_at,
      },
    });
  });

  // ==================== NOTIFICATIONS & COMPLAINTS ====================
  app.get('/api/notifications', requireAuth, (req: AuthedRequest, res) => {
    const items = db
      .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 40')
      .all(req.auth!.userId);
    res.json({ notifications: items });
  });

  app.post('/api/notifications/read-all', requireAuth, (req: AuthedRequest, res) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.auth!.userId);
    res.json({ ok: true });
  });

  app.get('/api/complaints', requireAuth, (req: AuthedRequest, res) => {
    if (req.auth!.role === 'admin') {
      const q = String(req.query.q ?? '').trim();
      let sql = `SELECT c.*, u.name AS user_name, u.account_number AS user_account_number,
                        u.phone AS user_phone, u.role AS user_role, r.ride_number
                 FROM complaints c
                 JOIN users u ON u.id = c.user_id
                 LEFT JOIN rides r ON r.id = c.ride_id`;
      const params: unknown[] = [];
      if (q) {
        const like = `%${q}%`;
        sql += ` WHERE u.account_number LIKE ? OR u.name LIKE ? OR u.phone LIKE ? OR r.ride_number LIKE ? OR c.subject LIKE ? OR c.category LIKE ?`;
        params.push(like, like, like, like, like, like);
      }
      sql += ' ORDER BY c.created_at DESC';
      const items = db.prepare(sql).all(...params);
      res.json({ complaints: items });
      return;
    }
    const items = db
      .prepare(
        `SELECT c.*, r.ride_number
         FROM complaints c
         LEFT JOIN rides r ON r.id = c.ride_id
         WHERE c.user_id = ? ORDER BY c.created_at DESC`,
      )
      .all(req.auth!.userId);
    res.json({ complaints: items });
  });

  app.post('/api/complaints', requireAuth, (req: AuthedRequest, res) => {
    const { rideId, category, subject, message, attachmentUrl } = req.body as {
      rideId?: string;
      category?: string;
      subject?: string;
      message?: string;
      attachmentUrl?: string | null;
    };
    if (!subject?.trim() || !message?.trim()) {
      res.status(400).json({ error: 'يرجى كتابة عنوان وتفاصيل الشكوى' });
      return;
    }

    let safeRideId: string | null = null;
    let rideNumberSnapshot: string | null = null;
    if (rideId) {
      const rRow = db
        .prepare('SELECT id, ride_number, customer_id, driver_id FROM rides WHERE id = ?')
        .get(rideId) as { id: string; ride_number?: string | null; customer_id: string; driver_id: string | null } | undefined;
      if (rRow && (rRow.customer_id === req.auth!.userId || rRow.driver_id === req.auth!.userId)) {
        safeRideId = rRow.id;
        rideNumberSnapshot = rRow.ride_number ?? null;
      }
    }

    let safeAttachment: string | null = null;
    if (attachmentUrl) {
      const m = String(attachmentUrl).match(/^\/api\/uploads\/([a-f0-9-]+\.(?:jpg|png|webp))$/i);
      if (m) {
        db.prepare(
          `UPDATE upload_records SET owner_user_id = ?, purpose = 'complaint_attachment'
           WHERE filename = ? AND (owner_user_id IS NULL OR owner_user_id = ?)`,
        ).run(req.auth!.userId, m[1], req.auth!.userId);
        safeAttachment = attachmentUrl;
      }
    }

    // Clauses 15 & 19: Automatically attach user/driver status, commission, and wallet snapshot
    const uSnap = db
      .prepare('SELECT account_number, status, role FROM users WHERE id = ?')
      .get(req.auth!.userId) as { account_number: string; status: string; role: string } | undefined;
    const contextObj: Record<string, unknown> = {
      account_number: uSnap?.account_number ?? null,
      user_status: uSnap?.status ?? 'active',
      role: uSnap?.role ?? req.auth!.role,
      ride_number: rideNumberSnapshot,
    };
    if (req.auth!.role === 'driver') {
      const dpSnap = db
        .prepare('SELECT approval_status, rejection_reason, agreed_commission_percent, is_online FROM driver_profiles WHERE user_id = ?')
        .get(req.auth!.userId) as
        | { approval_status: string; rejection_reason: string | null; agreed_commission_percent: number | null; is_online: number }
        | undefined;
      const wSnap = getOrCreateDriverWallet(req.auth!.userId);
      contextObj.approval_status = dpSnap?.approval_status ?? null;
      contextObj.rejection_reason = dpSnap?.rejection_reason ?? null;
      contextObj.agreed_commission_percent = dpSnap?.agreed_commission_percent ?? null;
      contextObj.active_commission_percent = getCommissionPercent();
      contextObj.is_online = dpSnap?.is_online ?? 0;
      contextObj.bonus_balance_iqd = wSnap.bonus_balance_iqd;
      contextObj.real_balance_iqd = wSnap.real_balance_iqd;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const cleanCategory = category?.trim().slice(0, 60) || 'أسباب أخرى';
    db.prepare(
      `INSERT INTO complaints (id, user_id, ride_id, category, subject, message, attachment_url, appeal_context, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)`,
    ).run(
      id,
      req.auth!.userId,
      safeRideId,
      cleanCategory,
      subject.trim().slice(0, 120),
      message.trim().slice(0, 1500),
      safeAttachment,
      JSON.stringify(contextObj),
      now,
    );
    const complaint = db
      .prepare(
        `SELECT c.*, u.name AS user_name, u.account_number AS user_account_number, u.phone AS user_phone, u.role AS user_role, r.ride_number
         FROM complaints c
         JOIN users u ON u.id = c.user_id
         LEFT JOIN rides r ON r.id = c.ride_id
         WHERE c.id = ?`,
      )
      .get(id);
    sendToAdmins('admin:complaint_new', complaint);
    res.status(201).json({ complaint });
  });

  // ==================== ADMIN DASHBOARD (STRICT RBAC) ====================
  app.get('/api/admin/overview', requireAuth, requireRole('admin'), (_req, res) => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

    const totalCustomers = (
      db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'customer'").get() as { c: number }
    ).c;
    const totalDrivers = (
      db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'driver'").get() as { c: number }
    ).c;
    const onlineDrivers = (
      db.prepare("SELECT COUNT(*) AS c FROM driver_profiles WHERE is_online = 1 AND approval_status = 'approved'").get() as {
        c: number;
      }
    ).c;
    const offlineDrivers = Math.max(0, totalDrivers - onlineDrivers);

    const activeRidesCount = (
      db
        .prepare(
          "SELECT COUNT(*) AS c FROM rides WHERE status IN ('searching', 'found', 'on_the_way', 'arrived', 'in_progress')",
        )
        .get() as { c: number }
    ).c;
    const completedRidesCount = (
      db.prepare("SELECT COUNT(*) AS c FROM rides WHERE status = 'completed'").get() as { c: number }
    ).c;
    const cancelledRidesCount = (
      db.prepare("SELECT COUNT(*) AS c FROM rides WHERE status = 'cancelled'").get() as { c: number }
    ).c;

    const dailyRevenueIqd = (
      db
        .prepare("SELECT COALESCE(SUM(final_fare_iqd), 0) AS s FROM rides WHERE status = 'completed' AND completed_at >= ?")
        .get(startOfDay) as { s: number }
    ).s;
    const monthlyRevenueIqd = (
      db
        .prepare("SELECT COALESCE(SUM(final_fare_iqd), 0) AS s FROM rides WHERE status = 'completed' AND completed_at >= ?")
        .get(startOfMonth) as { s: number }
    ).s;

    const liveDrivers = db
      .prepare(
        `SELECT u.id, u.account_number, u.name, u.phone, dp.category, dp.car_make, dp.car_model, dp.plate_number,
                dp.is_online, dp.current_lat, dp.current_lng, dp.current_speed_kmh, dp.rating_avg
         FROM driver_profiles dp
         JOIN users u ON u.id = dp.user_id
         WHERE dp.approval_status = 'approved' AND dp.current_lat IS NOT NULL`,
      )
      .all();

    const activeRides = db
      .prepare(
        `SELECT r.*, cu.name AS customer_name, cu.account_number AS customer_account_number,
                du.name AS driver_name, du.account_number AS driver_account_number
         FROM rides r
         JOIN users cu ON cu.id = r.customer_id
         LEFT JOIN users du ON du.id = r.driver_id
         WHERE r.status IN ('searching', 'found', 'on_the_way', 'arrived', 'in_progress')
         ORDER BY r.created_at DESC`,
      )
      .all();

    res.json({
      kpis: {
        totalCustomers,
        totalDrivers,
        onlineDrivers,
        offlineDrivers,
        activeRidesCount,
        completedRidesCount,
        cancelledRidesCount,
        dailyRevenueIqd,
        monthlyRevenueIqd,
      },
      liveDrivers,
      activeRides,
    });
  });

  app.get('/api/admin/customers', requireAuth, requireRole('admin'), (req, res) => {
    const q = String(req.query.q ?? '').trim();
    const params: unknown[] = [];
    let qFilter = '';
    if (q) {
      const like = `%${q}%`;
      qFilter = 'AND (u.account_number LIKE ? OR u.name LIKE ? OR u.phone LIKE ?)';
      params.push(like, like, like);
    }
    const customers = db
      .prepare(
        `SELECT u.id, u.account_number, u.name, u.phone, u.avatar_url, u.status, u.terms_accepted_version, u.created_at,
                (SELECT COUNT(*) FROM rides r WHERE r.customer_id = u.id) AS total_rides,
                (SELECT status FROM plus_subscriptions ps WHERE ps.user_id = u.id AND ps.status = 'active' LIMIT 1) AS plus_status
         FROM users u WHERE u.role = 'customer' ${qFilter} ORDER BY u.created_at DESC`,
      )
      .all(...params);
    res.json({ customers });
  });

  app.get('/api/admin/drivers', requireAuth, requireRole('admin'), (req, res) => {
    const q = String(req.query.q ?? '').trim();
    const params: unknown[] = [];
    let qFilter = '';
    if (q) {
      const like = `%${q}%`;
      qFilter = 'AND (u.account_number LIKE ? OR u.name LIKE ? OR u.phone LIKE ? OR dp.plate_number LIKE ?)';
      params.push(like, like, like, like);
    }
    const drivers = db
      .prepare(
        `SELECT u.id, u.account_number, u.name, u.phone, u.avatar_url, u.status, u.terms_accepted_version, u.created_at, dp.*
         FROM users u
         JOIN driver_profiles dp ON dp.user_id = u.id
         WHERE u.role = 'driver' ${qFilter}
         ORDER BY CASE dp.approval_status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END, u.created_at DESC`,
      )
      .all(...params);
    res.json({ drivers });
  });

  app.patch('/api/admin/users/:id/status', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { status } = req.body as { status: 'active' | 'suspended' };
    if (status !== 'active' && status !== 'suspended') {
      res.status(400).json({ error: 'حالة غير صالحة' });
      return;
    }
    if (status === 'suspended') {
      db.prepare('UPDATE users SET status = ?, token_version = token_version + 1 WHERE id = ?').run(
        status,
        req.params.id,
      );
      db.prepare('UPDATE driver_profiles SET is_online = 0 WHERE user_id = ?').run(req.params.id);
    } else {
      db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, req.params.id);
    }
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: `user.status_${status}`,
      targetType: 'user',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.post('/api/admin/drivers/:id/approve', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const approvePhoto = Boolean((req.body as { approvePhoto?: boolean } | undefined)?.approvePhoto);
    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE driver_profiles SET approval_status = 'approved', rejection_reason = NULL WHERE user_id = ?`,
      ).run(req.params.id);
      if (approvePhoto) {
        const dp = db
          .prepare('SELECT pending_avatar_url FROM driver_profiles WHERE user_id = ?')
          .get(req.params.id) as { pending_avatar_url: string | null } | undefined;
        if (dp?.pending_avatar_url) {
          db.prepare('UPDATE users SET avatar_url = ? WHERE id = ?').run(dp.pending_avatar_url, req.params.id);
        }
        db.prepare(
          `UPDATE driver_profiles SET photo_status = 'approved', photo_rejection_reason = NULL, pending_avatar_url = NULL WHERE user_id = ?`,
        ).run(req.params.id);
      }
    });
    tx();

    const bonusOutcome = grantDriverOpeningBonusAtomic(req.params.id, req.auth!.userId);
    sendToUser(req.params.id, 'wallet:updated', bonusOutcome.wallet);

    createNotification({
      userId: req.params.id,
      title: 'تمت الموافقة على حسابك وإضافة الرصيد الافتتاحي',
      body: bonusOutcome.granted
        ? 'تهانينا! تمت الموافقة على حسابك وحصلت على رصيد افتتاحي مجاني 10,000 د.ع لبدء استقبال الرحلات.'
        : 'تهانينا! تمت الموافقة على انضمامك ككابتن في مشوار. يمكنك الآن تفعيل زر مشوار واستقبال الطلبات.',
      type: 'admin_notice',
    });
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'driver.approved',
      targetType: 'driver_profile',
      targetId: req.params.id,
      details: { approvePhoto, openingBonusGranted: bonusOutcome.granted },
    });
    res.json({ ok: true, wallet: bonusOutcome.wallet });
  });

  app.post('/api/admin/drivers/:id/photo/approve', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const tx = db.transaction(() => {
      const dp = db
        .prepare('SELECT pending_avatar_url FROM driver_profiles WHERE user_id = ?')
        .get(req.params.id) as { pending_avatar_url: string | null } | undefined;
      if (dp?.pending_avatar_url) {
        db.prepare('UPDATE users SET avatar_url = ? WHERE id = ?').run(dp.pending_avatar_url, req.params.id);
      }
      db.prepare(
        `UPDATE driver_profiles
         SET photo_status = 'approved', photo_rejection_reason = NULL, pending_avatar_url = NULL
         WHERE user_id = ?`,
      ).run(req.params.id);
    });
    tx();

    const activeRide = db
      .prepare(
        `SELECT id FROM rides
         WHERE driver_id = ? AND status IN ('found', 'on_the_way', 'arrived', 'in_progress') LIMIT 1`,
      )
      .get(req.params.id) as { id: string } | undefined;
    if (activeRide) {
      const enriched = getEnrichedRide(activeRide.id);
      if (enriched) broadcastRideUpdate(enriched);
    }

    createNotification({
      userId: req.params.id,
      title: 'تمت الموافقة على صورتك الشخصية',
      body: 'أصبحت صورتك الشخصية معتمدة وتظهر للزبائن عند قبول الرحلات.',
      type: 'admin_notice',
    });
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'driver.photo_approved',
      targetType: 'driver_profile',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.post('/api/admin/drivers/:id/photo/reject', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { reason } = req.body as { reason?: string };
    const cleanReason = reason?.trim() || 'الصورة غير واضحة، يرجى رفع صورة شخصية واضحة حديثة';
    db.prepare(
      `UPDATE driver_profiles
       SET photo_status = 'rejected', photo_rejection_reason = ?, pending_avatar_url = NULL
       WHERE user_id = ?`,
    ).run(cleanReason, req.params.id);

    const activeRide = db
      .prepare(
        `SELECT id FROM rides
         WHERE driver_id = ? AND status IN ('found', 'on_the_way', 'arrived', 'in_progress') LIMIT 1`,
      )
      .get(req.params.id) as { id: string } | undefined;
    if (activeRide) {
      const enriched = getEnrichedRide(activeRide.id);
      if (enriched) broadcastRideUpdate(enriched);
    }

    createNotification({
      userId: req.params.id,
      title: 'تم رفض الصورة الشخصية',
      body: cleanReason,
      type: 'admin_notice',
    });
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'driver.photo_rejected',
      targetType: 'driver_profile',
      targetId: req.params.id,
      details: { reason: cleanReason },
    });
    res.json({ ok: true });
  });

  app.post('/api/admin/drivers/:id/reject', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { reason } = req.body as { reason?: string };
    db.prepare(
      `UPDATE driver_profiles SET approval_status = 'rejected', rejection_reason = ?, is_online = 0 WHERE user_id = ?`,
    ).run(reason?.trim() || 'لم تستوفِ المستمسكات الشروط المطلوبة', req.params.id);
    createNotification({
      userId: req.params.id,
      title: 'تحديث بخصوص طلب السائق',
      body: reason?.trim() || 'تم رفض طلب التسجيل، يرجى مراجعة المستمسكات',
      type: 'admin_notice',
    });
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'driver.rejected',
      targetType: 'driver_profile',
      targetId: req.params.id,
      details: { reason },
    });
    res.json({ ok: true });
  });

  app.get('/api/admin/message-reports', requireAuth, requireRole('admin'), (_req, res) => {
    const reports = db
      .prepare(
        `SELECT mr.*,
                rep.name AS reporter_name, rep.account_number AS reporter_account_number,
                ru.name AS reported_user_name, ru.account_number AS reported_user_account_number
         FROM message_reports mr
         JOIN users rep ON rep.id = mr.reporter_id
         JOIN users ru ON ru.id = mr.reported_user_id
         ORDER BY mr.created_at DESC LIMIT 100`,
      )
      .all();
    res.json({ reports });
  });

  app.patch('/api/admin/message-reports/:id', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { status, admin_note } = req.body as {
      status: 'reviewed' | 'action_taken';
      admin_note?: string;
    };
    if (status !== 'reviewed' && status !== 'action_taken') {
      res.status(400).json({ error: 'حالة غير صالحة' });
      return;
    }
    db.prepare('UPDATE message_reports SET status = ?, admin_note = COALESCE(?, admin_note) WHERE id = ?').run(
      status,
      admin_note?.trim() || null,
      req.params.id,
    );
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: `message_report.${status}`,
      targetType: 'message_report',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.get('/api/admin/rides', requireAuth, requireRole('admin'), (req, res) => {
    const q = String(req.query.q ?? '').trim();
    const status = String(req.query.status ?? '').trim();
    const conditions: string[] = [];
    const params: unknown[] = [];

    if (status && status !== 'all') {
      conditions.push('r.status = ?');
      params.push(status);
    }
    if (q) {
      const like = `%${q}%`;
      conditions.push(
        '(r.id LIKE ? OR r.ride_number LIKE ? OR cu.account_number LIKE ? OR du.account_number LIKE ? OR cu.name LIKE ? OR cu.phone LIKE ? OR du.name LIKE ? OR du.phone LIKE ? OR r.pickup_address LIKE ? OR r.dropoff_address LIKE ?)',
      );
      params.push(like, like, like, like, like, like, like, like, like, like);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const rides = db
      .prepare(
        `SELECT r.*, cu.name AS customer_name, cu.account_number AS customer_account_number, cu.phone AS customer_phone,
                du.name AS driver_name, du.account_number AS driver_account_number, du.phone AS driver_phone, du.avatar_url AS driver_avatar,
                dp.car_make, dp.car_model, dp.plate_number
         FROM rides r
         JOIN users cu ON cu.id = r.customer_id
         LEFT JOIN users du ON du.id = r.driver_id
         LEFT JOIN driver_profiles dp ON dp.user_id = r.driver_id
         ${whereClause}
         ORDER BY r.created_at DESC LIMIT 150`,
      )
      .all(...params);
    res.json({ rides });
  });

  app.get('/api/admin/sos', requireAuth, requireRole('admin'), (_req, res) => {
    const alerts = db
      .prepare(
        `SELECT sa.*, u.name AS user_name, u.account_number AS user_account_number, u.phone AS user_phone,
                r.ride_number, r.pickup_address, r.dropoff_address, r.status AS ride_status,
                cu.name AS customer_name, cu.account_number AS customer_account_number,
                du.name AS driver_name, du.account_number AS driver_account_number
         FROM sos_alerts sa
         JOIN users u ON u.id = sa.user_id
         LEFT JOIN rides r ON r.id = sa.ride_id
         LEFT JOIN users cu ON cu.id = r.customer_id
         LEFT JOIN users du ON du.id = r.driver_id
         ORDER BY CASE sa.status WHEN 'active' THEN 0 WHEN 'acknowledged' THEN 1 ELSE 2 END, sa.created_at DESC
         LIMIT 100`,
      )
      .all();
    res.json({ alerts });
  });

  app.patch('/api/admin/sos/:id', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { status, admin_note } = req.body as { status: 'acknowledged' | 'resolved'; admin_note?: string };
    if (status !== 'acknowledged' && status !== 'resolved') {
      res.status(400).json({ error: 'حالة غير صالحة' });
      return;
    }
    const existing = db.prepare('SELECT * FROM sos_alerts WHERE id = ?').get(req.params.id) as
      | { id: string; user_id: string }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'التنبيه غير موجود' });
      return;
    }
    const resolvedAt = status === 'resolved' ? new Date().toISOString() : null;
    db.prepare(
      `UPDATE sos_alerts SET status = ?, admin_note = COALESCE(?, admin_note), resolved_at = COALESCE(?, resolved_at) WHERE id = ?`,
    ).run(status, admin_note?.trim() || null, resolvedAt, existing.id);

    const updated = db.prepare('SELECT * FROM sos_alerts WHERE id = ?').get(existing.id);
    createNotification({
      userId: existing.user_id,
      title: status === 'resolved' ? 'تمت معالجة بلاغ الطوارئ' : 'فريق الطوارئ يتابع بلاغك الآن',
      body: admin_note?.trim() || 'تم استلام تنبيه الطوارئ والتعامل معه من قبل إدارة مشوار.',
      type: 'admin_notice',
    });
    sendToAdmins('admin:sos_updated', updated);
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: `sos.${status}`,
      targetType: 'sos_alert',
      targetId: existing.id,
    });
    res.json({ alert: updated });
  });

  app.get('/api/admin/shares', requireAuth, requireRole('admin'), (_req, res) => {
    const shares = db
      .prepare(
        `SELECT rs.id, rs.ride_id, rs.created_by_user_id, rs.is_active, rs.expires_at, rs.created_at, rs.revoked_at,
                u.name AS creator_name, u.account_number AS creator_account_number,
                r.ride_number, r.pickup_address, r.dropoff_address, r.status AS ride_status
         FROM ride_shares rs
         JOIN users u ON u.id = rs.created_by_user_id
         JOIN rides r ON r.id = rs.ride_id
         ORDER BY rs.is_active DESC, rs.created_at DESC LIMIT 100`,
      )
      .all();
    res.json({ shares });
  });

  app.post('/api/admin/shares/:id/revoke', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    db.prepare(`UPDATE ride_shares SET is_active = 0, revoked_at = COALESCE(revoked_at, ?) WHERE id = ?`).run(
      new Date().toISOString(),
      req.params.id,
    );
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'ride_share.revoked_by_admin',
      targetType: 'ride_share',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.get('/api/admin/ratings', requireAuth, requireRole('admin'), (req, res) => {
    const q = String(req.query.q ?? '').trim();
    const params: unknown[] = [];
    let qFilter = '';
    if (q) {
      const like = `%${q}%`;
      qFilter = 'AND (r.ride_number LIKE ? OR cu.account_number LIKE ? OR du.account_number LIKE ? OR cu.name LIKE ? OR du.name LIKE ?)';
      params.push(like, like, like, like, like);
    }
    const ratings = db
      .prepare(
        `SELECT r.id, r.ride_number, r.category, r.driver_rating, r.driver_review, r.customer_rating, r.customer_review,
                r.rating_moderated, r.completed_at, r.pickup_address, r.dropoff_address,
                cu.name AS customer_name, cu.account_number AS customer_account_number,
                du.name AS driver_name, du.account_number AS driver_account_number
         FROM rides r
         JOIN users cu ON cu.id = r.customer_id
         LEFT JOIN users du ON du.id = r.driver_id
         WHERE (r.driver_rating IS NOT NULL OR r.customer_rating IS NOT NULL) ${qFilter}
         ORDER BY r.completed_at DESC LIMIT 100`,
      )
      .all(...params);
    res.json({ ratings });
  });

  app.patch('/api/admin/ratings/:rideId/moderate', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { moderated } = req.body as { moderated: boolean };
    const ride = db.prepare('SELECT id, driver_id, customer_id FROM rides WHERE id = ?').get(req.params.rideId) as
      | { id: string; driver_id: string | null; customer_id: string }
      | undefined;
    if (!ride) {
      res.status(404).json({ error: 'الرحلة غير موجودة' });
      return;
    }

    const tx = db.transaction(() => {
      db.prepare('UPDATE rides SET rating_moderated = ? WHERE id = ?').run(moderated ? 1 : 0, ride.id);
      if (ride.driver_id) {
        const dStats = db
          .prepare(
            `SELECT AVG(driver_rating) AS avg_r, COUNT(driver_rating) AS cnt
             FROM rides WHERE driver_id = ? AND driver_rating IS NOT NULL AND rating_moderated = 0`,
          )
          .get(ride.driver_id) as { avg_r: number | null; cnt: number };
        db.prepare('UPDATE driver_profiles SET rating_avg = ?, rating_count = ? WHERE user_id = ?').run(
          Number((dStats.avg_r || 5).toFixed(2)),
          dStats.cnt,
          ride.driver_id,
        );
      }
      const cStats = db
        .prepare(
          `SELECT AVG(customer_rating) AS avg_r, COUNT(customer_rating) AS cnt
           FROM rides WHERE customer_id = ? AND customer_rating IS NOT NULL AND rating_moderated = 0`,
        )
        .get(ride.customer_id) as { avg_r: number | null; cnt: number };
      db.prepare('UPDATE users SET rating_avg = ?, rating_count = ? WHERE id = ?').run(
        Number((cStats.avg_r || 5).toFixed(2)),
        cStats.cnt,
        ride.customer_id,
      );
    });
    tx();

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: moderated ? 'rating.hidden' : 'rating.restored',
      targetType: 'ride',
      targetId: ride.id,
    });
    res.json({ ok: true });
  });

  app.get('/api/admin/reported-users', requireAuth, requireRole('admin'), (_req, res) => {
    const reportedUsers = db
      .prepare(
        `SELECT u.id, u.account_number, u.name, u.phone, u.role, u.status, u.rating_avg,
                COUNT(mr.id) AS report_count,
                MAX(mr.reason) AS latest_reason,
                MAX(mr.created_at) AS latest_at
         FROM message_reports mr
         JOIN users u ON u.id = mr.reported_user_id
         GROUP BY u.id
         ORDER BY report_count DESC, latest_at DESC`,
      )
      .all();
    res.json({ reportedUsers });
  });

  app.get('/api/admin/pricing', requireAuth, requireRole('admin'), (_req, res) => {
    const pricing = db.prepare('SELECT * FROM pricing_rules WHERE id = 1').get();
    const promos = db.prepare('SELECT * FROM promo_codes ORDER BY created_at DESC').all();
    res.json({ pricing, promos });
  });

  app.put('/api/admin/pricing', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const p = req.body as Partial<PricingRules>;
    const oldCommPct = getCommissionPercent();
    const commPct = p.commission_percent !== undefined ? Number(p.commission_percent) : oldCommPct;
    const values = [
      Number(p.base_fare_iqd),
      Number(p.per_km_iqd),
      Number(p.min_fare_iqd),
      Number(p.waiting_fee_per_min_iqd),
      Number(p.cancellation_fee_iqd),
      Number(p.economy_multiplier),
      Number(p.super_multiplier),
      Number(p.plus_multiplier),
      Number(p.family_multiplier),
    ];
    if (
      values.some((v) => !Number.isFinite(v) || v < 0) ||
      values[5] <= 0 ||
      values[6] <= 0 ||
      values[7] <= 0 ||
      values[8] <= 0 ||
      !Number.isFinite(commPct) ||
      commPct < 0 ||
      commPct > 50
    ) {
      res.status(400).json({ error: 'يجب أن تكون جميع الأسعار والمعاملات ونسبة العمولة (0-50%) أرقاماً صالحة' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare(
      `UPDATE pricing_rules SET
        base_fare_iqd = ?, per_km_iqd = ?, min_fare_iqd = ?,
        waiting_fee_per_min_iqd = ?, cancellation_fee_iqd = ?,
        economy_multiplier = ?, super_multiplier = ?, plus_multiplier = ?, family_multiplier = ?,
        commission_percent = ?, updated_at = ?
       WHERE id = 1`,
    ).run(...values, commPct, now);

    // Clause 7: Notify drivers whenever Admin changes commission_percent so they must consent before receiving new rides
    if (Math.abs(commPct - oldCommPct) > 0.0001) {
      const drivers = db
        .prepare("SELECT id FROM users WHERE role = 'driver' AND status = 'active'")
        .all() as Array<{ id: string }>;
      for (const d of drivers) {
        createNotification({
          userId: d.id,
          title: `تحديث نسبة عمولة مشوار إلى ${commPct}%`,
          body: `تم تعديل نسبة عمولة مشوار من ${oldCommPct}% إلى ${commPct}%. أي رحلة جارية تستمر حتى تكتمل، ولن تصلك طلبات جديدة حتى توافق على التعديل من داخل التطبيق.`,
          type: 'commission_changed',
        });
        sendToUser(d.id, 'driver:commission_changed', {
          oldPercent: oldCommPct,
          newPercent: commPct,
          requiresCommissionConsent: true,
        });
      }
    }

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'pricing.updated',
      targetType: 'pricing_rules',
      targetId: '1',
      details: { ...(p as Record<string, unknown>), oldCommissionPercent: oldCommPct, newCommissionPercent: commPct },
    });
    const pricing = db.prepare('SELECT * FROM pricing_rules WHERE id = 1').get();
    res.json({ pricing });
  });

  // ==================== ADMIN FINANCE, WALLETS & PAYMENT GATEWAYS ====================
  app.get('/api/admin/finance', requireAuth, requireRole('admin'), (req, res) => {
    const q = String(req.query.q ?? '').trim();
    const gateways = listPaymentGatewayConfigs();
    const report = getFinancialAccountingReport();

    const wParams: unknown[] = [];
    let wFilter = '';
    if (q) {
      const like = `%${q}%`;
      wFilter = 'WHERE u.account_number LIKE ? OR u.name LIKE ? OR u.phone LIKE ?';
      wParams.push(like, like, like);
    }

    const wallets = db
      .prepare(
        `SELECT dw.*,
                (dw.bonus_balance_iqd + dw.real_balance_iqd) AS total_available_iqd,
                u.name AS driver_name, u.account_number AS driver_account_number, u.phone AS driver_phone,
                dp.is_online, dp.approval_status
         FROM driver_wallets dw
         JOIN users u ON u.id = dw.driver_id
         JOIN driver_profiles dp ON dp.user_id = dw.driver_id
         ${wFilter}
         ORDER BY dw.updated_at DESC`,
      )
      .all(...wParams);

    const wtParams: unknown[] = [];
    let wtFilter = '';
    if (q) {
      const like = `%${q}%`;
      wtFilter = 'WHERE u.account_number LIKE ? OR u.name LIKE ? OR r.ride_number LIKE ?';
      wtParams.push(like, like, like);
    }

    const walletTransactions = db
      .prepare(
        `SELECT wt.*, u.name AS driver_name, u.account_number AS driver_account_number, r.ride_number
         FROM wallet_transactions wt
         JOIN users u ON u.id = wt.driver_id
         LEFT JOIN rides r ON r.id = wt.ride_id
         ${wtFilter}
         ORDER BY wt.created_at DESC LIMIT 150`,
      )
      .all(...wtParams);

    const ptParams: unknown[] = [];
    let ptFilter = '';
    if (q) {
      const like = `%${q}%`;
      ptFilter =
        'WHERE pt.reference_id LIKE ? OR u.account_number LIKE ? OR du.account_number LIKE ? OR r.ride_number LIKE ? OR u.name LIKE ?';
      ptParams.push(like, like, like, like, like);
    }

    const paymentTransactions = db
      .prepare(
        `SELECT pt.*, u.name AS user_name, u.account_number AS user_account_number,
                du.name AS driver_name, du.account_number AS driver_account_number,
                r.ride_number
         FROM payment_transactions pt
         JOIN users u ON u.id = pt.user_id
         LEFT JOIN users du ON du.id = pt.driver_id
         LEFT JOIN rides r ON r.id = pt.ride_id
         ${ptFilter}
         ORDER BY pt.created_at DESC LIMIT 150`,
      )
      .all(...ptParams);

    res.json({
      gateways,
      commission_percent: getCommissionPercent(),
      report,
      wallets,
      walletTransactions,
      paymentTransactions,
    });
  });

  app.put('/api/admin/payments/gateways/:provider', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const provider = req.params.provider as PaymentMethod;
    if (provider !== 'cash' && provider !== 'superqi' && provider !== 'zaincash') {
      res.status(400).json({ error: 'بوابة دفع غير صالحة' });
      return;
    }

    const { is_enabled, merchant_approved, environment, merchant_id, api_base_url, min_topup_iqd } = req.body as {
      is_enabled?: number | boolean;
      merchant_approved?: number | boolean;
      environment?: 'pending_approval' | 'sandbox' | 'production';
      merchant_id?: string | null;
      api_base_url?: string | null;
      min_topup_iqd?: number;
    };

    let cleanBaseUrl: string | null = null;
    if (provider !== 'cash' && api_base_url) {
      try {
        cleanBaseUrl = validateGatewayBaseUrl(api_base_url, provider);
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'رابط البوابة غير صالح' });
        return;
      }
    }

    const safeEnv =
      environment === 'production' || environment === 'sandbox' ? environment : 'pending_approval';
    const minTop = Math.max(0, Math.round(Number(min_topup_iqd) || 0));

    db.prepare(
      `UPDATE payment_gateway_configs
       SET is_enabled = ?,
           merchant_approved = ?,
           environment = ?,
           merchant_id = ?,
           api_base_url = COALESCE(?, api_base_url),
           min_topup_iqd = ?,
           updated_at = ?
       WHERE provider = ?`,
    ).run(
      is_enabled ? 1 : 0,
      provider === 'cash' ? 1 : merchant_approved ? 1 : 0,
      provider === 'cash' ? 'production' : safeEnv,
      merchant_id?.trim() || null,
      cleanBaseUrl,
      minTop,
      new Date().toISOString(),
      provider,
    );

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'payment_gateway.updated',
      targetType: 'payment_gateway',
      targetId: provider,
      details: { is_enabled: Boolean(is_enabled), merchant_approved: Boolean(merchant_approved), environment: safeEnv },
    });

    res.json({ gateways: listPaymentGatewayConfigs() });
  });

  app.post('/api/admin/wallets/:driverId/adjust', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { walletPool, deltaIqd, reason } = req.body as {
      walletPool?: 'real' | 'bonus';
      deltaIqd?: number;
      reason?: string;
    };
    if (walletPool !== 'real' && walletPool !== 'bonus') {
      res.status(400).json({ error: 'نوع الرصيد غير صالح' });
      return;
    }
    const driver = db
      .prepare("SELECT id FROM users WHERE id = ? AND role = 'driver'")
      .get(req.params.driverId);
    if (!driver) {
      res.status(404).json({ error: 'السائق غير موجود' });
      return;
    }

    try {
      const outcome = adjustDriverWalletByAdmin({
        driverId: req.params.driverId,
        adminUserId: req.auth!.userId,
        walletPool,
        deltaIqd: Number(deltaIqd),
        reason: String(reason || ''),
      });
      sendToUser(req.params.driverId, 'wallet:updated', outcome.wallet);
      if (outcome.reactivated) {
        const dp = db.prepare('SELECT * FROM driver_profiles WHERE user_id = ?').get(req.params.driverId);
        sendToAdmins('admin:driver_status', dp);
      }
      createNotification({
        userId: req.params.driverId,
        title: 'تحديث إداري على رصيد المحفظة',
        body: `${Number(deltaIqd) > 0 ? 'إضافة' : 'خصم'} ${Math.abs(Math.round(Number(deltaIqd))).toLocaleString()} د.ع — السبب: ${reason}`,
        type: 'admin_notice',
      });
      res.json(outcome);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر تعديل الرصيد' });
    }
  });

  app.post('/api/admin/promos', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { code, discount_percent, max_discount_iqd, expires_at } = req.body as {
      code: string;
      discount_percent: number;
      max_discount_iqd: number;
      expires_at?: string;
    };
    const pct = Number(discount_percent);
    const maxDisc = Number(max_discount_iqd) || 5000;
    if (!code?.trim() || !Number.isFinite(pct) || pct <= 0 || pct > 100 || maxDisc < 0) {
      res.status(400).json({ error: 'بيانات كود الخصم غير صالحة (النسبة بين 1 و 100)' });
      return;
    }
    const id = crypto.randomUUID();
    const cleanCode = code.trim().toUpperCase();
    db.prepare(
      `INSERT INTO promo_codes (id, code, discount_percent, max_discount_iqd, is_active, expires_at, created_at)
       VALUES (?, ?, ?, ?, 1, ?, ?)`,
    ).run(id, cleanCode, pct, maxDisc, expires_at || null, new Date().toISOString());

    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'promo.created',
      targetType: 'promo_code',
      targetId: id,
      details: { code: cleanCode, discount_percent: pct },
    });
    const promo = db.prepare('SELECT * FROM promo_codes WHERE id = ?').get(id);
    res.status(201).json({ promo });
  });

  app.patch('/api/admin/promos/:id', requireAuth, requireRole('admin'), (req, res) => {
    const { is_active } = req.body as { is_active: number };
    db.prepare('UPDATE promo_codes SET is_active = ? WHERE id = ?').run(is_active ? 1 : 0, req.params.id);
    res.json({ ok: true });
  });

  app.get('/api/admin/plus', requireAuth, requireRole('admin'), (_req, res) => {
    const settings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get();
    const subscriptions = db
      .prepare(
        `SELECT ps.*, u.name AS user_name, u.phone AS user_phone
         FROM plus_subscriptions ps
         JOIN users u ON u.id = ps.user_id
         ORDER BY ps.created_at DESC`,
      )
      .all();
    res.json({ settings, subscriptions });
  });

  app.put('/api/admin/plus', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const s = req.body as Partial<PlusSettings>;
    db.prepare(
      `UPDATE plus_settings SET
        monthly_price_iqd = ?, discount_percent = ?, waive_cancellation_fee = ?,
        priority_matching_enabled = ?, is_enabled = ?, updated_at = ?
       WHERE id = 1`,
    ).run(
      Math.max(0, Number(s.monthly_price_iqd) || 15000),
      Math.min(100, Math.max(0, Number(s.discount_percent) || 15)),
      s.waive_cancellation_fee ? 1 : 0,
      s.priority_matching_enabled ? 1 : 0,
      s.is_enabled ? 1 : 0,
      new Date().toISOString(),
    );
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'plus.settings_updated',
      targetType: 'plus_settings',
      targetId: '1',
      details: s as Record<string, unknown>,
    });
    const settings = db.prepare('SELECT * FROM plus_settings WHERE id = 1').get();
    res.json({ settings });
  });

  app.patch('/api/admin/plus/subscriptions/:id', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { status } = req.body as { status: 'active' | 'inactive' };
    db.prepare('UPDATE plus_subscriptions SET status = ? WHERE id = ?').run(status, req.params.id);
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: `plus.subscription_${status}`,
      targetType: 'plus_subscription',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.get('/api/admin/settings', requireAuth, requireRole('admin'), (_req, res) => {
    const settings = db.prepare('SELECT * FROM app_settings WHERE id = 1').get();
    res.json({ settings });
  });

  app.put('/api/admin/settings', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const s = req.body as Partial<AppSettings>;
    const cleanEmergency = String(s.emergency_phone || '104').trim().slice(0, 24) || '104';
    db.prepare(
      `UPDATE app_settings SET dispatch_timeout_sec = ?, search_radius_km = ?, allow_driver_registration = ?, emergency_phone = ?, updated_at = ? WHERE id = 1`,
    ).run(
      Math.max(10, Number(s.dispatch_timeout_sec) || 20),
      Math.max(2, Number(s.search_radius_km) || 15),
      s.allow_driver_registration ? 1 : 0,
      cleanEmergency,
      new Date().toISOString(),
    );
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'app.settings_updated',
      targetType: 'app_settings',
      targetId: '1',
    });
    const settings = db.prepare('SELECT * FROM app_settings WHERE id = 1').get();
    res.json({ settings });
  });

  app.patch('/api/admin/complaints/:id', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { status, admin_reply } = req.body as { status: 'in_review' | 'resolved'; admin_reply?: string };
    const resolvedAt = status === 'resolved' ? new Date().toISOString() : null;
    db.prepare(
      `UPDATE complaints SET status = ?, admin_reply = COALESCE(?, admin_reply), resolved_at = COALESCE(?, resolved_at) WHERE id = ?`,
    ).run(status, admin_reply?.trim() || null, resolvedAt, req.params.id);
    const comp = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id) as { user_id: string } | undefined;
    if (comp) {
      createNotification({
        userId: comp.user_id,
        title: 'تحديث حول شكواك',
        body: admin_reply?.trim() || 'تم تحديث حالة الشكوى من قبل فريق الدعم',
        type: 'complaint_update',
      });
    }
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: `complaint.${status}`,
      targetType: 'complaint',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.post('/api/admin/notify-drivers', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const { title, body } = req.body as { title?: string; body?: string };
    if (!title?.trim() || !body?.trim()) {
      res.status(400).json({ error: 'العنوان ونص الإشعار مطلوبان' });
      return;
    }
    const drivers = db
      .prepare("SELECT id FROM users WHERE role = 'driver' AND status = 'active'")
      .all() as Array<{ id: string }>;
    for (const d of drivers) {
      createNotification({
        userId: d.id,
        title: title.trim(),
        body: body.trim(),
        type: 'admin_notice',
      });
    }
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'admin.broadcast_drivers',
      targetType: 'notification',
      details: { count: drivers.length, title },
    });
    res.json({ sentCount: drivers.length });
  });

  app.get('/api/admin/audit-logs', requireAuth, requireRole('admin'), (_req, res) => {
    const logs = db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100').all();
    res.json({ logs });
  });

  // ==================== ADMIN SECURITY EVENTS & BACKUPS ====================
  app.get('/api/admin/security', requireAuth, requireRole('admin'), (_req, res) => {
    const events = db.prepare('SELECT * FROM security_events ORDER BY created_at DESC LIMIT 100').all();
    const backups = db.prepare('SELECT * FROM backup_records ORDER BY created_at DESC LIMIT 20').all();
    res.json({ events, backups });
  });

  app.patch('/api/admin/security/:id/resolve', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    db.prepare('UPDATE security_events SET is_resolved = 1 WHERE id = ?').run(req.params.id);
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'security.event_resolved',
      targetType: 'security_event',
      targetId: req.params.id,
    });
    res.json({ ok: true });
  });

  app.post('/api/admin/backups', requireAuth, requireRole('admin'), async (req: AuthedRequest, res) => {
    const backup = await createDatabaseBackup('manual');
    writeAuditLog({
      actorUserId: req.auth!.userId,
      actorRole: 'admin',
      action: 'backup.created_manual',
      targetType: 'backup_record',
      targetId: backup.id,
      details: { filename: backup.filename, sha256: backup.sha256 },
    });
    res.status(201).json({ backup });
  });

  app.get('/api/admin/export/:target', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
    const rawTarget = String(req.params.target || '').toLowerCase();
    if (rawTarget !== 'customer' && rawTarget !== 'driver' && rawTarget !== 'admin') {
      res.status(400).json({ error: 'هدف التصدير غير صالح (customer | driver | admin)' });
      return;
    }
    const target = rawTarget as StandaloneProjectTarget;
    try {
      const { zipPath, filename, sizeBytes } = generateStandaloneProjectZip(target);
      writeAuditLog({
        actorUserId: req.auth!.userId,
        actorRole: 'admin',
        action: 'admin.project_exported_zip',
        targetType: 'standalone_project',
        targetId: target,
        details: { filename, sizeBytes },
      });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.sendFile(zipPath);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'تعذر إنشاء حزمة ZIP للمشروع المستقل',
      });
    }
  });

  const roleManifests = {
    customer: {
      id: '/customer',
      name: 'MISHWAR – مشوار (تطبيق الزبون)',
      short_name: 'مشوار',
      description: 'تطبيق الزبون لطلب رحلات مشوار في العراق وتتبع السيارة لحظياً.',
      theme_color: '#6D28D9',
      background_color: '#F8FAFC',
      display: 'standalone',
      orientation: 'portrait',
      dir: 'rtl',
      lang: 'ar',
      start_url: '/customer',
      scope: '/',
      icons: [
        { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: '/pwa-maskable-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
      ],
    },
    driver: {
      id: '/driver',
      name: 'MISHWAR – كابتن مشوار (السائق)',
      short_name: 'كابتن مشوار',
      description: 'تطبيق كابتن مشوار لاستقبال طلبات الرحلات وتشغيل زر مشوار وإدارة المحفظة.',
      theme_color: '#0F172A',
      background_color: '#F8FAFC',
      display: 'standalone',
      orientation: 'portrait',
      dir: 'rtl',
      lang: 'ar',
      start_url: '/driver',
      scope: '/',
      icons: [
        { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: '/pwa-maskable-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
      ],
    },
    admin: {
      id: '/admin',
      name: 'MISHWAR – إدارة مشوار',
      short_name: 'إدارة مشوار',
      description: 'لوحة تحكم الإدارة والعمليات والمالية ومراقبة الأسطول لمنصة مشوار.',
      theme_color: '#1D4ED8',
      background_color: '#F8FAFC',
      display: 'standalone',
      dir: 'rtl',
      lang: 'ar',
      start_url: '/admin',
      scope: '/',
      icons: [
        { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: '/pwa-maskable-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
      ],
    },
  } as const;

  (['customer', 'driver', 'admin'] as const).forEach((roleKey) => {
    app.get(`/manifest-${roleKey}.webmanifest`, (_req, res) => {
      res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache');
      res.json(roleManifests[roleKey]);
    });
  });

  app.get(['/mishwar.apk', '/api/download/apk'], (_req, res) => {
    const apkPath = path.resolve(process.cwd(), 'exports', 'Mishwar.apk');
    if (!fs.existsSync(apkPath)) {
      res.status(404).json({ error: 'ملف APK غير متوفر حالياً' });
      return;
    }
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="Mishwar.apk"');
    res.sendFile(apkPath);
  });

  return { app, server };
}

function detectAppRoleFromRequest(req: express.Request): 'customer' | 'driver' | 'admin' | null {
  const cleanPath = req.path.replace(/\/+$/, '').toLowerCase();
  const appParam = typeof req.query.app === 'string' ? req.query.app.toLowerCase() : '';
  if (cleanPath === '/customer' || appParam === 'customer') return 'customer';
  if (cleanPath === '/driver' || appParam === 'driver') return 'driver';
  if (cleanPath === '/admin' || appParam === 'admin') return 'admin';
  return null;
}

function patchHtmlForAppRole(html: string, role: 'customer' | 'driver' | 'admin' | null): string {
  if (!role) return html;
  const titles: Record<'customer' | 'driver' | 'admin', { full: string; short: string }> = {
    customer: { full: 'MISHWAR – مشوار (تطبيق الزبون)', short: 'مشوار' },
    driver: { full: 'MISHWAR – كابتن مشوار (السائق)', short: 'كابتن مشوار' },
    admin: { full: 'MISHWAR – إدارة مشوار', short: 'إدارة مشوار' },
  };
  let out = html;
  if (out.includes('/manifest.webmanifest')) {
    out = out.replace(/\/manifest\.webmanifest/g, `/manifest-${role}.webmanifest`);
  } else {
    out = out.replace('</head>', `  <link rel="manifest" href="/manifest-${role}.webmanifest" />\n  </head>`);
  }
  out = out.replace(/<title>.*?<\/title>/i, `<title>${titles[role].full}</title>`);
  out = out.replace(
    /(<meta name="apple-mobile-web-app-title" content=")[^"]*(")/i,
    `$1${titles[role].short}$2`,
  );
  return out;
}

async function startServer() {
  const { app, server } = createMishwarServer();
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, ws: false },
      appType: 'spa',
    });

    app.get('/@vite/client', async (req, res, next) => {
      try {
        const result = await vite.transformRequest(req.originalUrl);
        if (!result) {
          next();
          return;
        }
        const patchedCode = result.code.replace(
          /createWebSocketModuleRunnerTransport\(\{[\s\S]*?\}\)/g,
          '({ async connect() {}, async disconnect() {}, send() {} })',
        );
        res.status(200).set({ 'Content-Type': 'application/javascript; charset=utf-8' }).end(patchedCode);
      } catch (err) {
        next(err);
      }
    });

    app.get(['/customer', '/driver', '/admin'], async (req, res, next) => {
      try {
        const role = detectAppRoleFromRequest(req);
        const templatePath = path.resolve(process.cwd(), 'index.html');
        const rawHtml = fs.readFileSync(templatePath, 'utf-8');
        const transformed = await vite.transformIndexHtml(req.originalUrl, rawHtml);
        res.status(200).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(patchHtmlForAppRole(transformed, role));
      } catch (err) {
        next(err);
      }
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      const role = detectAppRoleFromRequest(req);
      const indexFile = path.join(distPath, 'index.html');
      if (role && fs.existsSync(indexFile)) {
        const html = fs.readFileSync(indexFile, 'utf-8');
        res.status(200).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(patchHtmlForAppRole(html, role));
        return;
      }
      res.sendFile(indexFile);
    });
  }

  const PORT = process.env.NODE_ENV === 'production' ? Number(process.env.PORT) || 3000 : 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`MISHWAR server running on http://0.0.0.0:${PORT}`);
  });
}

if (process.env.MISHWAR_TEST_MODE !== '1') {
  startServer();
}
